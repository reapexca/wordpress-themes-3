<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<header class="entry-header clearfix">

<?php if ( has_post_thumbnail() ) { ?>

<div class="entry-thumb">

	<?php if ( is_single() ) { ?>
    
    <?php ht_responsive_post_thumbnail(); ?>
         
    <?php } else { ?> 
        <a href="<?php the_permalink(); ?>" rel="nofollow">
           <?php ht_responsive_post_thumbnail(); ?>
        </a>
    <?php }?>
    
</div>
<?php } ?>

<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>

<ul class="entry-meta clearfix">
	<li class="entry-meta-date"><i class="fa fa-clock-o"></i><time datetime="<?php the_time('Y-m-d')?>" itemprop="datePublished"><?php the_time( get_option('date_format') ); ?></time></li>
    <li class="entry-meta-category"><i class="fa fa-folder"></i><?php the_category('/ '); ?></li>
    <li class="entry-meta-comments"><i class="fa fa-comment"></i><?php comments_popup_link( __( '0 Comments', 'framework' ), __( '1 Comment', 'framework' ), __( '% Comments', 'framework' ) ); ?></li>
</ul>
</header>      

     
<div class="entry-content clearfix">
	<?php if ( is_single() ) { ?>
        <?php the_content(); ?>
        <?php numbered_in_page_links( array( 'before' => '<div class="page-links"><strong>' . __( 'Pages:', 'framework' ) .'</strong>', 'after' => '</div>' ) ); ?>
    <?php } else { ?>
        <?php the_excerpt(); ?>
    <?php }?>
</div>



<?php if ( !is_single() ) { ?>
    	<a class="readmore" href="<?php the_permalink(); ?>"><?php _e( "Read More", "framework" ); ?></a>
<?php }?>

<?php if (is_single() && has_tag()) { ?>
        <div class="tags"><?php the_tags( __( '<strong>Tagged:</strong>', 'framework' ),'',''); ?></div>
<?php } ?>

</article>