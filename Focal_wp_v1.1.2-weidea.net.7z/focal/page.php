<?php get_header(); ?>

<!-- #primary -->
<div id="primary" class="<?php ht_get_sidebar_position(); ?> clearfix">
<div class="ht-container">

<!-- #content -->
<div id="content" role="main">

    <?php while ( have_posts() ) : the_post(); ?>
        
    	<?php get_template_part( 'content', 'page' ); ?>

		<?php
        // If comments are open or we have at least one comment, load up the comment template
        if ( comments_open() || '0' != get_comments_number() )
        comments_template();
        ?>
    
    <?php endwhile; // end of the loop. ?>

</div>
<!-- #content -->
  
<?php ht_get_sidebar(); ?>

</div>
</div>
<!-- #primary -->
<?php get_footer(); ?>