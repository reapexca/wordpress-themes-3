<?php get_header(); ?>

<div id="site-subheader">
<div class="ht-container">
<strong><?php _e( 'Blog ', 'framework' ); ?></strong>
</div>
</div>

<!-- #primary -->
<div id="primary" class="sidebar-right clearfix">
<div class="ht-container">

<!-- #content -->
<div id="content" role="main">

<?php while ( have_posts() ) : the_post(); ?>

<?php get_template_part( 'content', get_post_format() ); ?>

<?php endwhile; // end of the loop. ?>

<?php // If comments are open or we have at least one comment, load up the comment template
		 if ( comments_open() || '0' != get_comments_number() )
					comments_template( '', true ) ?>

</div>
<!-- #content -->
  
<?php get_sidebar(); ?>

</div>
</div>
<!-- #primary -->
<?php get_footer(); ?>