<?php
/**
* The template for displaying Search Results pages.
*
*/
?>

<?php get_header(); ?>

<!-- #primary -->
<section id="primary" class="sidebar-right clearfix"> 
<div class="ht-container">

<!-- #content -->
<div id="content" role="main">

<?php if ( have_posts() ) { ?>

	<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

	<?php get_template_part( 'content', get_post_format() ); ?>
      			
<?php endwhile;  ?>

	<?php ht_content_nav( 'nav-below' );?>

<?php } else { ?>

	<?php get_template_part( 'content', 'none' ); ?>

<?php } ?>
    
</div>
<!-- /#content -->

<?php get_sidebar(); ?>

</div>
</section>
<!-- /#primary -->

<?php get_footer(); ?>