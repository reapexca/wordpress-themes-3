<?php
/**
* Functions and definitions
* by Hero Themes (http://herothemes.com)
*/


/**
* Set the content width based on the theme's design and stylesheet.
*/
if ( ! isset( $content_width ) ) $content_width = 600;

if ( ! function_exists( 'ht_theme_setup' ) ):
/**
* Sets up theme defaults and registers support for various WordPress features.
*/
function ht_theme_setup() {

    // Load HT Core
    //add_theme_support( 'ht-core' );
    add_theme_support( 'ht-core', 'font-awesome', 'wp-thumb', 'theme-updates' );
    require_if_theme_supports( 'ht-core', get_template_directory() . '/inc/ht-core/ht-core.php' );
	
	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 */
	load_theme_textdomain( 'framework', get_template_directory() . '/languages' );

	/**
	 * This theme uses wp_nav_menu() in one location.
	 */
	register_nav_menus( array(
			'primary-nav' => __( 'Primary Navigation', 'framework' )
	));
	
	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, and column width.
	 */
    add_editor_style( array( 'css/editor-style.css', ht_google_font_url() ) );
	
	// Adds RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );
	
	// Enable support for Post Thumbnails

	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 60, 60, true );

    add_image_size( 'post', 920, '', true );
    add_image_size( 'post-mid', 600, '', true );
    add_image_size( 'post-small', 320, '', true );

	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );
	
    // Enable HTML5 markup
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery' ) );
    
    // Add HT Gallery support
    add_theme_support( 'hero-gallery-manager' );
    add_theme_support('ht_gallery_video_url_features');
	
}
endif; // ht_theme_setup
add_action( 'after_setup_theme', 'ht_theme_setup' );


/**
* Enqueues scripts and styles for front-end.
*/
 
require("inc/scripts.php");
require("inc/styles.php");

/**
 * Register widgetized & Add Widgets
 */

require("inc/register-sidebars.php");

// Custom Widgets
require("inc/widgets/widget-functions.php");


// Theme Customizer
require("inc/theme-customizer.php");

// Inlcude Plugins
require("inc/tgm-load-plugins.php");

// Meta Boxe Options
require("inc/meta-boxes.php");

/**
* Add Template Navigation Functions
*/
require("inc/template-tags.php");


/**
* Comment Functions
*/
require("inc/comment-functions.php");


/**
 * Custom excerpt length
 */
function custom_excerpt_length( $length ) {
	return 26;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

function new_excerpt_more( $more ) {
	return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');


/**
* Portfolio Walker (for displaying category filter)
*/
class HT_Portfolio_Walker extends Walker_Category {
	function start_el(&$output, $category, $depth = 0, $args = array(), $current_object_id = 0) {
            extract($args);

            $cat_name = esc_attr( $category->name );
            $cat_name = apply_filters( 'list_cats', $cat_name, $category );
            $link = '<a href="' . esc_attr( get_term_link($category) ) . '" ';
            $link .= 'data-filter="' . urldecode($category->slug) . '" ';
            if ( $use_desc_for_title == 0 || empty($category->description) )
                    $link .= 'title="' . esc_attr( sprintf(__( 'View all posts filed under %s', 'framework' ), $cat_name) ) . '"';
            else
                    $link .= 'title="' . esc_attr( strip_tags( apply_filters( 'category_description', $category->description, $category ) ) ) . '"';
            $link .= '>';
            $link .= $cat_name . '</a>';

            if ( !empty($feed_image) || !empty($feed) ) {
                    $link .= ' ';

                    if ( empty($feed_image) )
                            $link .= '(';

                    $link .= '<a href="' . get_term_feed_link( $category->term_id, $category->taxonomy, $feed_type ) . '"';

                    if ( empty($feed) ) {
                            $alt = ' alt="' . sprintf(__( 'Feed for all posts filed under %s', 'framework' ), $cat_name ) . '"';
                    } else {
                            $title = ' title="' . $feed . '"';
                            $alt = ' alt="' . $feed . '"';
                            $name = $feed;
                            $link .= $title;
                    }

                    $link .= '>';

                    if ( empty($feed_image) )
                            $link .= $name;
                    else
                            $link .= "<img src='$feed_image'$alt$title" . ' />';

                    $link .= '</a>';

                    if ( empty($feed_image) )
                            $link .= ')';
            }

            if ( !empty($show_count) )
                    $link .= ' (' . intval($category->count) . ')';

            if ( !empty($show_date) )
                    $link .= ' ' . gmdate('Y-m-d', $category->last_update_timestamp);

            if ( 'list' == $args['style'] ) {
                    $output .= "\t<li";
                    $class = 'cat-item cat-item-' . $category->term_id;
                    if ( !empty($current_category) ) {
                            $_current_category = get_term( $current_category, $category->taxonomy );
                            if ( $category->term_id == $current_category )
                                    $class .=  ' current-cat';
                            elseif ( $category->term_id == $_current_category->parent )
                                    $class .=  ' current-cat-parent';
                    }
                    $output .=  ' class="' . $class . '"';
                    $output .= ">$link\n";
            } else {
                    $output .= "\t$link<br />\n";
            }
    }
}




/**
* Get related posts by taxonomy
*/

if ( !function_exists( 'ht_get_posts_related_by_taxonomy' ) ) {
    function ht_get_posts_related_by_taxonomy($post_id, $taxonomy) {
        $query = new WP_Query();
        $terms = wp_get_object_terms($post_id, $taxonomy);
        if (count($terms) > 0) {
        // Assumes only one term for per post in this taxonomy
        $post_ids = get_objects_in_term($terms[0]->term_id,$taxonomy);
        $post = get_post($post_id);
		$args = '';
        $args = wp_parse_args($args,array(
            'post_type' => $post->post_type, // The assumes the post types match
            'post__not_in' => array($post_id),
            'taxonomy' => $taxonomy,
            'term' => $terms[0]->slug,
            'orderby' => 'rand',
            'posts_per_page' => 4
        ));
        $query = new WP_Query($args);
        }
        return $query;
    }
}


// Return logo src
if ( ! function_exists( 'ht_theme_logo' ) ) {
function ht_theme_logo() {

    $ht_theme_logo = get_theme_mod( 'ht_site_logo' );
    
    if ( !empty($ht_theme_logo) ) {
        $ht_theme_logo_src = get_theme_mod( 'ht_site_logo' );
    } else {
        $ht_theme_logo_src = get_template_directory_uri()."/images/logo.png";
    }
    return $ht_theme_logo_src;

}
}

// Get responsive thumbnails, if function is available
function ht_responsive_post_thumbnail() {
	if ( function_exists( 'ht_get_responsive_post_thumbnail' ) ) {
    	ht_get_responsive_post_thumbnail();
	} else {
		the_post_thumbnail('post');
	}
}

if ( ! function_exists( 'ht_get_responsive_post_thumbnail' ) ) :
/**
* Responsive Post Thumbnails
*
*/
function ht_get_responsive_post_thumbnail() {
 
	$ht_post_thumbnail_id = get_post_thumbnail_id( get_the_id() );
	$ht_post_thumbnail_320 = wp_get_attachment_image_src( $ht_post_thumbnail_id, 'width=320&height=0&crop=resize-crop' );
	$ht_post_thumbnail_480 = wp_get_attachment_image_src( $ht_post_thumbnail_id, 'width=480&height=0&crop=resize-crop' );
	$ht_post_thumbnail_600 = wp_get_attachment_image_src( $ht_post_thumbnail_id, 'width=600&height=0&crop=resize-crop' );
	$ht_post_thumbnail_920 = wp_get_attachment_image_src( $ht_post_thumbnail_id, 'width=920&height=0&crop=resize-crop' );
	$ht_post_thumbnail_1200 = wp_get_attachment_image_src( $ht_post_thumbnail_id, 'width=1200&height=0&crop=resize-crop' );
	?>
    <picture>
    <source src="<?php echo $ht_post_thumbnail_320[0]; ?>">
    <source media="(min-width: 320px)" src="<?php echo $ht_post_thumbnail_480[0]; ?>">
    <source media="(min-width: 480px)" src="<?php echo $ht_post_thumbnail_600[0]; ?>">
    <source media="(min-width: 600px)" src="<?php echo $ht_post_thumbnail_920[0]; ?>">
    <source media="(min-width: 920px)" src="<?php echo $ht_post_thumbnail_1200[0]; ?>">
    	<noscript>
    	<img src="<?php echo $ht_post_thumbnail_1200[0] ?>" alt="" />
        </noscript>
  	</picture>
	<?php
	
}
endif;


// Modify default password protect form
function custom_password_text($content) {
    $before = 'Password:';
    $after = ' ';
    $content = str_replace($before, $after, $content);
    return $content;
}
add_filter('the_password_form', 'custom_password_text');

// Add class to body when fixed footer is needed
add_filter( 'body_class', 'ht_body_fullscreen_gallery_class');
function ht_body_fullscreen_gallery_class( $classes ) {
global $post;

if ($post == '') return $classes;
 
    // Is the gallery slideshow + fullscreen?
    if ( is_page_template('template-homepage.php') ) {
        $ht_homepage_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
        $ht_gallery_type = get_post_meta( $ht_homepage_gallery_ID, '_ht_gallery_type', true );
        $ht_gallery_slideshow_fullscreen =  get_post_meta( $ht_homepage_gallery_ID, '_ht_gallery_slideshow_full', true );
    } else {
        $ht_gallery_type = get_post_meta( get_the_id(), '_ht_gallery_type', true );
        $ht_gallery_slideshow_fullscreen =  get_post_meta( get_the_ID(), '_ht_gallery_slideshow_full', true );
    }   
    if ( $ht_gallery_slideshow_fullscreen == 'on' && $ht_gallery_type == 'slideshow' && !is_post_type_archive( 'ht_gallery_post' ) && !post_password_required( get_the_ID() )  ) { 
        $classes[] .= 'fixed-footer';
    }
    if ( $ht_gallery_slideshow_fullscreen == 'on' && $ht_gallery_type == 'slideshow' && !is_post_type_archive( 'ht_gallery_post' ) && !post_password_required( get_the_ID() ) ) { 
        $classes[] .= 'fixed-header';
    }  

    return $classes; 

}