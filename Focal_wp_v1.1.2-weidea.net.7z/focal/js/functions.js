// Start Wrapper
jQuery(document).ready(function($) {
 
// Responsive Images
$(function(){
    $('picture').picture();
});

// Mobile Nav Menu
$(function htMenuToggle() {

    $("#navbar-toggle").click(function () {
        $("#nav-primary").animate({
            height: "toggle",
            opacity: "toggle"
        }, 400);
    });
    
});

// HT Gallery Lightbox
jQuery('#ht-gallery-grid').magnificPopup({
    delegate: '.ht-lightbox', // child items selector, by clicking on it popup will open
    
    image: {
        titleSrc: 'title', // Attribute of the target element that contains caption for the slide.
    },
    gallery:{
        enabled:true,
        preload: [1,2],
    },
    
});

// WordPress Gallery Shortcode
jQuery('.entry-content .gallery').magnificPopup({
  delegate: 'a', // child items selector, by clicking on it popup will open
  type: 'image',
  image: { titleSrc: 'title'  },
  gallery: { 
    enabled: true ,
    navigateByImgClick: true,
  },
});

// Horitonzal Gallery 
imagesLoaded( '#single-gallery-header', function() { 
	var gallery_header = $('#single-gallery-header');
	if(gallery_header.length>0){
		var gallery_header_ul = gallery_header.children('ul');
		if(gallery_header_ul.length > 0 ){
			var total_width = 0;
			gallery_header_ul.children('li').each(function(){
				total_width += $(this).width();
			});
			gallery_header_ul.width(total_width);
		}
	}
});


$('#single-gallery-header').niceScroll({
	cursorborder:"0",
	cursorborderradius:"8px",
	cursorwidth:"6px",
	cursorcolor:"rgba(255,255,255,0.8)",
	cursorborderradius: 0,
	touchbehavior: true, 
	bouncescroll: true
});


$('.gallery-fullscreen').magnificPopup({
	type:'image',
	gallery: {
		enabled: true,
		navigateByImgClick: true,
		preload: [0,1] // Will preload 0 - before current, and 1 after the current image
	}, 
});

//	End Wrapper
});	



    jQuery(document).ready(function ($) {
        $(window).load(function () {
			var isotopeContainer = $("#isotope-container");
            if ($().isotope) {
                 isotopeContainer = $("#isotope-container"),
                    calculateColumnWidth = function () {
                        var newIsotopeWidth, windowWidth = $(window).width();
						windowWidth <= 450 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 1) : 
                        windowWidth <= 900 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 2) : 
						windowWidth <= 1350 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 3) : 
						windowWidth <= 1800 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 4) : 
						windowWidth <= 2250 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 5) : 
						windowWidth <= 2700 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 6) : 
						windowWidth <= 3150 ? newIsotopeWidth = Math.floor(isotopeContainer.width() / 7) : 
						newIsotopeWidth = 450;
                        return newIsotopeWidth;
                    }, setColumnWidth = function () {
                        var columnWidth = calculateColumnWidth();
                        isotopeContainer.children().css({
                            width: columnWidth
                        })
                    };
                setColumnWidth();
                isotopeContainer.isotope({
                    layoutMode: "masonry",
                    masonry: {
                        columnWidth: calculateColumnWidth(),
                    },
                });

                $(window).smartresize(function () {
                    setColumnWidth();
                    isotopeContainer.isotope({
                        masonry: {
                            columnWidth: calculateColumnWidth()
                        }
                    })
                });
				
				optionFilter = $('#gallery-filter'),
					optionFilterLinks = optionFilter.find('a');
					optionFilterLinks.attr('href', '#');
					optionFilterLinks.click(function () {
						var selector = jQuery(this).attr('data-filter');
						// initialize Isotope
						isotopeContainer.isotope({
							filter : '.' + selector
						});
						// Highlight the correct filter
						optionFilterLinks.removeClass('active');
						jQuery(this).addClass('active');
						return false;
});
            }
        });
    })



function htResponsiveSlideshow() {
  var windowWidth = jQuery(window).width();
    if( windowWidth < 320) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-320'));
        });
    }
    else if( windowWidth < 480) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-480'));
        });
    }
    else if( windowWidth < 600) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-600'));
        });
    }
    else if( windowWidth < 920) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-920'));
        });
    }
    else if( windowWidth < 1200) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-1200'));
        });
    }
    else if( windowWidth < 1600) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-1600'));
        });
    }
    else if( windowWidth >= 1600) {
        jQuery('#ht-gallery-slideshow .rsImg, #ht-gallery-carousel .rsImg').each(function() {
            jQuery(this).attr('src', jQuery(this).attr('data-image-2000'));
        });
    }
};

jQuery(document).ready(function($) {


// Responsive Slider Images
jQuery(window).load(function () {
  htResponsiveSlideshow();
  console.log('window load');
}); 

jQuery( window ).resize(function() {
  htResponsiveSlideshow();
  console.log('window resize');
});


}); 


// Full height gallery
jQuery(document).ready(function($) {

    var headerHeight = $('#site-header').outerHeight();
    var footerHeight = $('#site-footer').outerHeight();
    jQuery('.ht-gallery-fullscreen').css({ "padding-top": headerHeight - 20, "padding-bottom": footerHeight });

}); 