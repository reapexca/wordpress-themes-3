// Start Wrapper
jQuery(document).ready(function ($) {

	// Show slideshow only options when it's selected
	if($('#_ht_gallery_type').val() != 'slideshow') {
		$('.cmb_id__ht_gallery_slideshow_full, .cmb_id__ht_gallery_slideshow_thumbs, .cmb_id__ht_gallery_slideshow_imgsizing, .cmb_id__ht_gallery_slideshow_thumbs_orien').hide();
	} 
	
	$('#_ht_gallery_type').change(function() {
		if($(this).val() == 'slideshow') {
			$('.cmb_id__ht_gallery_slideshow_full, .cmb_id__ht_gallery_slideshow_thumbs, .cmb_id__ht_gallery_slideshow_imgsizing, .cmb_id__ht_gallery_slideshow_thumbs_orien').show();
		} else {
			$('.cmb_id__ht_gallery_slideshow_full, .cmb_id__ht_gallery_slideshow_thumbs, .cmb_id__ht_gallery_slideshow_imgsizing, .cmb_id__ht_gallery_slideshow_thumbs_orien').hide();
		}
	});

	$('#_ht_gallery_type').change(function() {
		if($(this).val() == 'horizontal') {
			$('.cmb_id__ht_gallery_img_titles, .cmb_id__ht_gallery_img_caption').hide();
		} else {
			$('.cmb_id__ht_gallery_img_titles, .cmb_id__ht_gallery_img_caption').show();
		}
	});
	
	// Show fullscreen btn option only on slideshow and carousel
	if( $('#_ht_gallery_type').val() != 'slideshow' && $('#_ht_gallery_type').val() != 'carousel' )  {
			$('.cmb_id__ht_gallery_fullscreen_btn').hide();
	} 
	
	$('#_ht_gallery_type').change(function() {
		if($(this).val() == 'slideshow' || $(this).val() == 'carousel') {
			$('.cmb_id__ht_gallery_fullscreen_btn').show();
		} else {
			$('.cmb_id__ht_gallery_fullscreen_btn').hide();
		}
	});
	
	// Show thumbs orien only when option is active
	$('#_ht_gallery_slideshow_thumbs').change(function(){
		slideShowThumbOptionsSync();
	});
	
	slideShowThumbOptionsSync();
	
	function slideShowThumbOptionsSync(){
		if ($('#_ht_gallery_slideshow_thumbs').is(':checked')) {
        	$('.cmb_id__ht_gallery_slideshow_thumbs_orien').show();
    	} else {
			$('.cmb_id__ht_gallery_slideshow_thumbs_orien').hide();
		}
	}

})