<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<?php endwhile; // end of the loop. ?>

<?php if ( !post_password_required( get_the_ID() ) ) { ?>

<?php $ht_gallery_type = get_post_meta( get_the_id(), '_ht_gallery_type', true );
if ( $ht_gallery_type == 'grid-landscape' || $ht_gallery_type == 'grid-portrait' || $ht_gallery_type == 'grid-square'  ) {
	get_template_part( 'templates/htgallery', 'grid' );
} elseif ( $ht_gallery_type == 'carousel'  ) {
	get_template_part( 'templates/htgallery', 'carousel' );
} elseif ( $ht_gallery_type == 'slideshow'  ) {
	get_template_part( 'templates/htgallery', 'slideshow' );
} elseif ( $ht_gallery_type == 'horizontal'  ) {
	get_template_part( 'templates/htgallery', 'horizontal' );
} else {
	get_template_part( 'templates/htgallery', 'horizontal' );
} ?>

<?php 
// Get gallery ID
if ( is_page_template('template-homepage.php') ) {
	$ht_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
} else {
	$ht_gallery_ID = get_the_ID();
}
$ht_gallery_slideshow_fullscreen = get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_full', true );
if ( !empty($ht_gallery_slideshow_fullscreen) ) {
	$ht_gallery_slideshow_fullscreen = 'on';
} else {
	$ht_gallery_slideshow_fullscreen = 'off';
}
if ( $ht_gallery_slideshow_fullscreen != 'on' ) { ?>

<!-- #primary -->
<section id="primary" class="sidebar-off clearfix">

<!-- #content -->
<div id="content" role="main">

<?php while ( have_posts() ) : the_post(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>    

	<h1 class="entry-title"><?php the_title(); ?></h1>

	<div class="entry-content clearfix">
	<?php the_content(); ?>
	</div>

</article>

<?php endwhile; // end of the loop. ?>

<!-- #gallery-related -->
<?php $related = ht_get_posts_related_by_taxonomy($post->ID, 'ht_gallery_category');
if( $related->have_posts() ) : ?>	

<section id="gallery-related" class="clearfix">
                        
<h3 id="gallery-related-title"><?php _e( 'Related Galleries', 'framework' ); ?></h3>  
	<ul class="clearfix">

<?php while( $related->have_posts() ) : $related->the_post(); ?>
<?php
// Get gallery images 
$ht_homepage_gallery_image = get_post_meta( get_the_ID(), '_ht_gallery_starred_image', true );
if ( $ht_homepage_gallery_image == '' ) {
	$ht_homepage_gallery = get_post_meta( get_the_ID(), '_ht_gallery_images', true );
	$ht_homepage_gallery = explode(",", $ht_homepage_gallery);
	$ht_homepage_gallery_image = count( $ht_homepage_gallery ) > 0 ? $ht_homepage_gallery[0] : null;
}
?>

<li>
<figure class="gallery-thumb">
<?php echo wp_get_attachment_image( $ht_homepage_gallery_image, 'width=400&height=300&crop=resize' ); ?>
<?php $ht_the_excerpt = get_the_excerpt(); ?>
	<?php if ( $ht_the_excerpt != '' ) {  ?>
		<figcaption class="with-excerpt">
	<?php } else { ?>
		<figcaption>
	<?php } ?>
		<a href="<?php the_permalink(); ?>"> 
			<h2 class="overlay-title"><?php the_title(); ?></h2>
		</a>
		<?php if ( $ht_the_excerpt != '' ) { ?>
			<p class="overlay-caption"><?php echo $ht_the_excerpt; ?></p>
		<?php } ?>
		</figcaption>
</figure>   
</li>	
<?php endwhile; ?>
	</ul>
</section>
<?php endif; wp_reset_postdata(); ?>
<!-- /#gallery-related -->


</div>
<!-- #content -->

</section>
<!-- /#primary -->

<?php } ?>

<?php } else { ?>

<!-- #primary, .container -->
<div id="primary" class="sidebar-off clearfix">
<div class="ht-container">

<!-- #content -->
<main id="content" class="clearfix" role="main" itemprop="mainContentOfPage">

<!-- .entry-content -->
<div class="entry-content password-protected clearfix">
<h1><?php the_title(); ?></h1>   
<?php the_content(); ?>
</div>
<!-- /.entry-content -->

</main>
<!-- #content -->

</div>
</div>
<!-- /#primary -->

<?php } // if password protected ?>

<?php get_footer(); ?>