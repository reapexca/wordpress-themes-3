<?php
// Get gallery ID
if ( is_page_template('template-homepage.php') ) {
	$ht_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
} else {
	$ht_gallery_ID = get_the_ID();
}
// Get gallery array
$ht_gallery = ht_gallery_get_gallery($ht_gallery_ID);

// Get gallery options
$ht_gallery_slideshow_fullscreen =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_full', true );
$ht_gallery_img_title =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_titles', true );
$ht_gallery_img_caption =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_caption', true );
$ht_gallery_type = get_post_meta( $ht_gallery_ID, '_ht_gallery_type', true );
?>

<?php if ( $ht_gallery ) { ?>
<div id="ht-gallery-grid" class="clearfix ht-<?php if ($ht_gallery_type != '') { echo $ht_gallery_type; } else { echo 'grid-portrait'; }; ?>">
<ul class="clearfix">
<?php foreach ($ht_gallery as $gallery_image) { ?>
<?php $gallery_image_full_src = wp_get_attachment_image_src( $gallery_image['id'], 'gallery-full' ); ?>
<li class="animated fadeInUp">

<?php if ( !empty($gallery_image['video_url']) )  { ?>
	<figure class="gallery-thumb with-vid">   
    <?php 
	if ( $ht_gallery_type == 'grid-portrait' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=300&height=400&crop=resize-crop' );
	} elseif ( $ht_gallery_type == 'grid-landscape' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=500&height=300&crop=resize-crop' );
	} elseif ( $ht_gallery_type == 'grid-square' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=400&height=400&crop=resize-crop' );
	} else {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=300&height=400&crop=resize-crop' );
	}
	?>    
    <figcaption>
    	<span><h2><?php echo $gallery_image['title']; ?></h2></span>
        <a class="ht-lightbox mfp-iframe" href="<?php echo $gallery_image['video_url']; ?>" title="<?php echo $gallery_image['title']; ?>"><i class="fa fa-play"></i></a>
	</figcaption>
    </figure>
<?php } else { ?>

	<figure class="gallery-thumb">    
    <?php 
	if ( $ht_gallery_type == 'grid-portrait' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=300&height=400&crop=resize-crop' );
	} elseif ( $ht_gallery_type == 'grid-landscape' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=500&height=300&crop=resize-crop' );
	} elseif ( $ht_gallery_type == 'grid-square' ) {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=400&height=400&crop=resize-crop' );
	} else {
		echo wp_get_attachment_image( $gallery_image['id'], 'width=300&height=400&crop=resize-crop' );
	}
	?>    
    <figcaption>
    	<span><h2><?php echo $gallery_image['title']; ?></h2></span>
        <a class="ht-lightbox mfp-image" href="<?php echo $gallery_image_full_src[0]; ?>" title="<?php echo $gallery_image['title']; ?>"><i class="fa fa-expand"></i></a>
	</figcaption>
    
	</figure>
    
<?php } ?>
    
</li> 
<?php } // end foreach ?>
</ul>
</div>
<?php } // end if $ht_homepage_gallery ?>