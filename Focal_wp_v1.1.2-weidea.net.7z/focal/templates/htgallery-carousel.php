<?php
// Get gallery ID
if ( is_page_template('template-homepage.php') ) {
	$ht_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
} else {
	$ht_gallery_ID = get_the_ID();
}
// Get gallery array
$ht_gallery = ht_gallery_get_gallery($ht_gallery_ID);

// Get Gallery options
$ht_gallery_slideshow_fullscreen =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_full', true );
$ht_gallery_img_title =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_titles', true );
$ht_gallery_img_caption =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_caption', true ); ?>

<?php ht_gallery_carousel_script($ht_gallery_ID); ?>

<?php if ( $ht_gallery ) { ?>
<div id="ht-gallery-carousel" class="royalSlider rsDefault">
<?php foreach ($ht_gallery as $gallery_image) { ?>
<?php 
// Set gallery image sizes
$gallery_image_320 = wp_get_attachment_image_src( $gallery_image['id'], 'width=320&height=0&crop=resize-crop' );
$gallery_image_480 = wp_get_attachment_image_src( $gallery_image['id'], 'width=480&height=0&crop=resize-crop' );
$gallery_image_600 = wp_get_attachment_image_src( $gallery_image['id'], 'width=600&height=0&crop=resize-crop' );
$gallery_image_920 = wp_get_attachment_image_src( $gallery_image['id'], 'width=920&height=0&crop=resize-crop' );
$gallery_image_1200 = wp_get_attachment_image_src( $gallery_image['id'], 'width=1200&height=0&crop=resize-crop' );
?>

<div class="rsContent">

	<img alt="" class="rsImg" src="<?php echo $gallery_image_320[0]; ?>" 
    data-image-320="<?php echo $gallery_image_320[0]; ?>"
    data-image-480="<?php echo $gallery_image_480[0]; ?>"
    data-image-600="<?php echo $gallery_image_600[0]; ?>"
    data-image-920="<?php echo $gallery_image_920[0]; ?>"
    data-image-1200="<?php echo $gallery_image_1200[0]; ?>"
    <?php if ( !empty($gallery_image['video_url']) )  { ?>data-rsVideo="<?php echo $gallery_image['video_url']; ?>"<?php } ?> /> 

<?php if ( $ht_gallery_img_title == 'on' || $ht_gallery_img_caption == 'on' ) { ?>     
	<?php if ( !empty($gallery_image['title']) || !empty($gallery_image['caption']) ) { ?>
        <div class="ht-gallery-caption">
        <?php if ($ht_gallery_img_title == 'on') { ?><h2><?php echo $gallery_image['title']; ?></h2><?php } ?>
        <?php if (!empty($gallery_image['caption']) && $ht_gallery_img_caption == 'on') { ?><p><?php echo $gallery_image['caption']; ?></p><?php } ?>
        </div> 
    <?php } ?>
<?php } ?>
</div>

<?php } // end foreach ?>
</div> 
<?php } // end if $ht_homepage_gallery ?>