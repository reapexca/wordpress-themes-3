<?php
// Get gallery ID
if ( is_page_template('template-homepage.php') ) {
    $ht_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
} else {
    $ht_gallery_ID = get_the_ID();
}
// Get gallery array
$ht_gallery = ht_gallery_get_gallery($ht_gallery_ID);

// Get Gallery options
$ht_gallery_slideshow_fullscreen =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_full', true );
$ht_gallery_img_title =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_titles', true );
$ht_gallery_img_caption =  get_post_meta( $ht_gallery_ID, '_ht_gallery_img_caption', true ); ?>

<?php if ($ht_gallery && count( $ht_gallery ) == 1) { ?>

    <div id="single-image-gallery-header">
    <?php foreach ($ht_gallery as $gallery_image) { ?>
        <?php 
    // Get gallery image meta
    $gallery_image_full_src = wp_get_attachment_image_src( $gallery_image['id'], 'full' );
    ?>
    <?php echo wp_get_attachment_image( $gallery_image['id'], 'height=500&crop=resize-crop' ); ?>
    <a href="<?php echo $gallery_image_full_src[0] ?>" class="gallery-fullscreen"><i class="fa fa-arrows-alt"></i></a>
    <?php } // end foreach ?>
    </div>

<?php } elseif ($ht_gallery) { ?>

    <div id="single-gallery-header">
    <ul class="clearfix">
    <?php foreach ($ht_gallery as $gallery_image) { ?>

    <?php 
    // Get gallery image meta
    $gallery_image_title = get_post_field('post_title', $gallery_image['id']);
    $gallery_image_caption = get_post_field('post_excerpt', $gallery_image['id']);
    $gallery_image_full_src = wp_get_attachment_image_src( $gallery_image['id'], 'full' ); ?>

        <li>
        <?php echo wp_get_attachment_image( $gallery_image['id'], 'gallery-single' ); ?>
        <a href="<?php echo $gallery_image_full_src[0] ?>" class="gallery-fullscreen"><i class="fa fa-arrows-alt"></i></a>
        </li>

    <?php } // end foreach ?>
    </ul>
    </div> 

<?php } // end if $ht_gallery ?>