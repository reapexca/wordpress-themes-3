<?php get_header(); ?>


<!-- #site-subheader -->
<div id="site-subheader">
<div class="ht-container">
<span class="gallery-filter-title"><?php _e( 'Filter: ', 'framework' ); ?></span>
<ul id="gallery-filter" class="clearfix">
<li class="all">
      <a href="#all" data-filter="isotope-item" class="active">
      <?php _e('All', 'framework'); ?>
      </a></li>
<?php wp_list_categories( array('title_li' => '', 'taxonomy' => 'ht_gallery_category', 'walker' => new HT_Portfolio_Walker() ) ); ?>
</ul>
</div>
</div>
<!-- /#site-subheader -->


<?php	$args = array(
			'post_type' => 'ht_gallery_post',
			'posts_per_page' => '-1',
			'order' => 'ASC',
			'orderby' => 'menu_order'
		);
$wp_query = new WP_Query($args);
if($wp_query->have_posts()) : ?>

<div id="isotope-container">

<?php while($wp_query->have_posts()) : $wp_query->the_post(); ?>
<?php
// Get gallery images 
$ht_gallery_image = get_post_meta( get_the_ID(), '_ht_gallery_starred_image', true );
if ( $ht_gallery_image == '' ) {
	$ht_gallery = get_post_meta( get_the_ID(), '_ht_gallery_images', true );
	$ht_gallery = is_a($ht_gallery, 'WP_Error') ? array() : explode(",", $ht_gallery);
	$ht_gallery_image = count( $ht_gallery ) > 0 ? $ht_gallery[0] : null;
}
?>
<?php // Get portfolio categories for isotope
		$terms =  get_the_terms( $post->ID, 'ht_gallery_category' ); 
		$term_list = '';
		if( is_array($terms) ) {
			foreach( $terms as $term ) {
				$term_list .= urldecode($term->slug);
				$term_list .= ' ';
			}
		}
?>

<div class="isotope-item <?php echo $term_list ?>">
<figure class="gallery-thumb">

<?php echo wp_get_attachment_image( $ht_gallery_image, 'width=500&height=400&crop=resize' ); ?>
<?php $ht_the_excerpt = get_the_excerpt(); ?>
<?php if ( $ht_the_excerpt != '' ) {  ?>
<figcaption class="with-excerpt">
<?php } else { ?>
<figcaption>
<?php } ?>
<?php ?>
   <a href="<?php the_permalink(); ?>"> 
        <h2 class="overlay-title"><?php the_title(); ?></h2>
   </a> 
<?php if ( $ht_the_excerpt != '' ) { ?>
<p class="overlay-caption"><?php echo $ht_the_excerpt; ?></p>
<?php } ?>
</figcaption>

</figure>
</div> 

<?php endwhile; ?>
</div>
<?php endif; ?>

<?php get_footer(); ?>