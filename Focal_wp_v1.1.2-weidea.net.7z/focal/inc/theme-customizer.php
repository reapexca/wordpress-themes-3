<?php

/**
 * Adds the individual sections, settings, and controls to the theme customizer
 */
function ht_customizer( $wp_customize ) {
	
	/**
 	* Adds textarea support to the theme customizer
 	*/
	class ht_Customize_Textarea_Control extends WP_Customize_Control {
    public $type = 'textarea';
 
    public function render_content() {
        ?>

<label> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
  <textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
</label>
<?php
    }
}
	
class Category_Dropdown_Custom_Control extends WP_Customize_Control {
  public function render_content() {

    //ht gallery
	$hero_galleries = apply_filters( 'get_ht_galleries', array() );           

    $options = '';
      foreach($hero_galleries as $hero_gallery) {
		$is_selected = ( $hero_gallery == $this->value() ) ? 'selected="selected"' : '';
		$options.= sprintf("\t".'<option value="%1$s '.$is_selected.'">%2$s</option>'."\n", $hero_gallery['id'], $hero_gallery['name']);
        }

?>
<label> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
<select id="<?php echo $this->id; ?>" name="<?php echo $this->id; ?>" <?php $this->link(); ?> >
<?php echo $options; ?>	        
</select>
<?php }
}	
	
	
	
	/**
 	* Header Section
 	*/
	$wp_customize->add_section('ht_header', array(
		'title' => __( 'Header', 'framework' ),
		'description' => '',
		'priority' => 30,
	) );
	
	$wp_customize->add_setting( 'blogname', array(
		'default'    => get_option( 'blogname' ),
		'type'       => 'option',
		'capability' => 'manage_options',
	) );

	$wp_customize->add_control( 'blogname', array(
		'label'      => __( 'Site Title', 'framework' ),
		'section'    => 'ht_header',
	) );

	$wp_customize->add_setting( 'blogdescription', array(
		'default'    => get_option( 'blogdescription' ),
		'type'       => 'option',
		'capability' => 'manage_options',
	) );

	$wp_customize->add_control( 'blogdescription', array(
		'label'      => __( 'Tagline', 'framework' ),
		'section'    => 'ht_header',
	) );
	
	
	// Add logo to Site Title & Tagline Section
	$wp_customize->add_setting( 'ht_site_logo', array('default' => get_template_directory_uri() . '/images/logo.png') );
 
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ht_site_logo', array(
		'label' => __( 'Site Logo' , 'framework' ),
		'section' => 'ht_header',
		'settings' => 'ht_site_logo')
	) );

	
	/**
 	* Footer Section
 	*/
    $wp_customize->add_section('ht_footer', array(
		'title' => __( 'Footer' , 'framework' ),
		'description' => '',
		'priority' => 35,
	));
	
	// site coypright
	$wp_customize->add_setting( 'ht_copyright', array(
		'default' => '&copy; Copyright A Hero Theme.',
	));
	 
	$wp_customize->add_control( new ht_Customize_Textarea_Control( $wp_customize, 'ht_copyright', array(
		'label'   => __( 'Site Copyright' , 'framework' ),
		'section' => 'ht_footer',
		'settings'   => 'ht_copyright',
		'priority' => 0,
	)));
	
	// RSS Option
	$wp_customize->add_setting('ht_footer_rss');

	$wp_customize->add_control('ht_footer_rss',	array(
		'type' => 'checkbox',
		'label' => __( 'Hide RSS Link' , 'framework' ),
		'section' => 'ht_footer',
		'priority' => 1,
	));
	
	// Email Option
	$wp_customize->add_setting('ht_footer_email');

	$wp_customize->add_control('ht_footer_email',	array(
		'type' => 'text',
		'label' => __( 'Email Link', 'framework' ),
		'section' => 'ht_footer',
	));
	
	// Twitter Option
	$wp_customize->add_setting('ht_footer_twitter');

	$wp_customize->add_control('ht_footer_twitter',	array(
		'type' => 'text',
		'label' => __( 'Twitter Link', 'framework' ),
		'section' => 'ht_footer',
	));
	
	// Facebook Option
	$wp_customize->add_setting('ht_footer_facebook');

	$wp_customize->add_control('ht_footer_facebook', array(
		'type' => 'text',
		'label' => __( 'Facebook Link', 'framework' ),
		'section' => 'ht_footer',
	));
	
	// Google+ Option
	$wp_customize->add_setting('ht_footer_google');

	$wp_customize->add_control('ht_footer_google',	array(
		'type' => 'text',
		'label' => __( 'Google+ Link' , 'framework' ),
		'section' => 'ht_footer',
	));
	
	// Pinterest Option
	$wp_customize->add_setting('ht_footer_pinterest');

	$wp_customize->add_control('ht_footer_pinterest',	array(
		'type' => 'text',
		'label' => __( 'Pinterest Link' , 'framework' ),
		'section' => 'ht_footer',
	));
	
	// LinkedIn Option
	$wp_customize->add_setting('ht_footer_linkedin');

	$wp_customize->add_control('ht_footer_linkedin',	array(
		'type' => 'text',
		'label' => __( 'LinkedIn Link', 'framework' ),
		'section' => 'ht_footer',
	));
	
	// Flickr Option
	$wp_customize->add_setting('ht_footer_flickr');

	$wp_customize->add_control('ht_footer_flickr',	array(
		'type' => 'text',
		'label' => __( 'Flickr Link', 'framework' ),
		'section' => 'ht_footer',
	));
	
	
	 // Homepage Section
    $wp_customize->add_section( 'ht_homepage', array(
		'title' => __( 'Homepage', 'framework' ),
		'description' => '',
		'priority' => 50,
	));	

	// Gallery Chooser
	$wp_customize->add_setting( 'ht_homepage_gallery', array('default' => '') );

    $wp_customize->add_control( new Category_Dropdown_Custom_Control( $wp_customize, 'ht_homepage_gallery', array(
		'label'    => __( 'Select Homepage Gallery', 'framework' ),
		'section'  => 'ht_homepage',
		'settings' => 'ht_homepage_gallery',

	)));

	/**
 	* Styling Section
 	*/
    $wp_customize->add_section( 'ht_styling', array(
		'title' => __( 'Styling', 'framework' ),
		'description' => __( 'Change the look of the theme.', 'framework' ),
		'priority' => 40,
	) );	

	// theme color option
	$wp_customize->add_setting( 'ht_styling_themecolor', array('default' => '#DD5136') );
 
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ht_styling_themecolor', array(
        'label'   => __( 'Theme Color', 'framework' ),
        'section' => 'ht_styling',
        'settings'   => 'ht_styling_themecolor',
	)));

	
}
add_action( 'customize_register', 'ht_customizer' );