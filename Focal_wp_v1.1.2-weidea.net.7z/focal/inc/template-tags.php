<?php

/**
 * Display navigation to next/previous pages when applicable
 */
 
if ( ! function_exists( 'ht_content_nav' ) ):
function ht_content_nav( $nav_id ) {
	global $wp_query;

	$nav_class = 'site-navigation paging-navigation';
	if ( is_single() )
		$nav_class = 'site-navigation post-navigation';

	?>
    <?php if ($wp_query->max_num_pages > 1) { ?>
	<nav role="navigation" id="<?php echo $nav_id; ?>" class="<?php echo $nav_class; ?> clearfix">
<ul class="clearfix">

	<?php if ( is_single() ) : // navigation links for single posts ?>

		<?php previous_poht_link( '<div class="nav-previous">%link</div>', '<span class="meta-nav">' . _x( '<i class="fa fa-angle-left"></i>', 'Previous post link', 'framework' ) . '</span> %title' ); ?>
		<?php next_poht_link( '<div class="nav-next">%link</div>', '%title <span class="meta-nav">' . _x( '<i class="fa fa-angle-right"></i>', 'Next post link', 'framework' ) . '</span>' ); ?>

	<?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>

        <?php if ( get_previous_posts_link() ) : ?>
		<li class="nav-previous"><?php previous_posts_link( __( '<i class="fa fa-chevron-left"></i> Previous Page', 'framework' ) ); ?></li>
		<?php endif; ?>
        
        <?php if ( get_next_posts_link() ) : ?>
		<li class="nav-next"><?php next_posts_link( __( 'Next Page <i class="fa fa-chevron-right"></i>', 'framework' ) ); ?></li>
		<?php endif; ?>

	<?php endif; ?>
</ul>
	</nav><!-- #<?php echo $nav_id; ?> -->
	<?php }
}
endif;

/**
 * The formatted output of a list of pages.
 */
add_action( 'numbered_in_page_links', 'numbered_in_page_links', 10, 1 );

/**
 * Modification of wp_link_pages() with an extra element to highlight the current page.
 *
 * @param  array $args
 * @return void
 */
function numbered_in_page_links( $args = array () )
{
    $defaults = array(
        'before'      => '<p>' . __('Pages:', 'framework'),
		'after'       => '</p>',
		'link_before' => '',   
		'link_after'  => '',
		'pagelink'    => '%',
		'echo'        => 1,
		'highlight'   => 'span'
    );

    $r = wp_parse_args( $args, $defaults );
    $r = apply_filters( 'wp_link_pages_args', $r );
    extract( $r, EXTR_SKIP );

    global $page, $numpages, $multipage, $more, $pagenow;

    if ( ! $multipage )
    {
        return;
    }

    $output = $before;

    for ( $i = 1; $i < ( $numpages + 1 ); $i++ )
    {
        $j       = str_replace( '%', $i, $pagelink );
        $output .= ' ';

        if ( $i != $page || ( ! $more && 1 == $page ) )
        {
            $output .= _wp_link_page( $i ) . "{$link_before}{$j}{$link_after}</a>";
        }
        else
        {   // highlight the current page
            // not sure if we need $link_before and $link_after
            $output .= "<$highlight>{$link_before}{$j}{$link_after}</$highlight>";
        }
    }

    print $output . $after;
}

if ( ! function_exists( 'ht_get_sidebar_position' ) ) :
/**
* Returns the sidebar position class
*
*/
function ht_get_sidebar_position() {

if ( is_home() ) {
    $ht_index_id = get_option('page_for_posts');
    $ht_sidebar_position = get_post_meta( $ht_index_id, '_ht_sidebar_pos', true );
} else {
    $ht_sidebar_position = get_post_meta( get_the_id(), '_ht_sidebar_pos', true );
}

if ($ht_sidebar_position == '') {
    echo 'sidebar-right';
} else {
    echo $ht_sidebar_position;
}
    
}
endif;


if ( ! function_exists( 'ht_get_sidebar' ) ) :
/**
* Returns the sidebar position class
*
*/
function ht_get_sidebar() {

if ( is_home() ) {
    $ht_index_id = get_option('page_for_posts');
    $ht_sidebar_position = get_post_meta( $ht_index_id, '_ht_sidebar_pos', true );
} else {
    $ht_sidebar_position = get_post_meta( get_the_id(), '_ht_sidebar_pos', true );
}

if ( $ht_sidebar_position != 'sidebar-off'  ) {
    return get_sidebar();
}
    
}
endif;