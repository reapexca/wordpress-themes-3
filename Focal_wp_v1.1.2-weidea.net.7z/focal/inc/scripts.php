<?php
/**
 * Enqueues scripts for front-end.
 */
 
function ht_enqueue_scripts() {
	
	/*
	* Load our main theme JavaScript file
	*/
	wp_enqueue_script('ht_theme_custom', get_template_directory_uri() . '/js/functions.js', array( 'jquery.isotope', 'jquery.nicescroll'  ), false, true);
	
	
	// Register Scripts
	wp_register_script('jquery.imagesloaded', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array( 'jquery' ), false, true);
	wp_register_script('jquery.isotope', get_template_directory_uri() . '/js/jquery.isotope.min.js', array( 'jquery', 'jquery.imagesloaded' ), false, true);

	wp_register_script('jquery.nicescroll', get_template_directory_uri() . '/js/jquery.nicescroll.min.js', array( 'jquery' ), false, true);

	// Load Royal Slider
	wp_enqueue_script('jquery.royalslider', get_template_directory_uri() . '/js/jquery.royalslider.min.js', array( 'jquery' ), false, true);
	
	// Load Magnific Popup
	wp_enqueue_script('jquery.magnific-popup', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array( 'jquery' ), false, true);
	
	
	// Isotope Script
	if ( is_post_type_archive('ht_gallery_post') ) {
	wp_enqueue_script( 'jquery.imagesloaded' );
	wp_enqueue_script( 'jquery.isotope' );
	}
	
	// Scroll Script
	if ( 'ht_gallery_post' == get_post_type() ) {
	wp_enqueue_script( 'jquery.nicescroll' );
	wp_enqueue_script( 'jquery.imagesloaded' );
	}
	
	
	/*
	* Adds JavaScript to pages with the comment form to support
	* sites with threaded comments (when in use).
	*/
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
	}
	
	
}
add_action('wp_enqueue_scripts', 'ht_enqueue_scripts');

/**
 * Gallery Scripts
 */
 
// Gallery Carousel
function ht_gallery_carousel_script($ht_gallery_ID) { 

// Get slidehsow options
$ht_gallery_slideshow_fullscreen_btn =  get_post_meta( $ht_gallery_ID, '_ht_gallery_fullscreen_btn', true );
?>
   
<script>
jQuery(document).ready(function($) {
  var slider = $('#ht-gallery-carousel').royalSlider({
    addActiveClass: true,
    arrowsNav: false,
    controlNavigation: 'none',
    autoScaleSlider: true,
	autoScaleSliderWidth: 1000,
	autoScaleSliderHeight: 500, 
    loop: true,
    fadeinLoadedSlide: true,
    globalCaption: false,
    keyboardNavEnabled: true,
    globalCaptionInside: false,
	numImagesToPreload:50,
	imageScaleMode:	'fit',
	
	<?php if ( $ht_gallery_slideshow_fullscreen_btn == 'on' ) { ?>
		fullscreen: {
    		enabled: true,
    		nativeFS: true
    	},
	<?php } ?>

    visibleNearby: {
		enabled: true,
		centerArea: 0.5,
		center: false,
		breakpoint: 650,
		breakpointCenterArea: 0.64,
		navigateByCenterClick: true 
    }
	}).data('royalSlider');

	slider.ev.on('rsAfterContentSet', function(event) {
		$('#ht-gallery-carousel').royalSlider('updateSliderSize', true);
	});

});
</script>
    
<?php }

// Gallery Carousel
function ht_gallery_slideshow_script($ht_gallery_ID) { 

// Get slidehsow options
$ht_gallery_slideshow_thumbs =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_thumbs', true );
$ht_gallery_slideshow_thumbs_orien =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_thumbs_orien', true );
$ht_gallery_slideshow_full =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_full', true );
$ht_gallery_slideshow_imgsizing =  get_post_meta( $ht_gallery_ID, '_ht_gallery_slideshow_imgsizing', true );
$ht_gallery_slideshow_fullscreen_btn =  get_post_meta( $ht_gallery_ID, '_ht_gallery_fullscreen_btn', true );
?>

<script type="text/javascript">
jQuery(document).ready(function($) {
	var slider = $("#ht-gallery-slideshow").royalSlider({
		transitionType: 'fade',
		keyboardNavEnabled: true,
		slidesSpacing: 0,
		loop: true,
		arrowsNav: true,
		arrowsNavAutoHide: false,
		video: {
    		autoHideBlocks: false,
    		autoHideArrows: false
    	},

		
		<?php if ( $ht_gallery_slideshow_imgsizing == 'fit' ) { ?>
			imageScaleMode: 'fit', 
		<?php } else { ?>
			imageScaleMode: 'fill',
		<?php } ?>
		
		<?php if ( $ht_gallery_slideshow_thumbs == 'on' ) { ?>
			controlNavigation: 'thumbnails',
			thumbs: {
				<?php if ( $ht_gallery_slideshow_thumbs_orien == 'vertical' ) { ?>
				orientation: 'vertical',
				<?php } elseif ( $ht_gallery_slideshow_thumbs_orien == 'horizontal' ) { ?>
				orientation: 'horizontal',
				<?php } else { ?>
				orientation: 'vertical',
				<?php } ?>
				autoCenter: false,
				fitInViewport: false,
				paddingBottom: 0,
				spacing: 5,
				arrows: false,
				firstMargin: 0,
				appendSpan: true
			},
		<?php } else { ?>
		controlNavigation: 'none',
		<?php } ?>
		
		<?php if ( $ht_gallery_slideshow_full != 'on' ) { ?>
		autoScaleSlider: true,
		<?php } ?> 
		
		<?php if ( $ht_gallery_slideshow_fullscreen_btn == 'on' ) { ?>
		fullscreen: {
    		enabled: true,
    		nativeFS: true
    	},
		<?php } ?> 
		
		globalCaption: false,
		sliderDrag: true,
		
	}).data('royalSlider'); 
	
	slider.ev.on('rsAfterContentSet', function(event) {
		$('#ht-gallery-slideshow').royalSlider('updateSliderSize', true);
	});
	slider.ev.on('rsBeforeAnimStart', function(event) {
    	htResponsiveSlideshow();
	});
	
});
</script>
    
<?php }

// Add gallery options JS to admin
add_action('admin_init','ht_gallery_meta_js');
function ht_gallery_meta_js() {
  global $pagenow, $typenow;
  if (empty($typenow) && !empty($_GET['post'])) {
    $post = get_post($_GET['post']);
    $typenow = $post->post_type;
  }
  if (is_admin() && $typenow=='ht_gallery_post') {
    if ($pagenow=='post-new.php' OR $pagenow=='post.php') { 
      wp_enqueue_script('my-custom-script', get_template_directory_uri() . "/js/admin-gallery-meta.js",array('jquery'));
    }
  }
}