<?php
/**
* Hero Themes - Core Theme Functions
* by Hero Themes (http://herothemes.com)
*/


/**
* TGM Class
*/
require("libraries/tgm-plugin-activation/class-tgm-plugin-activation.php");

/**
* Load WP Thumb Library
*/
if(current_theme_supports('ht-core', 'wp-thumb' )){
	require("libraries/wpthumb/wpthumb.php");
}

/**
* Load Theme Updates
*/
if(current_theme_supports('ht-core', 'theme-updates' )){
	require_once('libraries/ht-theme-updates/ht-theme-updates.php');
}

/**
 * Initialize the metabox class.
 */
add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'libraries/cmb_meta_boxes/init.php';

}

/**
 * Load Font Awesome
 */
function ht_core_font_awesome() {

	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/inc/ht-core/libraries/font-awesome/css/font-awesome.min.css', array('theme-style') );		
	
}
if(current_theme_supports('ht-core', 'font-awesome' )){
	add_action( 'wp_enqueue_scripts', 'ht_core_font_awesome' );
}
	

/**
* Load Reponsive Image Functions
*/
require("ht-responsive-images.php");

/**
* Load Display Functions
*/
require("ht-display-functions.php");

/*
* add ie conditional html5 shim to header
*/
function ht_core_html5_shim () {
    echo '<!--[if lt IE 9]>';
    echo '<script src="'. get_template_directory_uri() .'/inc/ht-core/js/html5.js"></script>';
    echo '<![endif]-->';
}
add_action('wp_head', 'ht_core_html5_shim');	

/*
* add ie 6-8 conditional selectivizr to header
*/
function ht_core_selectivizr () {
    echo '<!--[if (gte IE 6)&(lte IE 8)]>';
    echo '<script src="'. get_template_directory_uri() .'/inc/ht-core/js/selectivizr-min.js"></script>';
    echo '<![endif]-->';
}
add_action('wp_head', 'ht_core_selectivizr');	

// Allow Shortcodes in widgets
add_filter('widget_text', 'shortcode_unautop');
add_filter('widget_text', 'do_shortcode');

/**
 * Modify Exsisting Widgets
 */ 
 function ht_custom_tag_cloud_widget($args) {
	$args['largest'] = 13; //largest tag
	$args['smallest'] = 8; //smallest tag
	return $args;
}
add_filter( 'widget_tag_cloud_args', 'ht_custom_tag_cloud_widget' );

add_filter('wp_list_categories', 'ht_add_span_cat_count');
function ht_add_span_cat_count($links) {
$links = str_replace('</a> (', '</a> <span>', $links);
$links = str_replace(')', '</span>', $links);
return $links;
}

/*
* Improve default excerpts
*/

// Increase length
function ht_custom_excerpt_length( $length ) {
    return 50;
}
add_filter( 'excerpt_length', 'ht_custom_excerpt_length' );

/*
* Hero Themes HT Core support filter
* Usage (in theme) add_theme_support('ht-core', 'feature1', 'feature2') or add_theme_support('ht')
* Usage (in plugin) current_theme_support('ht-core', 'feature1')
*/
function ht_core_features_filter($support, $features, $theme_supports){	
	if(!is_array($theme_supports))
		return false;
	else
		return !array_diff($features,$theme_supports);	
}
add_filter('current_theme_supports-ht-core', 'ht_core_features_filter', 10, 3);

