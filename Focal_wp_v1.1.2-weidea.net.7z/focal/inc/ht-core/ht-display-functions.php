<?php


if(!function_exists('ht_breadcrumb_display')){
	/**
	 * Breadcrumbs display
	 * @pluggable
	 */
	function ht_breadcrumb_display( $sep = '<span class="sep"> &gt; </span>' ) {
	    global $post;    

	    $homelink = '<a href="' . home_url() . '" class="ht-breadcrumbs-home">' . __('Home') . '</a> ' . $sep; 
		
		if (!is_front_page()) {  
			echo '<div class="ht-breadcrumbs" >';
			
			$visited = array();
				
			 				
			if ( !is_single()  ) {
				echo $homelink;
				if (is_category()) {
 
		            $cat = get_category_parents(get_query_var('cat'), true, $sep);

		            // remove last sep
		            echo substr($cat, 0, strlen($cat) - strlen($sep));
		 
		        }
		 
		        if (is_tax()) {
		 
		            $tag = single_tag_title('', false);
		            $tag = get_tag_id($tag);
		            $term = get_term_parents($tag, get_query_var('taxonomy'), true, $sep);
		 
		            // remove last sep
		            echo substr($term, 0, strlen($term) - strlen($sep));
		        } 

			} elseif ( is_single() ) {
				//Single Post	
				
				$terms = wp_get_post_terms( $post->ID , 'category');


				if( !empty($terms) ){
					foreach($terms as $term) {
						echo $homelink;
						if ($term->parent != 0) { 
							$parents =  get_category_parents($term->term_id, true,'' .$sep . '', false, $visited );
							echo $parents;
						} else {
							echo '<a href="' . esc_attr(get_term_link($term, 'category')) . '" title="' . sprintf( __( "View all posts in %s" ), $term->name ) . '" ' . '>' . $term->name.'</a> ';
							echo $sep;
							$visited[] = $term->term_id;
						}
						echo get_the_title();
						echo '<br/>';

					} // End foreach
				} else {
					//uncategorized post
					echo get_the_title();
					echo '<br/>';
				}		
				
			} else {
					//Display the post title.
					echo get_the_title();
			}
					
			echo '</div>';	
		} //is_front_page
	} //end function
} //end function exists


if(!function_exists('get_term_parents')){
	/**
	 * Get the term parents
	 * @pluggable
	 */
	function get_term_parents( $id, $taxonomy, $link = false, $separator = '/', $nicename = false, $visited = array() ) {
	  $chain = '';
	  $parent = &get_term( $id, $taxonomy );
	  if ( is_wp_error( $parent ) )
	    return $parent;
	  if ( $nicename )
	    $name = $parent->slug;
	  else
	    $name = $parent->name;
	  if ( $parent->parent && ( $parent->parent != $parent->term_id ) && !in_array( $parent->parent, $visited ) ) {
	    $visited[] = $parent->parent;
	    $chain .= get_term_parents( $parent->parent, $taxonomy, $link, $separator, $nicename, $visited );
	  }
	  if ( $link )
	    $chain .= '<a href="' . esc_url( get_term_link( intval( $parent->term_id ), $taxonomy ) ) . '" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $parent->name ) ) . '">'.$name.'</a>' . $separator;
	  else
	    $chain .= $name.$separator;
	  return $chain;
	}//end function
}//end function_exists
