<?php
/**
 * Enqueues styles for front-end.
 */
function ht_theme_styles() {
	global $wp_styles;
	
	/*
	 * Loads our main stylesheet.
	 */
	wp_enqueue_style( 'theme-style', get_template_directory_uri() . '/css/style.css' );
		

	// Add Google font, used in the main stylesheet.
	wp_enqueue_style( 'ht-google-font', ht_google_font_url(), array(), null );

	
	/*
	* Load theme custom colors
	*/
	//Theme variables from theme customizer
	$ht_styling_themecolor = get_theme_mod( 'ht_styling_themecolor', '#DD5136' );
	$ht_styling_themecolor_rgb = get_rgb_from_hex($ht_styling_themecolor);
	
	// Add custom styles
	$custom_css = "
	a, a:visited, a:hover {color: {$ht_styling_themecolor};}

	.entry-meta a {color: {$ht_styling_themecolor};}
	 
	.comment-action i {color: {$ht_styling_themecolor};}
	input[type='submit'], 
	input[type='button'],
	#site-subheader,
	.entry-content blockquote,
	.tags a, 
	.widget_tag_cloud a {
		background: {$ht_styling_themecolor};
	}
	#social-icons li a:hover {
		color: {$ht_styling_themecolor};
	}
	.paging-navigation li a:hover,
	.paging-navigation li a:hover i,
	.readmore:hover {
		color: {$ht_styling_themecolor};
		border-color: {$ht_styling_themecolor};
	}";
	if( $ht_styling_themecolor_rgb && array_key_exists('red', $ht_styling_themecolor_rgb) ) {
		$custom_css = $custom_css . "
		.gallery-thumb figcaption,
		#ht-gallery-grid figure figcaption, 
		#ht-galleries-related figure figcaption {
			background: rgba({$ht_styling_themecolor_rgb['red']},{$ht_styling_themecolor_rgb['green']},{$ht_styling_themecolor_rgb['blue']},0.85); 
		}
		";
	}
	
		
	wp_add_inline_style('theme-style',$custom_css);
		
	
}
add_action( 'wp_enqueue_scripts', 'ht_theme_styles' );

/**
* converts a hex colour to an rgb representation
* returns (array) the RGB values for the parameter hex_colour supplied
*/
function get_rgb_from_hex($hex_colour) {
   $hex_colour = str_replace("#", "", $hex_colour);

   if(strlen($hex_colour) == 6) {
      $red = hexdec(substr($hex_colour,0,2));
      $green = hexdec(substr($hex_colour,2,2));
      $blue = hexdec(substr($hex_colour,4,2));      
   } else {
      //repeat the hex value for shortcode
      $red_hex = substr($hex_colour,0,1);
      $green_hex = substr($hex_colour,1,1);
      $blue_hex = substr($hex_colour,2,1);
      $red = hexdec($red_hex.$red_hex);
      $green = hexdec($green_hex.$green_hex);
      $blue = hexdec($blue_hex.$blue_hex);
   }
   $rgb = array('red' => $red, 'green' => $green, 'blue' => $blue);
   return $rgb; 
}

/**
 * Register Google font
 */
function ht_google_font_url() {
	$font_url = '';
	/*
	 * Translators: If there are characters in your language that are not supported
	 * by this font, translate this to 'off'. Do not translate into your own language.
	 */
	if ( 'off' !== _x( 'on', 'Google font: on or off', 'framework' ) ) {
		$font_url = add_query_arg( 'family', urlencode( 'Montserrat:400|Open+Sans:400,400italic,700' ), "//fonts.googleapis.com/css" );
	}

	return $font_url;
}