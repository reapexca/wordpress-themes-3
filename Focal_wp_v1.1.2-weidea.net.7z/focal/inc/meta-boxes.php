<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'ht_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function ht_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_ht_';
	
	// Get deafult values
	$ht_sidebar_position_default = "sidebar-right";  

	$meta_boxes['ht_metabox_page_options'] = array(
		'id'         => 'ht_metabox_page_options',
		'title'      => __( 'Page Options', 'framework' ),
		'pages'      => array( 'page', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		// 'cmb_styles' => true, // Enqueue the CMB stylesheet on the frontend
		'fields'     => array(
			array(
                'name' => __( 'Sidebar Position', 'framework' ),
                'desc' => __( ' ', 'framework' ),
                'id' => $prefix . 'sidebar_pos',
				'std' => $ht_sidebar_position_default,
                'type' => 'select',
                'options' => array(
                        array( 'name' => __( 'Sidebar Right', 'framework' ), 'value' => 'sidebar-right', ),
                        array( 'name' => __( 'Sidebar Left', 'framework' ), 'value' => 'sidebar-left', ),
                    	array( 'name' => __( 'Sidebar Off', 'framework' ), 'value' => 'sidebar-off', ),
                	),
                ),
		),
	);
	
	$meta_boxes['ht_metabox_gallery_options'] = array(
		'id'         => 'ht_metabox_gallery_options',
		'title'      => __( 'Gallery Options', 'framework' ),
		'pages'      => array( 'ht_gallery_post', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		// 'cmb_styles' => true, // Enqueue the CMB stylesheet on the frontend
		'fields'     => array(
			array(
                'name' => __( 'Gallery Type', 'framework' ),
                'desc' => __( ' ', 'framework' ),
                'id' => $prefix . 'gallery_type',
				'default' => 'slideshow',
                'type' => 'select',
                'options' => array(
                		array( 'name' => __( 'Horizontal', 'framework' ), 'value' => 'horizontal', ),
                        array( 'name' => __( 'Grid Landscape', 'framework' ), 'value' => 'grid-landscape', ),
						array( 'name' => __( 'Grid Portrait', 'framework' ), 'value' => 'grid-portrait', ),
						array( 'name' => __( 'Grid Square', 'framework' ), 'value' => 'grid-square', ),
						array( 'name' => __( 'Slideshow', 'framework' ), 'value' => 'slideshow', ),
                ),
			),
			
			array(
				'name' => __( 'Slideshow - Fullscreen Slider?', 'framework' ),
				'desc' => __( 'This makes the slider take the full width and height of the window. Only the gallery will be visible.', 'framework' ),
				'id' => $prefix . 'gallery_slideshow_full',
				'type' => 'checkbox',
			),
			array(
				'name' => __( 'Slideshow - Show Thumbnails?', 'framework' ),
				'desc' => __( 'Show thumbnail navigation?', 'framework' ),
				'id' => $prefix . 'gallery_slideshow_thumbs',
				'type' => 'checkbox',
			),
			array(
                'name' => __( 'Slideshow Thumbnails - Orientation', 'framework' ),
                'desc' => __( 'Select what orientation to display thumbnails.', 'framework' ),
                'id' => $prefix . 'gallery_slideshow_thumbs_orien',
				'default' => 'vertical',
                'type' => 'select',
                'options' => array(
                        array( 'name' => __( 'Vertical', 'framework' ), 'value' => 'vertical', ),
						array( 'name' => __( 'Horizontal', 'framework' ), 'value' => 'horizontal', ),
                ),
			),
			
			array(
                'name' => __( 'Slideshow - Image Sizing', 'framework' ),
                'desc' => __( 'Fit - Keeps aspect ratio, image fits height of viewport.<br /> Fill - scales image to completely fill slider viewport.', 'framework' ),
                'id' => $prefix . 'gallery_slideshow_imgsizing',
				'default' => 'fit',
                'type' => 'select',
                'options' => array(
                        array( 'name' => __( 'Fit', 'framework' ), 'value' => 'fit', ),
						array( 'name' => __( 'Fill', 'framework' ), 'value' => 'fill', ),
                ),
			),
			array(
				'name' => __( 'Show Titles?', 'framework' ),
				'desc' => __( 'Show Image Titles', 'framework' ),
				'id' => $prefix . 'gallery_img_titles',
				'type' => 'checkbox',
				'default' => 'on',
			),
			array(
				'name' => __( 'Show Captions?', 'framework' ),
				'desc' => __( 'Show Image Captions', 'framework' ),
				'id' => $prefix . 'gallery_img_caption',
				'type' => 'checkbox',
			),
			array(
				'name' => __( 'Show Fullscreen Button', 'framework' ),
				'desc' => __( 'Allow galleries to be shown natively in fullscreen', 'framework' ),
				'id' => $prefix . 'gallery_fullscreen_btn',
				'type' => 'checkbox',
			)
			
			
		),
	);


	// Add other metaboxes as needed

	return $meta_boxes;
}