<?php get_header(); ?>

<div id="site-subheader">
<div class="ht-container">
<strong><?php _e( 'Blog ', 'framework' ); ?></strong>
</div>
</div>
 
<!-- #primary -->
<div id="primary" class="sidebar-right clearfix">
<div class="ht-container">

<!-- #content -->
<div id="content" role="main">

<?php if ( have_posts() ) : ?>

<?php while (have_posts()) : the_post(); ?>

<?php get_template_part( 'content', get_post_format() ); ?>

<?php endwhile; ?>

<?php ht_content_nav( 'nav-below' ); ?>

<?php else : ?>

<?php get_template_part( 'content', 'none' ); ?>

<?php endif; ?>
    
</div>
<!-- #content -->
  
<?php get_sidebar(); ?>

</div>
</div>
<!-- #primary -->
<?php get_footer(); ?>