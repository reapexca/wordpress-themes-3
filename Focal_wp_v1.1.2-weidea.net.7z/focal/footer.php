<!-- #site-footer -->
<footer id="site-footer" class="clearfix">
<div class="ht-container">

<?php if (get_theme_mod( 'ht_copyright' )) { ?>
<small id="copyright" role="contentinfo"><?php echo get_theme_mod( 'ht_copyright' ); ?></small>
<?php } ?>

<?php if (get_theme_mod( 'ht_footer_rss' ) != true || get_theme_mod( 'ht_footer_twitter' ) || get_theme_mod( 'ht_footer_email' ) || get_theme_mod( 'ht_footer_facebook' ) || get_theme_mod( 'ht_footer_google' ) || get_theme_mod( 'ht_footer_pinterest' ) || get_theme_mod( 'ht_footer_linkedin' ) || get_theme_mod( 'ht_footer_flickr' ) ) { ?>
<ul id="social-icons" class="clearfix">
<?php if (get_theme_mod( 'ht_footer_rss' ) != true ) { ?><li class="rss"><a href="<?php bloginfo('rss2_url'); ?>"><i class="fa fa-rss"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_email' ) ) { ?><li class="email"><a href="<?php echo get_theme_mod( 'ht_footer_email' ) ?>"><i class="fa fa-envelope"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_twitter' ) ) { ?><li class="twitter"><a href="<?php echo get_theme_mod( 'ht_footer_twitter' ) ?>"><i class="fa fa-twitter"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_facebook' ) ) { ?><li class="facebook"><a href="<?php echo get_theme_mod( 'ht_footer_facebook' ) ?>"><i class="fa fa-facebook"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_google' ) ) { ?><li class="google-plus"><a href="<?php echo get_theme_mod( 'ht_footer_google' ) ?>"><i class="fa fa-google-plus"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_pinterest' ) ) { ?><li class="pinterest"><a href="<?php echo get_theme_mod( 'ht_footer_pinterest' ) ?>"><i class="fa fa-pinterest"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_linkedin' ) ) { ?><li class="linkedin"><a href="<?php echo get_theme_mod( 'ht_footer_linkedin' ) ?>"><i class="fa fa-linkedin"></i></a></li><?php } ?>
<?php if (get_theme_mod( 'ht_footer_flickr' ) ) { ?><li class="flickr"><a href="<?php echo get_theme_mod( 'ht_footer_flickr' ) ?>"><i class="fa fa-flickr"></i></a></li><?php } ?>
</ul>
<?php } ?>

</div> 
</footer> 
<!-- /#site-footer -->

<?php wp_footer(); ?>

</body>
</html>