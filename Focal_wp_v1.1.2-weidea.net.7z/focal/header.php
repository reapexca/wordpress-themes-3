<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width" />
	<title><?php wp_title('-', true, 'right'); ?><?php bloginfo('name'); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- #header -->
<header id="site-header" class="clearfix" role="banner">
<div class="ht-container">

	<!-- #logo -->
	<div id="logo">
	        <a title="<?php bloginfo( 'name' ); ?>" href="<?php echo home_url(); ?>">
	            <img alt="<?php bloginfo( 'name' ); ?>" src="<?php echo ht_theme_logo(); ?>" />
	            <?php if ( is_front_page() ) { ?>
	            <h1 class="site-title" itemprop="headline"><?php bloginfo( 'name' ); ?></h1>
	            <?php } ?>
	        </a>
	</div>
	<!-- /#logo -->

	<!-- #primary-nav -->
	<?php if ( has_nav_menu( 'primary-nav' ) ) { ?>
	<nav id="nav-primary" class="clearfix">
	<?php wp_nav_menu( array('theme_location' => 'primary-nav', 'container' => false, 'menu_class' => 'nav clearfix' )); ?>
	</nav>

	<!-- #navbar-toggle -->
	<button id="navbar-toggle" type="button"><i class="fa fa-bars"></i> <?php _e('Menu','framework'); ?></button>
	<!-- /#navbar-toggle -->
	<?php } ?> 
	<!-- #primary-nav -->

</div>
</header>
<!-- /#header -->