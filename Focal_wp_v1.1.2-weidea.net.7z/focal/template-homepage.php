<?php
/*
Template Name: Homepage
*/
?>
<?php get_header(); ?>

<?php $ht_homepage_gallery_ID = get_theme_mod( 'ht_homepage_gallery' );
$ht_gallery_type = get_post_meta( $ht_homepage_gallery_ID, '_ht_gallery_type', true );
if ( $ht_gallery_type == 'grid-landscape' || $ht_gallery_type == 'grid-portrait' || $ht_gallery_type == 'grid-square'  ) {
	get_template_part( 'templates/htgallery', 'grid' );
} elseif ( $ht_gallery_type == 'carousel'  ) {
	get_template_part( 'templates/htgallery', 'carousel' );
} elseif ( $ht_gallery_type == 'slideshow'  ) {
	get_template_part( 'templates/htgallery', 'slideshow' );
} elseif ( $ht_gallery_type == 'horizontal'  ) {
	get_template_part( 'templates/htgallery', 'horizontal' );
} else {
	get_template_part( 'templates/htgallery', 'horizontal' );
} ?>

<?php get_footer(); ?>