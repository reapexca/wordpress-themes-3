<?php
function ait_econtent( $params ) {
    
}

add_shortcode( "ait-econtent", "ait_econtent" );