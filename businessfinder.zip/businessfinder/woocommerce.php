<?php

WPLatte::createTemplate(__FILE__, $latteParams)->render();