				</div><!--content-inner-->
			</div><!--content-outer-->
		</div><!--main-wrapper-->
	</div><!--wrapper-->
	<div id="footer-wrapper">
		<div id="footer">
			<div id="footer-nav">
				<?php wp_nav_menu(array('theme_location' => 'footer-menu')); ?>
			</div><!--footer-nav-->
			<div id="copyright">
				<p><?php echo get_option('gd_copyright'); ?></p>
			</div><!--copyright-->
		</div><!--footer-->
	</div><!--footer-wrapper-->
</div><!--site-->

<?php wp_footer(); ?>

</body>
</html>