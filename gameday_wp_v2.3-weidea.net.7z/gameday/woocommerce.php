<?php get_header(); ?>

<div id="main">
	<div id="post-area" <?php post_class(); ?>>
		<div id="woo-content">
			<?php woocommerce_content(); ?>
			<?php wp_link_pages(); ?>
		</div><!--woo-content-->
	</div><!--post-area-->
	<?php get_sidebar('woo'); ?>

</div><!--main -->


<?php get_footer(); ?>