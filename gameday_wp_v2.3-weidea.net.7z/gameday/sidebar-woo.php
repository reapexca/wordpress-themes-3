<div id="sidebar-wrapper">
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('WooCommerce Sidebar Widget Area')): endif; ?>
</div><!--sidebar-wrapper-->