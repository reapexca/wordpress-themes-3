<?php 
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; ?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="search-filter-wrapper">
				<form role="search" method="get" id="searchform" class="search-form" action="<?php echo esc_url(home_url('/')) ?>">

	                <div class="post-categories">
						<select name="cat_dropdown">
							<option value=""><?php esc_html_e('Select Category', 'markety');?></option>
							<?php 
								$categories = get_categories( array( 
									'orderby' 		=> 'name',
									'parent'  		=> 0
								));
								foreach ( $categories as $category ) : ?>
									<option value="<?php echo esc_attr($category->category_nicename); ?>"><?php echo esc_html($category->cat_name); ?></option>
								<?php endforeach;
							?>
						</select>
	                </div> <!-- .post-categories -->

	                <div class="post-tags">
	                	<select name="tag_dropdown">
							<option value=""><?php esc_html_e('Select Tag', 'markety');?></option>
							<?php 
								$tags = get_tags( array( 
									'orderby' 		=> 'name',
									'parent'  		=> 0
								));
								foreach ( $tags as $tag ) : ?>
									<option value="<?php echo esc_attr($tag->slug); ?>"><?php echo esc_html($tag->name); ?></option>
								<?php endforeach;
							?>
						</select>
	                </div>

	                <div class="post-orderby">
	                	<select name="post_orderby">
	                		<option value="none"><?php esc_html_e('None', 'markety')?></option>
	                		<option value="id"><?php esc_html_e('ID', 'markety')?></option>
	                		<option value="author"><?php esc_html_e('Author', 'markety')?></option>
	                		<option value="title"><?php esc_html_e('Title', 'markety')?></option>
	                		<option value="name"><?php esc_html_e('Name', 'markety')?></option>
	                		<option value="date" selected><?php esc_html_e('Date', 'markety')?></option>
	                		<option value="modified"><?php esc_html_e('Modified', 'markety')?></option>
	                		<option value="parent"><?php esc_html_e('Parent', 'markety')?></option>
	                		<option value="rand"><?php esc_html_e('Rand', 'markety')?></option>
	                		<option value="comment_count"><?php esc_html_e('Comment Count', 'markety')?></option>
	                		<option value="menu_order"><?php esc_html_e('Menu Order', 'markety')?></option>
	                	</select>
	                </div>

	                <div class="post-order">
	                	<select name="post_order">
	                		<option value="asc"><?php esc_html_e('ASC', 'markety')?></option>
	                		<option value="desc" selected><?php esc_html_e('DESC', 'markety')?></option>
	                	</select>
	                </div>

			        <div class="post-search">
			        	<input type="text" class="form-control" value="<?php echo get_search_query() ?>" name="s" id="s" placeholder="<?php esc_attr_e('Search', 'markety')?>"/>
				        <button type="submit"><i class="fa fa-search"></i></button>
				        <input type="hidden" value="post" name="post_type" id="post_type" />
			        </div>
			    </form>
			</div>
		</div>
	</div>
</div>