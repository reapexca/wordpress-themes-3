<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<?php $page_template = get_post_meta(get_queried_object_id(), '_wp_page_template', true); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <header class="entry-header">
        <?php if ($page_template == 'page-templates/blog-grid.php' || $page_template == 'page-templates/blog-grid-left-sidebar.php' || $page_template == 'page-templates/blog-grid-right-sidebar.php' || $page_template == 'page-templates/blog-grid-home.php') : ?>
            
            <!-- author avatar for grid layout -->
            <div class="post-author">
                <?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'markety_grid_post_author_size', 60 ) ); ?>
            </div>
        <?php endif; ?>

        <?php if (function_exists('rwmb_meta')) :
            $video_mp4 = rwmb_meta( 'markety_featured_mp4', 'type=file_input' );
            $video_webm = rwmb_meta( 'markety_featured_webm', 'type=file_input' );
            $video_ogv = rwmb_meta( 'markety_featured_ogv', 'type=file_input' );
            // $embed_video = rwmb_meta( 'markety_embed_video', 'type=oembed' );
            $embed_video = rwmb_meta( 'markety_embed_video');
                    
            if ( !empty($embed_video) or !empty($video_mp4) or !empty($video_webm) or !empty($video_ogv) ) : ?>
                <div class="post-thumbnail blog-video">
                    <div class="embed-responsive embed-responsive-16by9">
                        <?php
                            if ($embed_video and (empty($video_mp4) or empty($video_webm) or empty($video_ogv))) :

                                echo rwmb_meta( 'markety_embed_video');

                            elseif (!empty($video_mp4) or !empty($video_webm) or !empty($video_ogv)) : ?>
                                <video preload="auto" controls="controls">
                                    <?php if (!empty($video_mp4)) : ?>
                                        <source src="<?php echo esc_url($video_mp4); ?>" type="video/mp4"/>
                                    <?php endif; ?>

                                    <?php if (!empty($video_webm)) : ?>
                                        <source src="<?php echo esc_url($video_webm); ?>" type="video/webm"/>
                                    <?php endif; ?>

                                    <?php if (!empty($video_ogv)) : ?>
                                        <source src="<?php echo esc_url($video_ogv); ?>" type="video/ogv"/>
                                    <?php endif; ?>
                                </video>
                            <?php 
                            endif; 
                        ?>
                    </div>
                </div>
            <?php endif; 
        endif;
        ?>

        <?php if ($page_template == 'page-templates/blog-grid.php' || $page_template == 'page-templates/blog-grid-left-sidebar.php' || $page_template == 'page-templates/blog-grid-right-sidebar.php' || $page_template == 'page-templates/blog-grid-home.php') : 

            // post meta for grid layout
            markety_grid_posted_on();

        endif; ?>
    </header><!-- .entry-header -->

    <div class="blog-content">
        <div class="entry-header">
            <?php
                if ( is_single() ) :
                    the_title( '<h2 class="entry-title">', '</h2>' );
                else :
                    the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
                endif;
            ?>

            <?php if (! $page_template == 'page-templates/blog-grid.php' || ! $page_template == 'page-templates/blog-grid-left-sidebar.php' || ! $page_template == 'page-templates/blog-grid-right-sidebar.php' || ! $page_template == 'page-templates/blog-grid-home.php') : 

                // post meta for grid layout
                markety_posted_on();

            endif; ?>
        </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                if (is_single() || !has_excerpt()) :
                    the_content( '<span class="readmore">' . esc_html__( 'Read More', 'markety' ) . '</span>' );
                else :
                    the_excerpt();
                endif;

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'markety') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->


    <footer class="entry-footer clearfix">
        <ul class="entry-meta">
            <?php if (!is_single()): ?>

                <li>
                    <span class="post-comments">
                        <?php
                            comments_popup_link(
                                esc_html__('0', 'markety'),
                                esc_html__('1', 'markety'),
                                esc_html__('%', 'markety'), '',
                                esc_html__('Comments are Closed', 'markety')
                            ); 
                        ?>
                    </span>
                </li>

                <?php if (function_exists('zilla_likes')) : ?>
                    <li>
                        <span class="likes">
                            <?php zilla_likes(); ?>
                        </span>
                    </li>
                <?php endif; ?>

            <?php else : ?>
                <?php if (function_exists('zilla_likes')) : ?>
                    <li>
                        <span class="likes">
                            <?php zilla_likes(); ?>
                        </span>
                    </li>
                <?php endif; ?>
                <?php if (markety_option('show-share-button', false, true)): ?>
                    <li class="share"><span><i class="fa fa-share"></i> <?php esc_html_e('Share', 'markety');?></span>
                        <?php get_template_part( 'template-parts/post', 'share'); ?>
                    </li>
                <?php endif; ?>
                
            <?php endif; ?>
        </ul>

       <?php if (is_single()): ?>
            <div class="post-tags">
                <?php $tags_list = get_the_tag_list('', esc_html__(' ', 'markety'));
                    if ($tags_list) : ?>
                        <span class="tags-links">
                            <?php printf(esc_html__('%1$s', 'markety'), $tags_list); ?>
                        </span>
                    <?php endif; 
                ?>
            </div> <!-- .post-tags -->
        <?php endif; ?>
    </footer>
</article>