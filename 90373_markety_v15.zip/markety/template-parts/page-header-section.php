<?php 
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; 


$content_alignment = "";
$margin_bottom = "";
$padding_top = "";
$padding_bottom = "";
$header_background = 'background-image: url('.esc_url(markety_page_header_background()).');';
$parallax_background = "";
$content_color = "";

if (function_exists('rwmb_meta')) : 
    $content_alignment = rwmb_meta('markety_breadcrumb_content_alignment');
    if (rwmb_meta('markety_page_header_margin_bottom')) :
        $margin_bottom = 'margin-bottom: '.rwmb_meta('markety_page_header_margin_bottom').';';
    endif;
    if (rwmb_meta('markety_header_padding_top')) :
        $padding_top = 'padding-top: '.rwmb_meta('markety_header_padding_top').';';
    endif;
    if (rwmb_meta('markety_header_padding_bottom')) :
        $padding_bottom = 'padding-bottom: '.rwmb_meta('markety_header_padding_bottom').';';
    endif;

    // background options
    if (rwmb_meta('markety_page_header_color')) :
        $header_background = 'background-color: '.rwmb_meta('markety_page_header_color').';';
    endif;

    // parallax background
    if (rwmb_meta('markety_parallax_header_image') == 'parallax_header_bg') :
        $parallax_background = "data-stellar-background-ratio= 0.1";
    endif;

    // content color
    if (rwmb_meta('markety_header_content_color')) :
        $content_color = 'color: '.rwmb_meta('markety_header_content_color').';';
    endif;
endif; ?>

<!--page title start-->
<section class="page-title <?php echo esc_attr($content_alignment)?>" <?php echo esc_attr($parallax_background);?> style="<?php echo esc_attr($header_background.' '.$margin_bottom.' '.$padding_top.' '.$padding_bottom); ?> "  role="banner">
    
    <?php if (function_exists('rwmb_meta')) : 
        if (rwmb_meta('markety_background_overlay') == 'bg_overlay_enable') : ?>
            <div class="title-overlay-color"></div>
        <?php endif;
    endif; ?>

    <div class="container">
        <h2 style="<?php echo esc_attr($content_color); ?>"><?php echo esc_html( markety_page_header_section_title() ); ?></h2>
		<?php
			if (function_exists('rwmb_meta') and rwmb_meta('markety_page_subtitle')) : ?>
				<span style="<?php echo esc_attr($content_color); ?>"><?php echo esc_html(rwmb_meta('markety_page_subtitle'));?></span>
			<?php endif;
		?>

		<?php if(function_exists('rwmb_meta') and rwmb_meta('markety_page_breadcrumb_show') == 'page_breadcrumb_show') : ?>
            <div class="tt-breadcrumb" style="<?php echo esc_attr($content_color); ?>">
                <?php markety_breadcrumbs(); ?>
            </div>
		<?php endif; ?>
    </div><!-- .container -->
</section> <!-- page-title -->