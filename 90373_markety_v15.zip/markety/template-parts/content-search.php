<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; ?>

<?php $page_template = get_post_meta(get_queried_object_id(), '_wp_page_template', true); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <div class="blog-content">
        <div class="entry-header">
            <?php
                if ( is_single() ) :
                    the_title( '<h2 class="entry-title" itemprop="headline">', '</h2>' );
                else :
                    the_title( sprintf( '<h2 class="entry-title" itemprop="headline"><a href="%s" rel="bookmark" itemprop="url">', esc_url( get_permalink() ) ), '</a></h2>' );
                endif;
            ?>

            <?php markety_posted_on();?>

        </div><!-- /.entry-header -->

        <div class="entry-content" itemprop="description">
            <?php 
                if (is_single() || !has_excerpt()) :
                    the_content( '<span class="readmore">' . esc_html__( 'Read More', 'markety' ) . '</span>' );
                else :
                    the_excerpt();
                endif;

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'markety') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->

    <?php if (is_single()): ?>
        <footer class="entry-footer clearfix">
            <div class="share-wrapper">
                <?php if (markety_option('show-share-button', false, true)): ?>
                    <?php get_template_part( 'template-parts/post', 'share'); ?>
                <?php endif; ?>
            </div>

            <div class="post-tags">
                <?php $tags_list = get_the_tag_list('<ul class="list-inline"><li>#','</li><li>#','</li></ul>');
                    if ($tags_list) : ?>
                        <?php printf(esc_html__('%1$s', 'markety'), $tags_list); ?>
                    <?php endif;
                ?>
            </div> <!-- .post-tags -->
        </footer>
    <?php endif; ?>
</article>