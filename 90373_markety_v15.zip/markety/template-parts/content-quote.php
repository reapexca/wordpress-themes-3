<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <header class="entry-header">
        <?php if (function_exists('rwmb_meta')) :
            $quote = rwmb_meta( 'markety_qoute' );
            $author_url = rwmb_meta( 'markety_qoute_author_url' );

            if ($quote) : ?>
            
                <div class="post-thumbnail blog-quote">
                    <blockquote>
                        <p><?php echo esc_html($quote);?></p>
                        
                        <?php 
                            if ($author_url) : ?>
                                <small><a href="<?php echo esc_url($author_url)?>"><?php echo esc_html(rwmb_meta( 'markety_qoute_author' )); ?></a></small>
                                <?php else : ?>
                                    <small><?php echo esc_html(rwmb_meta( 'markety_qoute_author' )); ?></small>
                                <?php 
                            endif;
                        ?>
                        
                    </blockquote>
                </div>
            <?php endif; 
        endif;
        ?>
    </header><!-- .entry-header -->

    <div class="blog-content">
        <div class="entry-header">
            <?php
                if ( is_single() ) :
                    the_title( '<h2 class="entry-title">', '</h2>' );
                else :
                    the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
                endif;
            ?>
            <div class="entry-meta">
                <?php markety_posted_on() ?>
            </div><!-- .entry-meta -->
        </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                if (is_single() || !has_excerpt()) :
                    the_content( '<span class="readmore">' . esc_html__( 'Read More', 'markety' ) . '</span>' );
                else :
                    the_excerpt();
                endif;

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'markety') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->

    <footer class="entry-footer clearfix">
        <ul class="entry-meta">
            <?php if (!is_single()): ?>
                <li>
                    <span class="post-comments">
                        <?php
                            comments_popup_link(
                                esc_html__('0', 'markety'),
                                esc_html__('1', 'markety'),
                                esc_html__('%', 'markety'), '',
                                esc_html__('Comments are Closed', 'markety')
                            ); 
                        ?>
                    </span>
                </li>

                <?php if (function_exists('zilla_likes')) : ?>
                    <li>
                        <span class="likes">
                            <?php zilla_likes(); ?>
                        </span>
                    </li>
                <?php endif; ?>

            <?php else : ?>

                <?php if (function_exists('zilla_likes')) : ?>
                    <li>
                        <span class="likes">
                            <?php zilla_likes(); ?>
                        </span>
                    </li>
                <?php endif; ?>
                <?php if (markety_option('show-share-button', false, true)): ?>
                    <li class="share"><span><i class="fa fa-share"></i> <?php esc_html_e('Share', 'markety');?></span>
                        <?php get_template_part( 'template-parts/post', 'share'); ?>
                    </li>
                <?php endif; ?>
                
            <?php endif; ?>
        </ul>

       <?php if (is_single()): ?>
            <div class="post-tags">
                <?php $tags_list = get_the_tag_list('', esc_html__(' ', 'markety'));
                    if ($tags_list) : ?>
                        <span class="tags-links">
                            <?php printf(esc_html__('%1$s', 'markety'), $tags_list); ?>
                        </span>
                    <?php endif; 
                ?>
            </div> <!-- .post-tags -->
        <?php endif; ?>
    </footer>
</article>