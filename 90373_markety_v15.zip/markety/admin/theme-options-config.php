<?php

    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // ReduxFramework  Config File
    // For full documentation, please visit: https://docs.reduxframework.com
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // This is your option name where all the Redux data is stored.
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    $opt_name = "markety_theme_option";


    /**
     * SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => TRUE,
        // Show the sections below the admin menu item or not
        'menu_title'           => sprintf( esc_html__( '%s Options', 'markety' ), $theme->get( 'Name' ) ),
        'page_title'           => sprintf( esc_html__( '%s Theme Options', 'markety' ), $theme->get( 'Name' ) ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => FALSE,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => TRUE,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => TRUE,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-admin-generic',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => FALSE,
        // Show the time the page took to load, etc
        'update_notice'        => TRUE,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => TRUE,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => '40',
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => TRUE,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => FALSE,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => TRUE,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => TRUE,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => TRUE,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        'footer_credit'        => sprintf( esc_html__( '%s Theme Options', 'markety' ), $theme->get( 'Name' ) ),
        // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => TRUE,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => TRUE,
                'rounded' => FALSE,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // START SECTIONS
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    // General Settings
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-cogs',
        'title'  => esc_html__('General Settings', 'markety'),
        'fields' => array(
            array(
                'id'       => 'tt-breadcrumb',
                'type'     => 'switch',
                'title'    => esc_html__('Breadcrumb', 'markety'),
                'subtitle' => esc_html__('Show or Hide Your website Breadcrumb', 'markety'),
                'on'       => esc_html__('Show', 'markety'),
                'off'      => esc_html__('Hide', 'markety'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'smooth-scroll',
                'type'     => 'switch',
                'title'    => esc_html__('Smooth Page Scroll', 'markety'),
                'subtitle' => esc_html__('Enable or Disabled Smooth Page Scroll', 'markety'),
                'on'       => esc_html__('Enable', 'markety'),
                'off'      => esc_html__('Disabled', 'markety'),
                'default'  => FALSE,
            ),

            array(
                'id'       => 'rtl',
                'type'     => 'switch',
                'title'    => esc_html__('RTL', 'markety'),
                'subtitle' => esc_html__('Enable or Disabled RTL', 'markety'),
                'on'       => esc_html__('Enable', 'markety'),
                'off'      => esc_html__('Disabled', 'markety'),
                'default'  => FALSE,
            ),

            array(
                'id'       => 'top-border-style',
                'type'     => 'switch',
                'title'    => esc_html__('Top border style', 'markety'),
                'subtitle' => esc_html__('Enable or Disabled top border style', 'markety'),
                'on'       => esc_html__('Enable', 'markety'),
                'off'      => esc_html__('Disabled', 'markety'),
                'default'  => TRUE,
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Logo settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-slideshare',
        'title'  => esc_html__('Logo Settings', 'markety'),
        'fields' => array(
            array(
                'id'       => 'logo-type',
                'type'     => 'switch',
                'title'    => esc_html__('Logo Type', 'markety'),
                'subtitle' => esc_html__('You can set text or image logo', 'markety'),
                'on'       => esc_html__('Image Logo', 'markety'),
                'off'      => esc_html__('Text Logo', 'markety'),
                'default'  => TRUE,
            ),
            array(
                'id'       => 'text-logo',
                'type'     => 'text',
                'required' => array('logo-type', '=', '0'),
                'title'    => esc_html__('Logo Text', 'markety'),
                'subtitle' => esc_html__('Change your logo text', 'markety')
            ),
            array(
                'id'       => 'logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Logo.', 'markety'),
                'subtitle' => esc_html__('Change Site logo dimension: 160px &times; 55px', 'markety')
            ),
            
            array(
                'id'       => 'mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Mobile Logo.', 'markety'),
                'subtitle' => esc_html__('Change site mobile logo dimension: 160px &times; 55px', 'markety')
            ),
            
            array(
                'id'       => 'sticky-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Sticky Logo.', 'markety'),
                'subtitle' => esc_html__('Change site sticky logo dimension: 160px &times; 55px', 'markety')
            ),
            
            array(
                'id'       => 'sticky-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Sticky Mobile Logo.', 'markety'),
                'subtitle' => esc_html__('Change site sticky mobile logo dimension: 145px &times; 55px', 'markety')
            ),
            
            array(
                'id'             => 'logo-margin',
                'type'           => 'spacing',
                'output'         => array('.navbar-brand'),
                'mode'           => 'margin',
                'units'          => 'px',
                'units_extended' => 'false',
                'title'          => esc_html__('Logo Margin Option', 'markety'),
                'subtitle'       => esc_html__('You can change logo margin if needed.', 'markety'),
                'desc'           => esc_html__('Change top, right, bottom and left value in px, e.g: 10', 'markety')
            )
        )
    ));

    // Header settings
    Redux::setSection( $opt_name, array(
        'icon'   => 'el el-website',
        'title'  => esc_html__( 'Header Settings', 'markety' ),
        'fields' => array(
            
            // header style
            array(
                'id'       => 'header-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Header styles', 'markety' ),
                'subtitle' => esc_html__( 'Select Header Style.', 'markety' ),
                'options'  => array(
                    'header-default'   => array(
                        'alt' => esc_html__('Header default', 'markety'),
                        'img' => get_template_directory_uri() . '/images/header-default.jpg'
                    ),
                    'header-transparent'   => array(
                        'alt' => esc_html__('Header transparent', 'markety'),
                        'img' => get_template_directory_uri() . '/images/header-transparent.jpg'
                    )
                ),
                'default'  => 'header-default'
            ),

            // menu background color
            array(
                'id'       => 'menu-bg-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu background color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for menu background.', 'markety' )
            ),

            // menu color
            array(
                'id'       => 'menu-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu font color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for menu.', 'markety' )
            ),

            // mobile menu background color
            array(
                'id'       => 'mobile-menu-bg-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Mobile menu background color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for mobile menu background.', 'markety' )
            ),

            // mobile menu color
            array(
                'id'       => 'mobile-menu-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Mobile menu font color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for mobile menu.', 'markety' )
            ),

            // sticky menu visibility
            array(
                'id'       => 'sticky-menu-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Sticky menu visibility', 'markety'),
                'subtitle' => esc_html__('Visible or Hidden sticky menu', 'markety'),
                'on'       => esc_html__('Visible', 'markety'),
                'off'      => esc_html__('Hidden', 'markety'),
                'default'  => TRUE,
            ),

            // sticky menu background color
            array(
                'id'       => 'sticky-menu-bg-color',
                'type'     => 'color',
                'required' => array('sticky-menu-visibility', '=', '1'),
                'title'    => esc_html__( 'Sticky menu background color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for sticky menu background.', 'markety' )
            ),

            // sticky menu color
            array(
                'id'       => 'sticky-menu-color',
                'type'     => 'color',
                'required' => array('sticky-menu-visibility', '=', '1'),
                'title'    => esc_html__( 'Sticky menu font color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for sticky menu.', 'markety' )
            ),

            // SEO analysis button
            array(
                'id'       => 'analysis-button-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Analysis button visibility', 'markety'),
                'subtitle' => esc_html__('Visible or Hidden analysis button', 'markety'),
                'on'       => esc_html__('Visible', 'markety'),
                'off'      => esc_html__('Hidden', 'markety'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'analysis-button-text',
                'type'     => 'text',
                'required' => array('analysis-button-visibility', '=', '1'),
                'title'    => esc_html__('Analysis button text', 'markety'),
                'subtitle' => esc_html__('If you want to change analysis button then you can change text from here', 'markety'),
                'default'  => esc_html__('Free SEO Analysis', 'markety')
            ),

            array(
                'id'       => 'analysis-button-link',
                'type'     => 'switch',
                'required' => array('analysis-button-visibility', '=', '1'),
                'title'    => esc_html__('Analysis button link', 'markety'),
                'subtitle' => esc_html__('Select button link type', 'markety'),
                'on'       => esc_html__('Link with page', 'markety'),
                'off'      => esc_html__('External site link', 'markety'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'analysis-button-page-link',
                'type'     => 'select',
                'required' => array('analysis-button-link', '=', '1'),
                'title'    => esc_html__('Analysis quote page', 'markety'),
                'subtitle' => esc_html__('Select analysis quote page to linking with analysis button', 'markety'),
                'multi'    => false,
                'data'     => 'page'
            ),

            array(
                'id'       => 'analysis-button-external-link',
                'type'     => 'text',
                'required' => array('analysis-button-link', '=', '0'),
                'title'    => esc_html__('Analysis button external link', 'markety'),
                'subtitle' => esc_html__('Enter external button link here', 'markety')
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Page header image settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-picture',
        'title'  => esc_html__('Page Header Image', 'markety'),
        'fields' => array(

            array(
                'id'       => 'page-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Page Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'portfolio-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Portfolio Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'member-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Member Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            
            array(
                'id'       => 'product-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Product Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            
            array(
                'id'       => 'blog-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Blog Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'author-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Author Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'category-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Category Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'tag-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Tag Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'search-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Search Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'archive-header-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Archive Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            ),
            array(
                'id'       => 'header-404-image',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('404 Header Background.', 'markety'),
                'desc'     => esc_html__('Upload image from media library, dimension: 1920px x 450px', 'markety')
            )
        )
    ));

    
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Presets settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-brush',
        'title'  => esc_html__('Preset color', 'markety'),
        'fields' => array(
            
            array(
                'id'       => 'accent-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Site Accent Color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for the theme accent color (default: #ef476f).', 'markety' ),
                'default'  => '#ef476f',
            ),

            array(
                'id'       => 'link-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Site Link Color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for all link (default: #ef476f).', 'markety' ),
                'default'  => '#ef476f',
            ),

            array(
                'id'       => 'section-title-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Section title color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for section title (default: #26547c).', 'markety' ),
                'default'  => '#26547c',
            )
        )
    ));



    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Typography
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-font',
        'title'  => esc_html__('Typography', 'markety'),
        'fields' => array(
            
            // body typography
            array(
                'id'       => 'body-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'Body Font', 'markety' ),
                'subtitle' => esc_html__( 'Specify the body font properties.', 'markety' ),
                'google'   => true,
                'all_styles' => true,
                'text-align' => false,
                'default'  => array(
                    'color'       => '#999999',
                    'font-size'   => '16px',
                    'font-family' => 'Roboto',
                    'font-weight' => '400',
                    'line-height' => '25px'
                ),
            ),


            // Heading all typography
            array(
                'id'       => 'heading-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'Heading Font', 'markety' ),
                'subtitle' => esc_html__( 'This settings for all heading font (h1, h2, h3, h4, h5, h6)', 'markety' ),
                'google'   => true,
                'all_styles' => true,
                'text-align' => false,
                'font-size' => false,
                'line-height' => false,
                'default'  => array(
                    'color'       => '#26547c',
                    'font-family' => 'Roboto',
                    'font-weight' => '400'
                ),
            ),

            // only H1 typography
            array(
                'id'       => 'h1-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H1 (Heading one)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H1', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '40px',
                    'line-height' => '60px'
                ),
            ),


            // only H2 typography
            array(
                'id'       => 'h2-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H2 (Heading two)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H2', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '35px',
                    'line-height' => '40px'
                ),
            ),


            // only H3 typography
            array(
                'id'       => 'h3-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H3 (Heading three)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H3', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '20px',
                    'line-height' => '25px'
                ),
            ),

            // only H4 typography
            array(
                'id'       => 'h4-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H4 (Heading four)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H4', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '18px',
                    'line-height' => '20px'
                ),
            ),

            // only H5 typography
            array(
                'id'       => 'h5-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H5 (Heading five)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H5', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '16px',
                    'line-height' => '18px'
                ),
            ),

            // only H6 typography
            array(
                'id'       => 'h6-typography',
                'type'     => 'typography',
                'title'    => esc_html__( 'H6 (Heading six)', 'markety' ),
                'subtitle' => esc_html__( 'This settings only for H6', 'markety' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '14px',
                    'line-height' => '16px'
                ),
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Blog settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    $rs_lists = '';
    // revolution slider lists
    if( class_exists('RevSlider') ) :
        $slider = new RevSlider();
        $rs_lists = $slider->getArrSlidersShort();
    endif;


    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-file-edit',
        'title'  => esc_html__('Blog Settings', 'markety'),
        'fields' => array(

            array(
                'id'       => 'blog-title',
                'type'     => 'text',
                'title'    => esc_html__('Blog Page Title', 'markety'),
                'subtitle' => esc_html__('Enter Blog page title here, if leave blank then site title will appear', 'markety')
            ),
            array(
                'id'       => 'blog-sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__('Blog sidebar setting', 'markety'),
                'subtitle' => esc_html__('Select blog sidebar', 'markety'),
                'options'  => array(
                    'no-sidebar'    => array(
                        'alt' => 'No sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    'left-sidebar'  => array(
                        'alt' => 'Left sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    'right-sidebar' => array(
                        'alt' => 'Right sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    )
                ),
                'default'  => 'right-sidebar'
            ),

            array(
                'id'       => 'show-share-button',
                'type'     => 'switch',
                'title'    => esc_html__('Share button', 'markety'),
                'subtitle' => esc_html__('Show or hide share button', 'markety'),
                'on'       => esc_html__('Show', 'markety'),
                'off'      => esc_html__('Hide', 'markety'),
                'default'  => TRUE
            ),
            
            array(
                'id'       => 'tt-share-button',
                'type'     => 'checkbox',
                'required' => array( 'show-share-button', '=', '1' ),
                'title'    => esc_html__( 'Share button', 'markety' ),
                'subtitle' => esc_html__( 'Check to show share button', 'markety' ),
                'options'  => array(
                    'facebook' => esc_html__( 'Facebook', 'markety' ),
                    'twitter'  => esc_html__( 'Twitter', 'markety' ),
                    'google'   => esc_html__( 'Google+', 'markety' ),
                    'linkedin' => esc_html__( 'Linkedin', 'markety' )
                ),
                'default'  => array(
                    'facebook' => '1',
                    'twitter'  => '1',
                    'google'   => '1',
                    'linkedin' => '1'
                )
            ),

            array(
                'id'       => 'blog-page-nav',
                'type'     => 'switch',
                'title'    => esc_html__('Blog Pagination or Navigation', 'markety'),
                'subtitle' => esc_html__('Blog pagination style, posts pagination or newer / older posts', 'markety'),
                'on'       => esc_html__('Pagination', 'markety'),
                'off'      => esc_html__('Navigation', 'markety'),
                'default'  => TRUE
            ),
            
            array(
                'id'       => 'blog-search-filter',
                'type'     => 'switch',
                'title'    => esc_html__('Blog search filter', 'markety'),
                'subtitle' => esc_html__('Enable or disable blog search filter form grid post layout', 'markety'),
                'on'       => esc_html__('Enable', 'markety'),
                'off'      => esc_html__('Disable', 'markety'),
                'default'  => FALSE
            ),

            array(
                'id'       => 'tt-post-meta',
                'type'     => 'checkbox',
                'title'    => esc_html__( 'Post meta options', 'markety' ),
                'subtitle' => esc_html__( 'Check to show post meta', 'markety' ),
                'options'  => array(
                    'post-date'         => esc_html__( 'Post Date', 'markety' ),
                    'post-author'       => esc_html__( 'Post Author', 'markety' ),
                    'post-category'     => esc_html__( 'Post Category', 'markety' ),
                    'post-comment' => esc_html__( 'Post Comment', 'markety' ),
                    'post-like' => esc_html__( 'Post Like', 'markety' )
                ),
                'default'  => array(
                    'post-date' => '1',
                    'post-author'  => '1',
                    'post-category'   => '1',
                    'post-comment' => '1',
                    'post-like' => '1'
                )
            ),

            array(
                'id'      => 'rev-slider',
                'type'    => 'select',
                'title'   => esc_html__( 'Select slider for Blog Grid Home', 'markety' ),
                'options' => $rs_lists,
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Page settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-file-edit',
        'title'  => esc_html__('Page Settings', 'markety'),
        'fields' => array(

            array(
                'id'       => 'page-sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__('Page Sidebar', 'markety'),
                'subtitle' => esc_html__('Select page sidebar', 'markety'),
                'options'  => array(
                    'no-sidebar'    => array(
                        'alt' => 'No sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    'left-sidebar'  => array(
                        'alt' => 'Left sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    'right-sidebar' => array(
                        'alt' => 'Right sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    )
                ),
                'default'  => 'right-sidebar'
            )
        )
    ));


    if (class_exists('WooCommerce')) :
        //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
        // Shop settings
        //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
        Redux::setSection( $opt_name, array(
            'icon'   => 'el-icon-shopping-cart',
            'title'  => esc_html__('Shop Settings', 'markety'),
            'fields' => array(

                array(
                    'id'       => 'shop-sidebar',
                    'type'     => 'image_select',
                    'title'    => esc_html__('Shop Sidebar', 'markety'),
                    'subtitle' => esc_html__('Select shop sidebar', 'markety'),
                    'options'  => array(
                        'no-sidebar'    => array(
                            'alt' => 'No sidebar',
                            'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                        ),
                        'left-sidebar'  => array(
                            'alt' => 'Left sidebar',
                            'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                        ),
                        'right-sidebar' => array(
                            'alt' => 'Right sidebar',
                            'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                        )
                    ),
                    'default'  => 'right-sidebar'
                ),

                array(
                    'id'       => 'product-per-page',
                    'type'     => 'text',
                    'title'    => esc_html__('Product per page', 'markety'),
                    'subtitle' => esc_html__('Change number of products per page', 'markety'),
                    'default'  => '6'
                ),

                array(
                    'id'       => 'product-column',
                    'type'     => 'select',
                    'title'    => esc_html__('Product per row', 'markety'),
                    'subtitle' => esc_html__('Change number of products per row', 'markety'),
                    'options'  => array(
                        '2' => 'Column 2',
                        '3' => 'Column 3',
                        '4' => 'Column 4'
                    ),
                    'default'  => '3'
                )
            )
        ));
    endif;
    


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Portfolio settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-th-large',
        'title'  => esc_html__('Portfolio Settings', 'markety'),
        'fields' => array(
            
            array(
                'id'       => 'mask-show-hide',
                'type'     => 'switch',
                'title'    => esc_html__('Portfolio item mask show/hide', 'markety'),
                'subtitle' => esc_html__('You can show or hide portfolio item mask', 'markety'),
                'on'       => esc_html__('Show', 'markety'),
                'off'      => esc_html__('Hide', 'markety'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'mask-0',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('mask-show-hide', '=', '1'),
                'title'    => esc_html__('Portfolio item mask(Mask one)', 'markety'),
                'subtitle' => esc_html__('Upload portfolio mask image', 'markety')
            ),

            array(
                'id'       => 'mask-1',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('mask-show-hide', '=', '1'),
                'title'    => esc_html__('Portfolio item mask(Mask two)', 'markety'),
                'subtitle' => esc_html__('Upload portfolio mask image', 'markety')
            ),

            array(
                'id'       => 'portfolio-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Portfolio navigation visibility', 'markety'),
                'subtitle' => esc_html__('You can show or hide portfolio navigation bar from single portfolio page', 'markety'),
                'on'       => esc_html__('Visible', 'markety'),
                'off'      => esc_html__('Hidden', 'markety'),
                'default'  => TRUE,
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Preloader settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-repeat-alt',
        'title'  => esc_html__('Preloader Settings', 'markety'),
        'fields' => array(
            array(
                'id'       => 'page-preloader',
                'type'     => 'switch',
                'title'    => esc_html__('Page Preloader', 'markety'),
                'subtitle' => esc_html__('You can enable or disable page preloader from here.', 'markety'),
                'on'       => esc_html__('Enable', 'markety'),
                'off'      => esc_html__('Disable', 'markety'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'loader-bg-color',
                'type'     => 'color',
                'required' => array( 'page-preloader', '=', '1' ),
                'title'    => esc_html__( 'Preloader background color', 'markety' ),
                'subtitle' => esc_html__( 'Pick color for preloader background (default: #ffffff).', 'markety' ),
                'default'  => '#ffffff',
            ),

            array(
                'id'       => 'tt-loader',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array( 'page-preloader', '=', '1' ),
                'title'    => esc_html__('Animation file', 'markety'),
                'subtitle' => esc_html__('Upload loader gif animation file', 'markety')
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Custom Style
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-css',
        'title'  => esc_html__('Custom CSS', 'markety'),
        'fields' => array(
            array(
                'id'       => 'custom_style',
                'type'     => 'textarea',
                'title'    => esc_html__('CSS Code', 'markety'),
                'desc' => esc_html__('You can write your custom CSS here.', 'markety')
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Footer settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-photo',
        'title'  => esc_html__('Footer Settings', 'markety'),
        'fields' => array(
            // footer style
            array(
                'id'       => 'footer-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Footer styles', 'markety' ),
                'subtitle' => esc_html__( 'Select Footer Style.', 'markety' ),
                'options'  => array(
                    'footer-default'   => array(
                        'alt' => esc_html__('Footer default', 'markety'),
                        'img' => get_template_directory_uri() . '/images/footer-default.jpg'
                    ),
                    'footer-three-column'   => array(
                        'alt' => esc_html__('Footer Three Column', 'markety'),
                        'img' => get_template_directory_uri() . '/images/footer-3column.jpg'
                    ),
                    'footer-four-column'   => array(
                        'alt' => esc_html__('Footer Four Column', 'markety'),
                        'img' => get_template_directory_uri() . '/images/footer-4column.jpg'
                    ),
                    'footer-onepage'   => array(
                        'alt' => esc_html__('Footer onepage', 'markety'),
                        'img' => get_template_directory_uri() . '/images/footer-onepage.jpg'
                    )
                ),
                'default'  => 'footer-default'
            ),
            array(
                'id'       => 'footer-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('footer-style', '=', array('footer-default', 'footer-onepage')),
                'title'    => esc_html__('Footer Logo.', 'markety'),
                'subtitle' => esc_html__('Change footer logo dimension: 150px &times; 30px', 'markety')
            ),
            array(
                'id'       => 'footer-retina-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('footer-style', '=', array('footer-default', 'footer-onepage')),
                'title'    => esc_html__('Footer Retina Logo (High Density)', 'markety'),
                'subtitle' => esc_html__('Change Footer Retina logo dimension: 300px &times; 600px', 'markety'),
                'desc'     => esc_html__('Add a 300px &times; 60px pixels image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable', 'markety'),
            ),
            array(
                'id'       => 'footer-about-text',
                'type'     => 'editor',
                'required' => array('footer-style', '=', array('footer-default')),
                'title'    => esc_html__('Footer About Text', 'markety'),
                'subtitle' => esc_html__('Write footer about text here.', 'markety')
            ),
            array(
                'id'       => 'footer-menu-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Footer menu visibility', 'markety'),
                'required' => array('footer-style', '=', array('footer-default')),
                'subtitle' => esc_html__('Show or hide footer menu from footer', 'markety'),
                'on'       => esc_html__('Show', 'markety'),
                'off'      => esc_html__('Hide', 'markety'),
                'default'  => TRUE,
            ),
            array(
                'id'       => 'footer-text',
                'type'     => 'editor',
                'title'    => esc_html__('Footer Copyright Text', 'markety'),
                'subtitle' => esc_html__('Write footer copyright text here.', 'markety')
            ),
            array(
                'id'       => 'social-icon-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Social icon visibility', 'markety'),
                'subtitle' => esc_html__('Show or hide social icon from footer', 'markety'),
                'on'       => esc_html__('Show', 'markety'),
                'off'      => esc_html__('Hide', 'markety'),
                'default'  => TRUE,
            ),
            array(
                'id'       => 'facebook-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Facebook Link', 'markety'),
                'subtitle' => esc_html__('Enter facebook page or profile link. Leave blank to hide icon.', 'markety'),
                'default'  => "#"
            ),
            array(
                'id'       => 'twitter-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Twitter Link', 'markety'),
                'subtitle' => esc_html__('Enter twitter link. Leave blank to hide icon.', 'markety'),
                'default'  => "#"
            ),
            array(
                'id'       => 'google-plus-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Google Plus Link', 'markety'),
                'subtitle' => esc_html__('Enter google plus page or profile link. Leave blank to hide icon.', 'markety'),
                'default'  => "#"
            ),
            array(
                'id'       => 'youtube-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Youtube Link', 'markety'),
                'subtitle' => esc_html__('Enter youtube chanel link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'pinterest-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Pinterest Link', 'markety'),
                'subtitle' => esc_html__('Enter pinterest link. Leave blank to hide icon.', 'markety'),
                'default'  => "#"
            ),
            array(
                'id'       => 'flickr-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Flickr Link', 'markety'),
                'subtitle' => esc_html__('Enter flicker link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'linkedin-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Linkedin Link', 'markety'),
                'subtitle' => esc_html__('Enter linkedin profile link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'vimeo-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Vimeo Link', 'markety'),
                'subtitle' => esc_html__('Enter vimeo chanel link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'instagram-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Instagram Link', 'markety'),
                'subtitle' => esc_html__('Enter instagram page or profile link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'dribbble-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Dribbble Link', 'markety'),
                'subtitle' => esc_html__('Enter dribbble profile link. Leave blank to hide icon.', 'markety'),
            ),
            array(
                'id'       => 'behance-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Behance Link', 'markety'),
                'subtitle' => esc_html__('Enter behance profile link. Leave blank to hide icon.', 'markety'),
            ),
        )
    ));

    /*
     * <--- END SECTIONS
     */