<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; ?>

<footer class="footer-section footer-default-wrapper">
    <div class="container">
        
        <?php if ( class_exists( 'Redux' ) ) : ?>
            <a class="backToTop tt-scroll" href="#home"><i class="fa fa-angle-up"></i></a>
        
            <div class="primary-footer">
                <div class="row">
                    <div class="col-md-7">
                        <div class="footer-logo">
                            <a href="<?php echo esc_url(site_url('/')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                <img src="<?php echo esc_url(markety_option('footer-logo', 'url', get_template_directory_uri() . '/images/logo.png')); ?>" data-at2x="<?php echo esc_url(markety_option('footer-retina-logo', 'url', get_template_directory_uri() . '/images/logo2x.png')); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
                            </a>
                        </div> <!-- .footer-logo -->

                        <div class="footer-about-text">
                            <?php echo wp_kses(markety_option('footer-about-text'), array(
                                'a'          => array(
                                    'href'   => array(),
                                    'title'  => array(),
                                    'target' => array()
                                ),
                                'br'     => array(),
                                'em'     => array(),
                                'strong' => array(),
                                'ul'     => array(),
                                'li'     => array(),
                                'p'      => array(),
                                'span'   => array(
                                    'class' => array()
                                )
                            )); ?>
                        </div>
                        
                        <?php if (markety_option('footer-menu-visibility', false, true)): ?>
                            <div class="footer-menu clearfix">
                                <?php
                                    wp_nav_menu( apply_filters( 'markety_wp_nav_menu_footer', array(
                                         'theme_location' => 'footer',
                                         'items_wrap'     => '<ul class="footer-nav">%3$s</ul>',
                                         'fallback_cb'    => 'Markety_Navwalker::fallback'
                                        ))
                                    );
                                ?>
                            </div>
                        <?php endif; ?>

                        <?php if (markety_option('social-icon-visibility', false, true)) : ?>
                            <div class="social-links-wrap">
                                <?php get_template_part('template-parts/social', 'icons');?>
                            </div> <!-- /social-links-wrap -->
                        <?php endif; ?>

                    </div> <!-- .col-md-7 -->

                    <div class="col-md-5">
                        <?php if (is_active_sidebar('markety-footer-default' )): ?>
                            <div class="tt-sidebar-wrapper footer-sidebar clearfix" role="complementary">
                                <?php dynamic_sidebar('markety-footer-default' );?>
                            </div>
                        <?php endif ?>
                    </div> <!-- .col-md-5 -->
                </div>
            </div> <!-- .primary-footer -->
        <?php endif; ?>
    </div> <!-- .container -->
   
    <div class="footer-copyright">
        <div class="container">
            <div class="copyright">
                <?php if (markety_option('footer-text', false, false)) : ?>
                    <?php echo wp_kses(markety_option('footer-text'), array(
                        'a'      => array(
                            'href'   => array(),
                            'title'  => array(),
                            'target' => array()
                        ),
                        'br'     => array(),
                        'em'     => array(),
                        'strong' => array(),
                        'ul'     => array(),
                        'li'     => array(),
                        'p'      => array(),
                        'span'   => array(
                            'class' => array()
                        )
                    )); 
                    
                    else : ?>
                    <?php printf(
                        esc_html__('Copyright &copy; %1$s | %2$s Theme by %3$s | Powered by %4$s', 'markety'),
                        date('Y'), 
                        esc_html__('Markety', 'markety'),
                        "<a href='http://trendytheme.net'>".esc_html__('TrendyTheme', 'markety')."</a>",
                        "<a href='https://wordpress.org'>".esc_html__('WordPress', 'markety')."</a>"
                    ); ?>
                <?php endif; ?>
            </div> <!-- .copyright -->
        </div> <!-- .container -->
    </div> <!-- .footer-copyright -->
</footer> <!-- .footer-section -->