<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

function tt_vc_template_creative_testimonial( $data ) {
	$template                   = array();
	$template[ 'name' ]         = esc_html__( 'Creative Testimonial', 'markety');
	$template[ 'custom_class' ] = 'tt_vc_template_creative_testimonial';

	ob_start();
	?>[vc_row css=".vc_custom_1468824848608{margin-top: 150px !important;margin-bottom: 100px !important;}"][vc_column][tt_testimonial content_align="text-center" large_screen="1" items_desktop="1" items_tablet="1" items_mobile_landscape="1" items_mobile="1" item_gutter="0" testimonial_info="%5B%7B%22photo_option%22%3A%22yes%22%2C%22client_image%22%3A%221817%22%2C%22quote_video%22%3A%22yes%22%2C%22video_url%22%3A%22https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DxBaXSuxJcN0%22%2C%22icon_color%22%3A%22%2300d8ff%22%2C%22client_name%22%3A%22JONATHAN%20DOE%22%2C%22client_org%22%3A%22Toto%20Company%22%2C%22content%22%3A%22A%20dictum%20a%20et%20scelerisque%20at%20magnis%20urna%20a%20ultrices%20suspendisse%20consectetur%20tempor%20nec%20arcu%20curae%20rhoncus%20dis%20eu%20ullamcorper%20quam.%20Urna%20eu%20nascetur%20facilisis%20suspendisse%20inceptos%20condimentum%20urna%20conubia.%22%7D%2C%7B%22photo_option%22%3A%22yes%22%2C%22client_image%22%3A%221815%22%2C%22quote_video%22%3A%22yes%22%2C%22video_url%22%3A%22https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DxBaXSuxJcN0%22%2C%22icon_color%22%3A%22%23000000%22%2C%22client_name%22%3A%22EFTAKHER%20ALAM%22%2C%22client_org%22%3A%22Trendy%20Theme%22%2C%22content%22%3A%22A%20dictum%20a%20et%20scelerisque%20at%20magnis%20urna%20a%20ultrices%20suspendisse%20consectetur%20tempor%20nec%20arcu%20curae%20rhoncus%20dis%20eu%20ullamcorper%20quam.%20Urna%20eu%20nascetur%20facilisis%20suspendisse%20inceptos%20condimentum%20urna%20conubia.%22%7D%2C%7B%22photo_option%22%3A%22yes%22%2C%22client_image%22%3A%221816%22%2C%22quote_video%22%3A%22yes%22%2C%22video_url%22%3A%22https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DxBaXSuxJcN0%22%2C%22icon_color%22%3A%22%23000000%22%2C%22client_name%22%3A%22NAYLA%20NAEEAM%22%2C%22client_org%22%3A%22Oral%20Care%22%2C%22content%22%3A%22A%20dictum%20a%20et%20scelerisque%20at%20magnis%20urna%20a%20ultrices%20suspendisse%20consectetur%20tempor%20nec%20arcu%20curae%20rhoncus%20dis%20eu%20ullamcorper%20quam.%20Urna%20eu%20nascetur%20facilisis%20suspendisse%20inceptos%20condimentum%20urna%20conubia.%22%7D%5D"][/vc_column][/vc_row]
	<?php
	$template[ 'content' ] = ob_get_clean();
	array_unshift( $data, $template );
	return $data;
}
add_filter( 'vc_load_default_templates', 'tt_vc_template_creative_testimonial' );