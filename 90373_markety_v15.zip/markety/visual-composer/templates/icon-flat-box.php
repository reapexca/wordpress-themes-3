<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

function tt_vc_template_icon_flat_box( $data ) {
	$template                   = array();
	$template[ 'name' ]         = esc_html__( 'Icon Flat Box', 'markety');
	$template[ 'custom_class' ] = 'tt_vc_template_icon_flat_box';

	ob_start();
	?>[vc_row][vc_column][tt_icon_blocks block_height=""][tt_icon_block show_icon="yes" icon_style="icon-circle" icon_type="flat-icon" icon_position="icon-position-center" icon_color_option="custom-color" bg_color_option="custom-color" title="Keyword Research" flat_icon="flaticon-file189" icon_bg_color="#ef476f" icon_color="#ffffff"]Objectively exploit an expanded array of manufactured products vis-a-vis high-quality quality vectors uniquely[/tt_icon_block][tt_icon_block show_icon="yes" icon_style="icon-circle" icon_type="flat-icon" icon_position="icon-position-center" icon_color_option="custom-color" bg_color_option="custom-color" title="Website Analysis" flat_icon="flaticon-linegraphic1" icon_color="#ffffff" icon_bg_color="#02f58b"]Objectively exploit an expanded array of manufactured products vis-a-vis high-quality quality vectors uniquely[/tt_icon_block][tt_icon_block show_icon="yes" icon_style="icon-circle" icon_type="flat-icon" icon_position="icon-position-center" icon_color_option="custom-color" bg_color_option="custom-color" title="Competitor Analysis" flat_icon="flaticon-male26" icon_color="#ffffff" icon_bg_color="#00d8ff"]Objectively exploit an expanded array of manufactured products vis-a-vis high-quality quality vectors uniquely[/tt_icon_block][tt_icon_block show_icon="yes" icon_style="icon-circle" icon_type="flat-icon" icon_position="icon-position-center" icon_color_option="custom-color" bg_color_option="custom-color" title="Backlink Building" flat_icon="flaticon-link13" icon_color="#ffffff" icon_bg_color="#9600ff"]Objectively exploit an expanded array of manufactured products vis-a-vis high-quality quality vectors uniquely[/tt_icon_block][/tt_icon_blocks][/vc_column][/vc_row]
	<?php
	$template[ 'content' ] = ob_get_clean();
	array_unshift( $data, $template );
	return $data;
}
add_filter( 'vc_load_default_templates', 'tt_vc_template_icon_flat_box' );