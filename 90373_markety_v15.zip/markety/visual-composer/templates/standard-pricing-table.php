<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

function tt_vc_template_standard_pricing_table( $data ) {
	$template                   = array();
	$template[ 'name' ]         = esc_html__( 'Standard Pricing Table', 'markety');
	$template[ 'custom_class' ] = 'tt_vc_template_standard_pricing_table';

	ob_start();
	?>[vc_row css=".vc_custom_1473074623060{margin-top: 100px !important;margin-bottom: 100px !important;}"][vc_column][tt_section_title title_alignment="text-center" title="Standard Pricing Table" css=".vc_custom_1473076777957{margin-bottom: 80px !important;}"]
<p style="text-align: center;">Appropriately actualize unique e-business for low-risk high-yield initiatives. Intrinsicly communicate emerging expertise before principle-centered catalysts for.</p>
[/tt_section_title][vc_row_inner][vc_column_inner][tt_pricing grid_column="3" table_preset="" package_name="Starter" package_rate="59" table_bg="1996,1999" table_content="%5B%7B%22package_name%22%3A%22Starter%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2259%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E5%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_preset%22%3A%22table-preset-one%22%7D%2C%7B%22package_name%22%3A%22Premium%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2269%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E9%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_preset%22%3A%22table-preset-two%22%7D%2C%7B%22package_name%22%3A%22Business%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2279%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E12%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_preset%22%3A%22table-preset-three%22%7D%2C%7B%22package_name%22%3A%22Enterprise%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2299%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E15%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_preset%22%3A%22table-preset-four%22%7D%5D"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
	<?php
	$template[ 'content' ] = ob_get_clean();
	array_unshift( $data, $template );
	return $data;
}
add_filter( 'vc_load_default_templates', 'tt_vc_template_standard_pricing_table' );