<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

function tt_vc_template_custom_tab_pricing_table( $data ) {
	$template                   = array();
	$template[ 'name' ]         = esc_html__( 'Custom Tab Pricing Table', 'markety');
	$template[ 'custom_class' ] = 'tt_vc_template_custom_tab_pricing_table';

	ob_start();
	?>[vc_row css=".vc_custom_1473087669472{margin-top: 100px !important;margin-bottom: 100px !important;}"][vc_column][vc_row_inner][vc_column_inner][tt_pricing table_style="creative-table" table_alignment="text-left" grid_column="4" custom_price_form="yes" id="4" package_name="Starter" package_rate="59" table_bg="1996,1999" table_content="%5B%7B%22package_name%22%3A%22Starter%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2259%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E5%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_bg%22%3A%222333%2C2334%22%2C%22table_preset%22%3A%22table-preset-one%22%7D%2C%7B%22package_name%22%3A%22Business%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2279%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E5%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_bg%22%3A%222335%2C2336%22%2C%22table_preset%22%3A%22table-preset-one%22%7D%2C%7B%22package_name%22%3A%22Enterprise%22%2C%22currency_symbol%22%3A%22%24%22%2C%22currency_code%22%3A%22USD%22%2C%22package_rate%22%3A%2299%22%2C%22package_duration%22%3A%22Month%22%2C%22details%22%3A%22%3Cul%3E%5Cn%3Cli%3E15%20Target%20Keywords%3C%2Fli%3E%5Cn%3Cli%3E%2421%20%2F%20per%20mouth%20Call%20Tracking%3C%2Fli%3E%5Cn%3Cli%3EWeekly%20SEO%20Status%20Report%3C%2Fli%3E%5Cn%3C%2Ful%3E%22%2C%22purchase_button_show%22%3A%22yes%22%2C%22purchase_button_text%22%3A%22Purchase%22%2C%22table_bg%22%3A%222337%2C2338%22%2C%22table_preset%22%3A%22table-preset-one%22%7D%5D"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
	<?php
	$template[ 'content' ] = ob_get_clean();
	array_unshift( $data, $template );
	return $data;
}
add_filter( 'vc_load_default_templates', 'tt_vc_template_custom_tab_pricing_table' );