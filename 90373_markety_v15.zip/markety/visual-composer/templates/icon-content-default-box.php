<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

function tt_vc_template_icon_content_default( $data ) {
	$template                   = array();
	$template[ 'name' ]         = esc_html__( 'Icon Content Default', 'markety');
	$template[ 'custom_class' ] = 'tt_vc_template_icon_content_default';

	ob_start();
	?>[vc_row css=".vc_custom_1473146948495{margin-top: 100px !important;margin-bottom: 80px !important;}"][vc_column][tt_section_title title_alignment="text-center" title="Default Content Block" css=".vc_custom_1473146276380{margin-bottom: 80px !important;}"]
<p style="text-align: center;">Appropriately actualize unique e-business for low-risk high-yield initiatives. Intrinsicly communicate emerging expertise before principle-centered catalysts for.</p>
[/tt_section_title][vc_row_inner gap="2"][vc_column_inner width="1/4"][tt_icon_content_box show_icon="yes" icon_type="flat-icon" custom_link="yes" readmore_text="Read more" flat_icon="flaticon-earth208" title="Best Target"]Quickly generate exceptional ROI via client-based architectures.[/tt_icon_content_box][/vc_column_inner][vc_column_inner width="1/4"][tt_icon_content_box show_icon="yes" icon_type="flat-icon" content_box_bg_color="light-pink-bg" custom_link="yes" readmore_text="Read more" flat_icon="flaticon-calculate6" title="Classic Service"]Quickly generate exceptional ROI via client-based architectures.[/tt_icon_content_box][/vc_column_inner][vc_column_inner width="1/4"][tt_icon_content_box show_icon="yes" icon_type="flat-icon" content_box_bg_color="light-green-bg" custom_link="yes" readmore_text="Read more" flat_icon="flaticon-email14" title="Best Support"]Quickly generate exceptional ROI via client-based architectures.[/tt_icon_content_box][/vc_column_inner][vc_column_inner width="1/4"][tt_icon_content_box show_icon="yes" icon_type="flat-icon" content_box_bg_color="light-blue-bg" custom_link="yes" readmore_text="Read more" flat_icon="flaticon-money198" title="Value of money"]Quickly generate exceptional ROI via client-based architectures.[/tt_icon_content_box][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
	<?php
	$template[ 'content' ] = ob_get_clean();
	array_unshift( $data, $template );
	return $data;
}
add_filter( 'vc_load_default_templates', 'tt_vc_template_icon_content_default' );