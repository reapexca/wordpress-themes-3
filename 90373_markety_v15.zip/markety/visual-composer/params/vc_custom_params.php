<?php
	if ( ! defined( 'ABSPATH' ) ) :
	    exit; // Exit if accessed directly
	endif;

	// remove vc element
	vc_remove_element( 'vc_tta_tour' );

	// vc remove param
	vc_remove_param( 'vc_row', 'gap' );
	vc_remove_param( 'vc_row_inner', 'gap' );
	vc_remove_param( 'vc_row', 'el_class' );
	vc_remove_param( 'vc_row', 'full_width' );
	vc_remove_param( 'vc_tta_accordion', 'color' );
	vc_remove_param( 'vc_tta_accordion', 'style' );
	vc_remove_param( 'vc_tta_tabs', 'style' );
	vc_remove_param( 'vc_btn', 'color' );
	vc_remove_param( 'vc_btn', 'el_class' );


	// add param on row
	$attributes = array(
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> esc_html__( 'Content Width', 'markety'),
			'param_name' 	=> 'section_content_width',
			'value' 		=> array(
				esc_html__( 'Fixed Width', 'markety' ) => 'container',
				esc_html__( 'Full Width', 'markety' ) => 'container-fullwidth',
			),
			'description' 	=> esc_html__( 'Select content width', 'markety' ),
			'weight'		=> 1
		),

		array(
			'type'        => 'checkbox',
			'heading'     => esc_html__( 'Apply overlay ?', 'markety' ),
			'param_name'  => 'apply_overlay',
			'description' => esc_html__( 'If you want to apply overlay color then check this option', 'markety' ),
		),

		array(
	        'type'        =>'colorpicker',
	        'heading'     => esc_html__( 'Select color', 'markety' ),
	        'param_name'  => 'overlay_color',
	        'description' => esc_html__( 'Select section overlay color', 'markety' ),
	        'dependency'  => array(
	            'element'   => 'apply_overlay',
	            'not_empty' => true
	        )
	    ),

		array(
			'type' => 'textfield',
				'heading' => esc_html__( 'Extra class name', 'markety' ),
				'param_name' => 'el_class',
				'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'markety' )
		)
	);
	vc_add_params( 'vc_row', $attributes );




	// add param on accordion
	$attributes = array(

		array(
			'type' => 'dropdown',
			'param_name' => 'color',
			'value' => array(
				esc_html__('Theme Default', 'markety' ) => 'theme_default_color',
				esc_html__('Blue', 'markety' ) => 'blue',
				esc_html__('Turquoise', 'markety' ) => 'turquoise',
				esc_html__('Pink', 'markety' ) => 'pink',
				esc_html__('Violet', 'markety' ) => 'violet',
				esc_html__('Peacoc', 'markety' ) => 'peacoc',
				esc_html__('Chino', 'markety' ) => 'chino',
				esc_html__('Mulled Wine', 'markety' ) => 'mulled_wine',
				esc_html__('Vista Blue', 'markety' ) => 'vista_blue',
				esc_html__('Grey', 'markety' ) => 'grey',
				esc_html__('Black', 'markety' ) => 'black',
				esc_html__('Orange', 'markety' ) => 'orange',
				esc_html__('Sky', 'markety' ) => 'sky',
				esc_html__('Green', 'markety' ) => 'green',
				esc_html__('Juicy pink', 'markety' ) => 'juicy_pink',
				esc_html__('Sandy brown', 'markety' ) => 'sandy_brown',
				esc_html__('Purple', 'markety' ) => 'purple',
				esc_html__('White', 'markety' ) => 'white'
			),
			'std' => 'grey',
			'heading' => esc_html__( 'Color', 'markety' ),
			'description' => esc_html__( 'Select accordion color.', 'markety' ),
			'param_holder_class' => 'vc_colored-dropdown'
		),

		array(
			'type' => 'dropdown',
			'param_name' => 'style',
			'value' => array(
				esc_html__( 'Default', 'markety' ) => 'default',
				esc_html__( 'Classic', 'markety' ) => 'classic',
				esc_html__( 'Modern', 'markety' ) => 'modern',
				esc_html__( 'Flat', 'markety' ) => 'flat',
				esc_html__( 'Outline', 'markety' ) => 'outline',
			),
			'heading' => esc_html__( 'Style', 'markety' ),
			'description' => esc_html__( 'Select accordion display style.', 'markety' ),
		)

	);
	vc_add_params( 'vc_tta_accordion', $attributes );



	// add param on tab
	$attributes = array(

		array(
			'type' => 'dropdown',
			'param_name' => 'style',
			'value' => array(
				esc_html__( 'Default Tab', 'markety' ) => 'tab-default',
				esc_html__( 'Border Top Tab', 'markety' ) => 'tab-border-top',
				esc_html__( 'Classic', 'markety' ) => 'classic',
				esc_html__( 'Modern', 'markety' ) => 'modern',
				esc_html__( 'Flat', 'markety' ) => 'flat',
				esc_html__( 'Outline', 'markety' ) => 'outline',
			),
			'heading' => esc_html__( 'Style', 'markety' ),
			'description' => esc_html__( 'Select tabs display style.', 'markety' ),
		),

		array(
			'heading' => esc_html__( 'Tab equal width', 'markety' ),
			'type' => 'dropdown',
			'param_name' => 'tab_grid_column',
			'value' => array(
				esc_html__( 'Use default width', 'markety' ) => '',
				esc_html__( '2 Column', 'markety' ) => 'tabs-grid-column-2',
				esc_html__( '3 Column', 'markety' ) => 'tabs-grid-column-3',
				esc_html__( '4 Column', 'markety' ) => 'tabs-grid-column-4'
			),
			'description' => esc_html__( 'Select tab widht', 'markety' )
		)

	);
	vc_add_params( 'vc_tta_tabs', $attributes );


	// add param on button
	$attributes = array(
		array(
			'type' 					=> 'dropdown',
			'heading' 				=> __( 'Color', 'markety' ),
			'param_name' 			=> 'color',
			'description' 			=> __( 'Select button color.', 'markety' ),
			'param_holder_class' 	=> 'vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => array(
				esc_html__('Theme Primary', 'markety' ) => 'primary-color',
				esc_html__('Dark Blue', 'markety' ) => 'dark-blue',
				esc_html__('Light Blue', 'markety' ) => 'light-blue',
				esc_html__('Light green', 'markety' ) => 'light-green',
				esc_html__('Blue', 'markety' ) => 'blue',
				esc_html__('Turquoise', 'markety' ) => 'turquoise',
				esc_html__('Pink', 'markety' ) => 'pink',
				esc_html__('Violet', 'markety' ) => 'violet',
				esc_html__('Peacoc', 'markety' ) => 'peacoc',
				esc_html__('Chino', 'markety' ) => 'chino',
				esc_html__('Mulled Wine', 'markety' ) => 'mulled_wine',
				esc_html__('Vista Blue', 'markety' ) => 'vista_blue',
				esc_html__('Grey', 'markety' ) => 'grey',
				esc_html__('Black', 'markety' ) => 'black',
				esc_html__('Orange', 'markety' ) => 'orange',
				esc_html__('Sky', 'markety' ) => 'sky',
				esc_html__('Green', 'markety' ) => 'green',
				esc_html__('Juicy pink', 'markety' ) => 'juicy_pink',
				esc_html__('Sandy brown', 'markety' ) => 'sandy_brown',
				esc_html__('Purple', 'markety' ) => 'purple',
				esc_html__('White', 'markety' ) => 'white'
			),
			'std' => 'grey',
			// must have default color grey
			'dependency' => array(
				'element' => 'style',
				'value_not_equal_to' => array(
					'custom',
					'outline-custom',
					'gradient',
					'gradient-custom',
				),
			)
		),


		array(
			'type' => 'textfield',
				'heading' => esc_html__( 'Extra class name', 'markety' ),
				'param_name' => 'el_class',
				'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'markety' )
		)
	);
	vc_add_params( 'vc_btn', $attributes );