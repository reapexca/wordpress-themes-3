<?php
	if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;


    $tt_icon_block_attr = array();

	// VC Custom shortcode dir
	vc_set_shortcodes_templates_dir( get_template_directory() . '/visual-composer/shortcodes' );


	// VC Admin element stylesheet
	if ( ! function_exists( 'markety_vc_admin_styles' ) ) :
		function markety_vc_admin_styles() {
			wp_enqueue_style( 'markety_vc_admin_style', get_template_directory_uri() . '/visual-composer/assets/css/vc-element-style.css', array(), time(), 'all' );
		}
		add_action( 'admin_enqueue_scripts', 'markety_vc_admin_styles' );
	endif;


	// Remove vc default template
	if ( ! function_exists( 'markety_remove_default_templates' ) ) :
		function markety_remove_default_templates( $data ) {
			return array(); 
		}
		add_filter( 'vc_load_default_templates', 'markety_remove_default_templates' );
	endif;

	// set default editor post type
	$posttype_lists = array(
	    'page',
	    'tt-portfolio'
	);
	vc_set_default_editor_post_types( $posttype_lists );


	// include custom template
	require get_template_directory() . '/visual-composer/templates/icon-border-box.php';
	require get_template_directory() . '/visual-composer/templates/icon-flat-box.php';
	require get_template_directory() . '/visual-composer/templates/icon-content-default-box.php';
	require get_template_directory() . '/visual-composer/templates/icon-content-standard-box.php';
	require get_template_directory() . '/visual-composer/templates/icon-content-creative-box.php';
	require get_template_directory() . '/visual-composer/templates/creative-pricing-table.php';
	require get_template_directory() . '/visual-composer/templates/modern-pricing-table.php';
	require get_template_directory() . '/visual-composer/templates/standard-pricing-table.php';
	require get_template_directory() . '/visual-composer/templates/custom-tab-pricing-table.php';
	require get_template_directory() . '/visual-composer/templates/creative-testimonial.php';
	

	// include vc extend file
	require get_template_directory() . '/visual-composer/vc_extend/tt-icon-block.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-intro-block.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-hero-block.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-home-slider.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-gallery.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-text-rotator.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-section-title.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-testimonial.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-count-up.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-portfolio.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-member.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-latest-posts.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-partners.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-newsletter.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-google-map.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-popup.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-work-carousel.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-call-to-action.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-case-study-block.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-icon-content-box.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-pricing.php';
	require get_template_directory() . '/visual-composer/vc_extend/tt-address-info.php';

	// include custom param
	require get_template_directory() . '/visual-composer/params/vc_custom_params.php';
	
	// include others file
	require get_template_directory() . '/visual-composer/inc/flaticon-array-list.php';

	
	// register flat icon type
    function vc_iconpicker_editor_flaticon_jscss() {
        wp_enqueue_style( 'flaticon' );
    }
	add_action( 'vc_backend_editor_enqueue_js_css', 'vc_iconpicker_editor_flaticon_jscss' );
    add_action( 'vc_frontend_editor_enqueue_js_css', 'vc_iconpicker_editor_flaticon_jscss' );

    
    function vc_iconpicker_type_flaticon( $icons ) {
        $markety_flaticon_array = array(
			array('flaticon-add13'=>'add13'),
			array('flaticon-alarm68'=>'alarm68'),
			array('flaticon-anchor39'=>'anchor39'),
			array('flaticon-arrow164'=>'arrow164'),
			array('flaticon-arrow639'=>'arrow639'),
			array('flaticon-arrow79'=>'arrow79'),
			array('flaticon-arrows148'=>'arrows148'),
			array('flaticon-at1'=>'at1'),
			array('flaticon-audio23'=>'audio23'),
			array('flaticon-bag39'=>'bag39'),
			array('flaticon-bag45'=>'bag45'),
			array('flaticon-banking6'=>'banking6'),
			array('flaticon-basketball46'=>'basketball46'),
			array('flaticon-battery157'=>'battery157'),
			array('flaticon-battery17'=>'battery17'),
			array('flaticon-block33'=>'block33'),
			array('flaticon-book17'=>'book17'),
			array('flaticon-book36'=>'book36'),
			array('flaticon-books58'=>'books58'),
			array('flaticon-boxes6'=>'boxes6'),
			array('flaticon-briefcase56'=>'briefcase56'),
			array('flaticon-briefcase57'=>'briefcase57'),
			array('flaticon-briefcase65'=>'briefcase65'),
			array('flaticon-brightness11'=>'brightness11'),
			array('flaticon-building120'=>'building120'),
			array('flaticon-bulb19'=>'bulb19'),
			array('flaticon-button49'=>'button49'),
			array('flaticon-calculate6'=>'calculate6'),
			array('flaticon-calendar13'=>'calendar13'),
			array('flaticon-calendars2'=>'calendars2'),
			array('flaticon-camera90'=>'camera90'),
			array('flaticon-cancel22'=>'cancel22'),
			array('flaticon-cart'=>'cart'),
			array('flaticon-cart16'=>'cart16'),
			array('flaticon-certificate3'=>'certificate3'),
			array('flaticon-chain8'=>'chain8'),
			array('flaticon-charge1'=>'charge1'),
			array('flaticon-chart45'=>'chart45'),
			array('flaticon-check64'=>'check64'),
			array('flaticon-circulararrows'=>'circulararrows'),
			array('flaticon-clip14'=>'clip14'),
			array('flaticon-clock104'=>'clock104'),
			array('flaticon-clocks8'=>'clocks8'),
			array('flaticon-clouds29'=>'clouds29'),
			array('flaticon-cloudstorage5'=>'cloudstorage5'),
			array('flaticon-coin20'=>'coin20'),
			array('flaticon-compass109'=>'compass109'),
			array('flaticon-computer236'=>'computer236'),
			array('flaticon-computermouse10'=>'computermouse10'),
			array('flaticon-computers14'=>'computers14'),
			array('flaticon-computers31'=>'computers31'),
			array('flaticon-computerscreen8'=>'computerscreen8'),
			array('flaticon-counterclockwise14'=>'counterclockwise14'),
			array('flaticon-coverage1'=>'coverage1'),
			array('flaticon-credit-card21'=>'credit-card21'),
			array('flaticon-cropping4'=>'cropping4'),
			array('flaticon-cross105'=>'cross105'),
			array('flaticon-crosshair16'=>'crosshair16'),
			array('flaticon-cup55'=>'cup55'),
			array('flaticon-cup7'=>'cup7'),
			array('flaticon-delete26'=>'delete26'),
			array('flaticon-diagram7'=>'diagram7'),
			array('flaticon-direction2'=>'direction2'),
			array('flaticon-document169'=>'document169'),
			array('flaticon-document171'=>'document171'),
			array('flaticon-document26'=>'document26'),
			array('flaticon-document28'=>'document28'),
			array('flaticon-down-arrow4'=>'down-arrow4'),
			array('flaticon-down126'=>'down126'),
			array('flaticon-download170'=>'download170'),
			array('flaticon-download181'=>'download181'),
			array('flaticon-download3'=>'download3'),
			array('flaticon-drop29'=>'drop29'),
			array('flaticon-dropper13'=>'dropper13'),
			array('flaticon-earth208'=>'earth208'),
			array('flaticon-email109'=>'email109'),
			array('flaticon-email110'=>'email110'),
			array('flaticon-email111'=>'email111'),
			array('flaticon-email14'=>'email14'),
			array('flaticon-envelope54'=>'envelope54'),
			array('flaticon-fashion4'=>'fashion4'),
			array('flaticon-file187'=>'file187'),
			array('flaticon-file189'=>'file189'),
			array('flaticon-film5'=>'film5'),
			array('flaticon-film6'=>'film6'),
			array('flaticon-find5'=>'find5'),
			array('flaticon-flag86'=>'flag86'),
			array('flaticon-flash3'=>'flash3'),
			array('flaticon-folder25'=>'folder25'),
			array('flaticon-folder29'=>'folder29'),
			array('flaticon-folder47'=>'folder47'),
			array('flaticon-game84'=>'game84'),
			array('flaticon-gaming'=>'gaming'),
			array('flaticon-garbage2'=>'garbage2'),
			array('flaticon-gear65'=>'gear65'),
			array('flaticon-gift84'=>'gift84'),
			array('flaticon-global47'=>'global47'),
			array('flaticon-golf32'=>'golf32'),
			array('flaticon-gps6'=>'gps6'),
			array('flaticon-graphic6'=>'graphic6'),
			array('flaticon-hands2'=>'hands2'),
			array('flaticon-hardware2'=>'hardware2'),
			array('flaticon-home166'=>'home166'),
			array('flaticon-house158'=>'house158'),
			array('flaticon-house220'=>'house220'),
			array('flaticon-identity3'=>'identity3'),
			array('flaticon-ipad27'=>'ipad27'),
			array('flaticon-ipod3'=>'ipod3'),
			array('flaticon-keyboard55'=>'keyboard55'),
			array('flaticon-keyboard6'=>'keyboard6'),
			array('flaticon-lamps2'=>'lamps2'),
			array('flaticon-laptop13'=>'laptop13'),
			array('flaticon-left-arrow5'=>'left-arrow5'),
			array('flaticon-left15'=>'left15'),
			array('flaticon-levels1'=>'levels1'),
			array('flaticon-life-preserver'=>'life-preserver'),
			array('flaticon-light110'=>'light110'),
			array('flaticon-light91'=>'light91'),
			array('flaticon-light92'=>'light92'),
			array('flaticon-lightbulb24'=>'lightbulb24'),
			array('flaticon-lightning23'=>'lightning23'),
			array('flaticon-linegraphic1'=>'linegraphic1'),
			array('flaticon-link13'=>'link13'),
			array('flaticon-link63'=>'link63'),
			array('flaticon-location46'=>'location46'),
			array('flaticon-locks'=>'locks'),
			array('flaticon-loudspeaker12'=>'loudspeaker12'),
			array('flaticon-loudspeaker13'=>'loudspeaker13'),
			array('flaticon-loudspeaker14'=>'loudspeaker14'),
			array('flaticon-mac4'=>'mac4'),
			array('flaticon-mac6'=>'mac6'),
			array('flaticon-magnifying-glass1'=>'magnifying-glass1'),
			array('flaticon-magnifying-glass2'=>'magnifying-glass2'),
			array('flaticon-magnifyingglass16'=>'magnifyingglass16'),
			array('flaticon-magnifyingglass43'=>'magnifyingglass43'),
			array('flaticon-mail96'=>'mail96'),
			array('flaticon-male26'=>'male26'),
			array('flaticon-map106'=>'map106'),
			array('flaticon-message31'=>'message31'),
			array('flaticon-messages'=>'messages'),
			array('flaticon-microphone112'=>'microphone112'),
			array('flaticon-microphone87'=>'microphone87'),
			array('flaticon-money198'=>'money198'),
			array('flaticon-moon155'=>'moon155'),
			array('flaticon-mountain36'=>'mountain36'),
			array('flaticon-mouse49'=>'mouse49'),
			array('flaticon-movie4'=>'movie4'),
			array('flaticon-musicplayer7'=>'musicplayer7'),
			array('flaticon-mute39'=>'mute39'),
			array('flaticon-newspapers2'=>'newspapers2'),
			array('flaticon-nintendo11'=>'nintendo11'),
			array('flaticon-notepad'=>'notepad'),
			array('flaticon-notepad30'=>'notepad30'),
			array('flaticon-ok'=>'ok'),
			array('flaticon-options8'=>'options8'),
			array('flaticon-outbox4'=>'outbox4'),
			array('flaticon-padlock3'=>'padlock3'),
			array('flaticon-padlock50'=>'padlock50'),
			array('flaticon-padlock51'=>'padlock51'),
			array('flaticon-padlock53'=>'padlock53'),
			array('flaticon-paint104'=>'paint104'),
			array('flaticon-paper30'=>'paper30'),
			array('flaticon-pencil112'=>'pencil112'),
			array('flaticon-pencil17'=>'pencil17'),
			array('flaticon-phone22'=>'phone22'),
			array('flaticon-phone43'=>'phone43'),
			array('flaticon-photocamera1'=>'photocamera1'),
			array('flaticon-photography23'=>'photography23'),
			array('flaticon-picture59'=>'picture59'),
			array('flaticon-picture7'=>'picture7'),
			array('flaticon-pie-chart1'=>'pie-chart1'),
			array('flaticon-pie-chart3'=>'pie-chart3'),
			array('flaticon-pie-chart4'=>'pie-chart4'),
			array('flaticon-play111'=>'play111'),
			array('flaticon-play120'=>'play120'),
			array('flaticon-playbutton5'=>'playbutton5'),
			array('flaticon-playbutton6'=>'playbutton6'),
			array('flaticon-playbutton7'=>'playbutton7'),
			array('flaticon-pointer3'=>'pointer3'),
			array('flaticon-power'=>'power'),
			array('flaticon-print61'=>'print61'),
			array('flaticon-printer90'=>'printer90'),
			array('flaticon-rain48'=>'rain48'),
			array('flaticon-repair17'=>'repair17'),
			array('flaticon-right-arrow6'=>'right-arrow6'),
			array('flaticon-right11'=>'right11'),
			array('flaticon-screen116'=>'screen116'),
			array('flaticon-screen54'=>'screen54'),
			array('flaticon-screwdriver26'=>'screwdriver26'),
			array('flaticon-settings56'=>'settings56'),
			array('flaticon-shining5'=>'shining5'),
			array('flaticon-shopping240'=>'shopping240'),
			array('flaticon-shopping45'=>'shopping45'),
			array('flaticon-shoppingcart12'=>'shoppingcart12'),
			array('flaticon-shoppingcart13'=>'shoppingcart13'),
			array('flaticon-shoppingstore1'=>'shoppingstore1'),
			array('flaticon-shut-down1'=>'shut-down1'),
			array('flaticon-sign15'=>'sign15'),
			array('flaticon-sign45'=>'sign45'),
			array('flaticon-signal48'=>'signal48'),
			array('flaticon-smartphone97'=>'smartphone97'),
			array('flaticon-snow42'=>'snow42'),
			array('flaticon-speech-bubble5'=>'speech-bubble5'),
			array('flaticon-speech-bubble6'=>'speech-bubble6'),
			array('flaticon-speechbubble46'=>'speechbubble46'),
			array('flaticon-speechbubble47'=>'speechbubble47'),
			array('flaticon-statistical1'=>'statistical1'),
			array('flaticon-suitcase17'=>'suitcase17'),
			array('flaticon-suitcase5'=>'suitcase5'),
			array('flaticon-suitcase7'=>'suitcase7'),
			array('flaticon-sun94'=>'sun94'),
			array('flaticon-symbol14'=>'symbol14'),
			array('flaticon-symbols6'=>'symbols6'),
			array('flaticon-tablet22'=>'tablet22'),
			array('flaticon-tablets8'=>'tablets8'),
			array('flaticon-technology25'=>'technology25'),
			array('flaticon-technology26'=>'technology26'),
			array('flaticon-technology35'=>'technology35'),
			array('flaticon-technology36'=>'technology36'),
			array('flaticon-television2'=>'television2'),
			array('flaticon-text151'=>'text151'),
			array('flaticon-thermometer6'=>'thermometer6'),
			array('flaticon-tick9'=>'tick9'),
			array('flaticon-tool44'=>'tool44'),
			array('flaticon-tool45'=>'tool45'),
			array('flaticon-travelling7'=>'travelling7'),
			array('flaticon-trees14'=>'trees14'),
			array('flaticon-trophy71'=>'trophy71'),
			array('flaticon-umbrella55'=>'umbrella55'),
			array('flaticon-unlocked47'=>'unlocked47'),
			array('flaticon-unlocked48'=>'unlocked48'),
			array('flaticon-up-arrow7'=>'up-arrow7'),
			array('flaticon-up-arrow9'=>'up-arrow9'),
			array('flaticon-up7'=>'up7'),
			array('flaticon-uparrow14'=>'uparrow14'),
			array('flaticon-update22'=>'update22'),
			array('flaticon-update23'=>'update23'),
			array('flaticon-update3'=>'update3'),
			array('flaticon-usb12'=>'usb12'),
			array('flaticon-user163'=>'user163'),
			array('flaticon-vibrate'=>'vibrate'),
			array('flaticon-videocamera6'=>'videocamera6'),
			array('flaticon-videocamera7'=>'videocamera7'),
			array('flaticon-volume55'=>'volume55'),
			array('flaticon-wallclock2'=>'wallclock2'),
			array('flaticon-wallet35'=>'wallet35'),
			array('flaticon-watch26'=>'watch26'),
			array('flaticon-wifi86'=>'wifi86'),
			array('flaticon-wireless10'=>'wireless10'),
			array('flaticon-worker22'=>'worker22'),
			array('flaticon-wrapped4'=>'wrapped4'),
			array('flaticon-wrench75'=>'wrench75'),
			array('flaticon-writingtool'=>'writingtool'),
			array('flaticon-zoom10'=>'zoom10'),
			array('flaticon-zoom75'=>'zoom75')
        );
        return array_merge( $icons, $markety_flaticon_array );
    }
    add_filter( 'vc_iconpicker-type-flaticon', 'vc_iconpicker_type_flaticon' );


    function vc_iconpicker_base_register_flaticon_css(){
        wp_register_style( 'flaticon', get_template_directory_uri() . '/fonts/flaticon/flaticon.css', false, WPB_VC_VERSION, 'screen' );
    }
    add_action( 'vc_base_register_front_css', 'vc_iconpicker_base_register_flaticon_css' );
    add_action( 'vc_base_register_admin_css', 'vc_iconpicker_base_register_flaticon_css' );