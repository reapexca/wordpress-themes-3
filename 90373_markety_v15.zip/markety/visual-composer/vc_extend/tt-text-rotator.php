<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    //Text Rotator element
    vc_map( array(
        'name'        => esc_html__( 'Text Rotator', 'markety' ),
        'base'        => 'tt_text_rotator',
        'icon'        => 'fa fa-cube',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Show off text rotator effect in your page', 'markety' ),
        'params'      => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Rotator text', 'markety' ),
                'param_name'  => 'title',
                'admin_label' => true,
                'description' => esc_html__( 'Enter rotator text, separate text with "|", e.g: Creating a country  | for every citizen | leading people | to better quality life', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Animation', 'markety' ),
                'param_name'  => 'animation',
                'admin_label' => true,
                'value'       => array(
                    esc_html__('select animation', 'markety')   => '',
                    esc_html__('dissolve', 'markety')   => 'dissolve',
                    esc_html__('fade', 'markety')       => 'fade',
                    esc_html__('flip', 'markety')       => 'flip',
                    esc_html__('flipUp', 'markety')     => 'flipUp',
                    esc_html__('flipCube', 'markety')   => 'flipCube',
                    esc_html__('flipCubeUp', 'markety') => 'flipCubeUp',
                    esc_html__('spin', 'markety')       => 'spin'
                ),
                'description' => esc_html__( 'You can pick the way it animates when rotating through words, default: dissolve', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Animation speed', 'markety' ),
                'param_name'  => 'animation_speed',
                'admin_label' => true,
                'value'       => 3000,
                'description' => esc_html__( 'How many milliseconds until the next word show.', 'markety' )
            ),


            array(
                'type'          => 'textarea_html',
                'heading'       => esc_html__( 'Intro title', 'markety' ),
                'param_name'    => 'content',
                'admin_label'   => true,
                'description'   => esc_html__( 'Enter intro title', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content alignment', 'markety' ),
                'param_name'  => 'title_alignment',
                'value'       => array(
                    esc_html__('Select title alignment', 'markety') => '',
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety')  =>'text-center',
                    esc_html__('Right', 'markety')  =>'text-right' 
                ),
                'description' => esc_html__( 'Select content alignment', 'markety' )
            ),
            
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Show learn more button ?', 'markety' ),
                'param_name'  => 'show_button',
                'value'       => array(
                    esc_html__('Select an option', 'markety') => '',
                    esc_html__('Yes', 'markety') => 'yes',
                    esc_html__('No', 'markety') => 'no'
                    
                ),
                'admin_label' => true,
                'description' => esc_html__( 'If you want to show button then select yes', 'markety')
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Button text', 'markety' ),
                'param_name'  => 'button_text',
                'value'       => esc_html__('Learn More', 'markety' ),
                'admin_label' => true,
                'description' => esc_html__( 'Change button text', 'markety' ),
                'dependency' => Array(
                    'element' => 'show_button', 
                    'value' => array('yes')
                )
            ),

            array(
                'type'        => 'vc_link',
                'heading'     => esc_html__( 'Button link', 'markety' ),
                'param_name'  => 'custom_link',
                'description' => esc_html__( 'Enter custom link or select existing page as link', 'markety' ),
                'dependency' => Array(
                    'element' => 'show_button',
                    'value' => array('yes')
                )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Button class', 'markety' ),
                'param_name'  => 'button_class',
                'admin_label' => true,
                'description' => esc_html__( 'Use button class field to style particularly', 'markety' ),
                'dependency' => Array(
                    'element' => 'show_button', 
                    'value' => array('yes')
                )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Text_Rotator extends WPBakeryShortCode {
        }
    }
endif;