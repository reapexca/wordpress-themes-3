<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Icon blog element
    vc_map( array(
        'name'        => esc_html__( 'TT Case Study Block', 'markety' ),
        'base'        => 'tt_case_study_block',
        'icon'        => 'fa fa-keyboard-o',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Show off simple case study block', 'markety' ),
        'params'      => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Title', 'markety' ),
                'param_name'  => 'title',
                'holder' => 'h3',
                'description' => esc_html__( 'Enter intro title here', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Title color', 'markety' ),
                'param_name'  => 'title_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  => 'custom-color',
                ),
                'description' => esc_html__( 'If you change default title color then select custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'title_color',
                'description' => esc_html__( 'change title color', 'markety' ),
                'dependency'  => array(
                    'element' => 'title_color_option',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'textarea_html',
                'heading'     => esc_html__( 'Content', 'markety' ),
                'param_name'  => 'content',
                'description' => esc_html__( 'Enter content here.', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content color', 'markety' ),
                'param_name'  => 'content_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  => 'custom-color',
                ),
                'std'         => 'default-color',
                'description' => esc_html__( 'If you change default content color then select custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'content_color',
                'description' => esc_html__( 'Change content color', 'markety' ),
                'dependency'  => array(
                    'element' => 'content_color_option',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content Background', 'markety' ),
                'param_name'  => 'content_background',
                'value'       => array(
                    esc_html__('Select background color', 'markety') => '',
                    esc_html__('Theme Color', 'markety') => 'theme-bg', 
                    esc_html__('Dark Color', 'markety') => 'dark-bg',
                    esc_html__('Custom color', 'markety')  => 'custom-color', 
                ),
                'description' => esc_html__( 'Select content background color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'content_background_color',
                'description' => esc_html__( 'Change content background color', 'markety' ),
                'dependency'  => array(
                    'element' => 'content_background',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content position', 'markety' ),
                'param_name'  => 'content_position',
                'value'       => array(
                    esc_html__('Select content position', 'markety') => '',
                    esc_html__('Left section', 'markety') => 'case-study-left',
                    esc_html__('Right section', 'markety')  => 'case-study-right'
                ),
                'description' => esc_html__( 'Select content section position', 'markety' )
            ),

			array(
                "type" => "dropdown",
                "heading" => esc_html__("Button visibility", 'markety'),
                "param_name" => "button_visibility",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety') => 'hidden'
                ),
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Select button visibility option", 'markety')
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__("Button text", 'markety'),
                "param_name" => "button_text",
                "description" => esc_html__("Enter button text", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "vc_link",
                "heading" => esc_html__("Button link", 'markety'),
                "param_name" => "button_link",
                "description" => esc_html__("Enter button link", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button style", 'markety'),
                "param_name" => "button_style",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Primary', 'markety') => 'btn-primary',
                    esc_html__('White', 'markety') => 'btn-default',
                    esc_html__('Outline', 'markety') => 'btn-outline',
                ),
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Select button position", 'markety'),
                "dependency" => array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button size", 'markety'),
                "param_name" => "button_size",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Small', 'markety') => 'btn-sm',
                    esc_html__('Normal', 'markety') => 'btn-md',
                    esc_html__('Large', 'markety') => 'btn-lg'
                ),
                "description" => esc_html__("Select button position", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));


    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_TT_Case_Study_Block extends WPBakeryShortCode {
        }
    }
endif;
