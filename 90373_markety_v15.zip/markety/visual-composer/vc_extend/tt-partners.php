<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Partners element
    vc_map( array(
        'name'        => esc_html__( 'TT Partners', 'markety' ),
        'base'        => 'tt_partners',
        'icon'        => 'fa fa-users',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Show off partners logo', 'markety' ),
        'params'      => array(

            array(
                'type'          => 'attach_images',
                'heading'       => esc_html__( 'Images', 'markety'),
                'param_name'    => 'images',
                'description'   => esc_html__( 'Select images from media library.', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Apply image effect ?', 'markety' ),
                'param_name'    => 'image_effect',
                'value'         => array(
                    esc_html__( 'Black and White image', 'markety' ) => 'black_white',
                    esc_html__( 'Original Image', 'markety' ) => 'original_image'
                ),
                'std'           => 'original_image',
                'admin_label'   => true,
                'description'   => esc_html__( 'Select image effect', 'markety' ),
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'On click action', 'markety' ),
                'param_name'    => 'on_click_action',
                'value'         => array(
                    esc_html__( 'Do nothing', 'markety' ) => '',
                    esc_html__( 'Open custom link', 'markety' ) => 'custom_link'
                ),
                'admin_label'   => true,
                'description'   => esc_html__( 'Define action for onclick event if needed.', 'markety' )
            ),

            array(
                'type'          => 'exploded_textarea',
                'heading'       => esc_html__( 'Custom links', 'markety'),
                'param_name'    => 'links',
                'description'   => esc_html__( 'Enter links for each logo here. Divide links with linebreaks (Enter)', 'markety' ),
                'dependency'    => array(
                    'element'   => 'on_click_action', 
                    'value'     => array( 'custom_link' )
                )
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Item height', 'markety' ),
                'param_name'    => 'item_height',
                'value'         => '200px',
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Enter item height in px, e.g: 200px', 'markety' )
            ),
            array(
                'type'          => 'colorpicker',
                'heading'       => esc_html__( 'Item background color', 'markety' ),
                'param_name'    => 'item_bg',
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Change item background color if needed', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Top/bottom border style', 'markety' ),
                'param_name'    => 'item_top_border',
                'value'         => array(
                    esc_html__( 'Top border style', 'markety' ) => 'item-top-border',
                    esc_html__( 'Bottom border style', 'markety' ) => 'item-bottom-border',
                    esc_html__( 'Disable', 'markety' ) => ''
                ),
                'std'           => 'item-top-border',
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Select top or bottom border style here', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Show/Hide item border', 'markety' ),
                'param_name'    => 'item_border',
                'value'         => array(
                    esc_html__( 'Show', 'markety' ) => 'item-border-show',
                    esc_html__( 'Hide', 'markety' ) => 'item-border-hide'
                ),
                'std'           => 'item-border-show',
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'show or hide item border', 'markety' )
            ),

            array(
                'type'          => 'colorpicker',
                'heading'       => esc_html__( 'Item border color', 'markety' ),
                'param_name'    => 'item_border_color',
                'group'         => 'Carousel Settings',
                'dependency'    => array(
                    'element'   => 'item_border', 
                    'value'     => array( 'item-border-show' )
                ),
                'description'   => esc_html__( 'Change item border color if needed', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Show/hide navigation', 'markety' ),
                'param_name'    => 'navigation_visibility',
                'value'         => array(
                    esc_html__( 'Show', 'markety' ) => 'show',
                    esc_html__( 'Hide', 'markety' ) => 'hide'
                ),
                'std'           => 'show',
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Navigation visibility option', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Navigation position', 'markety' ),
                'param_name'    => 'nav_position',
                'value'         => array(
                    esc_html__( 'Top', 'markety' ) => 'nav-pos-top',
                    esc_html__( 'Bottom', 'markety' ) => 'nav-pos-bottom',
                    esc_html__( 'Center', 'markety' ) => 'nav-pos-center',
                    esc_html__( 'Left and Right', 'markety' ) => 'nav-pos-left-right'
                ),
                'admin_label'   => true,
                'dependency'    => array(
                    'element'   => 'navigation_visibility', 
                    'value'     => array( 'show' )
                ),
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Select navigation position', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Carousel row', 'markety' ),
                'param_name'    => 'carousel_row',
                'value'         => array(
                    esc_html__( 'Single', 'markety' ) => '1',
                    esc_html__( 'Double', 'markety' ) => '2'
                ),
                'admin_label'   => true,
                'group'         => 'Carousel Settings',
                'description'   => esc_html__( 'Select row option', 'markety' )
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Default large screen item, e.g: min width 1200px', 'markety'),
                'param_name'    => 'large_screen',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety'),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 4
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Desktop e.g: max width 1199px', 'markety'),
                'param_name'    => 'items_desktop',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety'),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 4
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Tablet e.g: max width 768px', 'markety' ),
                'param_name'    => 'items_tablet',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 3
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Mobile landscape e.g: max width 640px', 'markety' ),
                'param_name'    => 'items_mobile_landscape',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 2
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Mobile e.g: max width 320px', 'markety' ),
                'param_name'    => 'items_mobile',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),


            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Item gutter', 'markety'),
                'param_name'    => 'item_gutter',
                'description'   => esc_html__( 'Add gutter between items', 'markety'),
                'admin_label'   => true,
                'value'         => 0
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                "type"          => "textfield",
                "heading"       => esc_html__( "Extra class name", 'markety' ),
                "param_name"    => "el_class",
                "description"   => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'markety' )
            )
        )
    ));


    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Partners extends WPBakeryShortCode {
        }
    }
endif;