<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // TT Google mp element
    vc_map( array(
        'name'        => esc_html__( 'TT Google map', 'markety' ),
        'base'        => 'tt_google_map',
        'icon'        => 'fa fa-map-marker',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Custom google map', 'markety' ),
        'params'      => array(
            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Map Height', 'markety' ),
                'param_name'    => 'map_height',
                'admin_label'   => true,
                'value'         => '450px',
                'group'         => 'Map Settings',
                'description'   => esc_html__( 'Enter map height in px, e.g: 450px', 'markety' )
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Zoom', 'markety' ),
                'param_name'    => 'map_zoom',
                'admin_label'   => true,
                'value'         => 14,
                'group'         => 'Map Settings',
                'description'   => esc_html__( 'Enter map zoom', 'markety' )
            ),

            array(
                'type'          => 'param_group',
                'heading'       => esc_html__('Map info', 'markety'),
                'param_name'    => 'map_content',
                'group'         => 'Map info',
                'description'   => esc_html__('Enter map info', 'markety'),
                'params' => array(
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Latitude', 'markety' ),
                        'param_name'  => 'tt_latitude',
                        'admin_label' => true,
                        'description' => esc_html__( 'Enter address latitude number, If you unable to find latitude and longitude of your address. Please visit http://www.latlong.net/convert-address-to-lat-long.html you can easily generate.', 'markety' )
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Longitude', 'markety' ),
                        'param_name'  => 'tt_longitude',
                        'admin_label' => true,
                        'description' => esc_html__( 'Enter address longitude number', 'markety' )
                    ),
                    array(
                        'type'        => 'textarea_safe',
                        'heading'     => esc_html__( 'Info content', 'markety' ),
                        'param_name'  => 'info_content',
                        'description' => esc_html__( 'Enter info content here', 'markety' )
                    ),
                    array(
                        'type'        => 'attach_image',
                        'heading'     => esc_html__( 'Map marker', 'markety' ),
                        'param_name'  => 'map_marker',
                        'description' => esc_html__( 'Upload map marker from media library', 'markety' )
                    )
                ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Google_Map extends WPBakeryShortCode {
        }
    }
endif;