<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // TT Portfolio element
    vc_map( array(
        'name'        => esc_html__( 'TT Portfolio', 'markety' ),
        'base'        => 'tt_portfolio',
        'icon'        => 'fa fa-th',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'To showcase your portfolio with grid view', 'markety' ),
        'params'      => array(
            
            array(
                'type'          => 'textfield',
                'heading'       => esc_html__('Post Limit', 'markety'),
                'param_name'    => 'post_limit',
                'admin_label'   => true,
                'value'         => -1,
                'description'   => esc_html__('Put the number of posts to show, -1 for no limit', 'markety'),
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Grid column', 'markety' ),
                'param_name'    => 'grid_column',
                'value'         => array(
                    esc_html__('Select column', 'markety') => '',
                    esc_html__('2 Columns', 'markety') => 6,
                    esc_html__('3 Columns', 'markety') => 4,
                    esc_html__('4 Columns', 'markety') => 3
                ),
                'description'   => esc_html__( 'Select post grid column', 'markety' ),
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Grid padding', 'markety' ),
                'param_name'    => 'grid_padding',
                'value'         => array(
                    esc_html__('Yes', 'markety') => 'yes',
                    esc_html__('No', 'markety')  =>'no'
                ),
                'admin_label'   => true,
                'description'   => esc_html__( 'Grid padding will appear between item', 'markety' ),
            ),

            // Filter style
            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Filter visibility ', 'markety' ),
                'param_name'    => 'filter_visibility',
                'value'         => array(
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety')  =>'hidden',
                ),
                'std'           => 'visible',
                'admin_label'   => true,
                'group'         => esc_html__( 'Filter style', 'markety' ),
                'description'   => esc_html__( 'If you do not like to show filter then select hidden', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Filter style', 'markety' ),
                'param_name'    => 'filter_style',
                'value'         => array(
                    esc_html__('Square', 'markety')      => 'filter-square',
                    esc_html__('Round', 'markety')       => 'filter-round',
                    esc_html__('Rounded', 'markety')     => 'filter-rounded',
                    esc_html__('Outline', 'markety')     => 'filter-outline',
                    esc_html__('Transparent', 'markety') => 'filter-transparent'
                ),
                'std'           => 'filter-circle',
                'admin_label'   => true,
                'group'         => esc_html__( 'Filter style', 'markety' ),
                'description'   => esc_html__( 'Select filter style', 'markety' ),
                'dependency'    => array(
                    'element'   => 'filter_visibility',
                    'value'     => array('visible')
                )
            ),

            // Filter alignment
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Filter alignment', 'markety' ),
                'param_name'  => 'filter_alignment',
                'value'       => array(
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety')  =>'text-center',
                    esc_html__('Right', 'markety')  =>'text-right' 
                ),
                'std'           => 'text-center',
                'admin_label'   => true,
                'group'         => esc_html__( 'Filter style', 'markety' ),
                'description'   => esc_html__( 'Select filter alignment', 'markety' ),
                'dependency'    => array(
                    'element'   => 'filter_visibility',
                    'value'     => array('visible')
                )
            ),

            // Filter color
            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Filter color', 'markety' ),
                'param_name'    => 'filter_color',
                'value'         => array(
                    esc_html__('Default color', 'markety') => 'theme-default',
                    esc_html__('Dark color', 'markety')    => 'dark-color'
                ),
                'std'           => 'default-color',
                'admin_label'   => true,
                'group'         => esc_html__( 'Filter style', 'markety' ),
                'description'   => esc_html__( 'Select filter color', 'markety' ),
                'dependency'    => array(
                    'element'   => 'filter_visibility',
                    'value'     => array('visible')
                )
            ),

            // background image
            array(
                'type'        => 'attach_images',
                'heading'     => esc_html__( 'Background Images', 'markety' ),
                'param_name'  => 'portfolio_mask',
                'description' => esc_html__( 'Upload portfolio background image', 'markety' )
            ),


            // visibility options
            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Title', 'markety' ),
                'param_name'    => 'title_visibility',
                'value'         => array(
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety')  =>'hidden' ,
                ),
                'std'           => 'visible',
                'group'         => esc_html__( 'Visibility Options', 'markety' ),
                'description'   => esc_html__( 'If do not like to show title then select hidden', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Link icon button', 'markety' ),
                'param_name'    => 'link_button_visibility',
                'value'         => array(
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety')  =>'hidden' ,
                ),
                'std'           => 'visible',
                'group'         => esc_html__( 'Visibility Options', 'markety' ),
                'description'   => esc_html__( 'If do not like to show link button then select hidden', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Category', 'markety' ),
                'param_name'    => 'category_visibility',
                'value'         => array(
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety')  =>'hidden' ,
                ),
                'std'           => 'visible',
                'group'         => esc_html__( 'Visibility Options', 'markety' ),
                'description'   => esc_html__( 'If do not like to show category then select hidden', 'markety' )
            ),

            array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Background mask', 'markety' ),
                'param_name'    => 'mask_visibility',
                'value'         => array(
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety')  =>'hidden' ,
                ),
                'std'           => 'visible',
                'group'         => esc_html__( 'Visibility Options', 'markety' ),
                'description'   => esc_html__( 'If do not like to show background mask then select hidden', 'markety' )
            ),

            array(
                'type'          => 'css_editor',
                'heading'       => esc_html__( 'Css', 'markety' ),
                'param_name'    => 'css',
                'group'         => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Extra class name', 'markety' ),
                'param_name'    => 'el_class',
                'description'   => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));


    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Portfolio extends WPBakeryShortCode {
        }
    }
endif;