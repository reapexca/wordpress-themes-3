<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Section title style element
    vc_map( array(
        'name'        => esc_html__( 'Section Title', 'markety' ),
        'base'        => 'tt_section_title',
        'icon'        => 'fa fa-align-center',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'To customize section title style', 'markety' ),
        'params'      => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Title', 'markety' ),
                'param_name'  => 'title',
                'holder'      => 'h3',
                'description' => esc_html__( 'Enter title here', 'markety' )
            ),


            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Font Weight', 'markety' ),
                'param_name'  => 'font_weight',
                'value'       => array(
                    esc_html__('Light', 'markety') => '300',
                    esc_html__('Regular', 'markety')  =>'400',
                    esc_html__('Medium', 'markety')  =>'500',
                    esc_html__('Bold', 'markety')  =>'700', 
                    esc_html__('Extra Bold', 'markety')  =>'900' 
                ),
                'std'       => '300',
                'description' => esc_html__( 'Select title text transform', 'markety' )
            ),


            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Text Transform', 'markety' ),
                'param_name'  => 'text_transform',
                'value'       => array(
                    esc_html__('Default', 'markety') => '',
                    esc_html__('Uppercase', 'markety') => 'uppercase',
                    esc_html__('Capitalize', 'markety')  =>'capitalize',
                    esc_html__('Lowercase', 'markety')  =>'lowercase' 
                ),
                'description' => esc_html__( 'Select title text transform', 'markety' )
            ),


            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Alignment', 'markety' ),
                'param_name'  => 'title_alignment',
                'value'       => array(
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety')  =>'text-center',
                    esc_html__('Right', 'markety')  =>'text-right' 
                ),
                'description' => esc_html__( 'Select title alignment', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Title color option', 'markety' ),
                'param_name'  => 'title_color_option',
                'value'       => array(
                    esc_html__('Default Color', 'markety') => '',
                    esc_html__('Theme Color', 'markety')  =>'theme-color',
                    esc_html__('Custom Color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default title color then select theme color or select any custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Custom color', 'markety' ),
                'param_name'  => 'title_color',
                'description' => esc_html__( 'Change title color', 'markety' ),
                'dependency'  => array(
                    'element' => 'title_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),

            array(
                'type'        => 'textarea_html',
                'heading'     => esc_html__( 'Sub title description', 'markety' ),
                'param_name'  => 'content',
                'holder'      => 'span',
                'description' => esc_html__( 'Description will appear on after title bottom separator', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Description color option', 'markety' ),
                'param_name'  => 'description_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default description text color then select custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Custom color', 'markety' ),
                'param_name'  => 'description_color',
                'description' => esc_html__( 'Change description text color', 'markety' ),
                'dependency'  => array(
                    'element' => 'description_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Separator show/hide', 'markety' ),
                'param_name'  => 'section_separator',
                'value'       => array(
                    esc_html__('Select an option', 'markety') => '',
                    esc_html__('Show', 'markety') => 'yes',
                    esc_html__('Hide', 'markety')  =>'no' ,
                    ),
                'description' => esc_html__( 'If you want to hide section separator then select hide', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Separator position', 'markety' ),
                'param_name'  => 'separator_position',
                'value'       => array(
                    esc_html__('Select separator position', 'markety') => '',
                    esc_html__('Top of the title', 'markety') => 'befor_title',
                    esc_html__('Bottom of the title', 'markety') => 'after_title',
                    esc_html__('Bottom of the description', 'markety')  =>'after_description',
                ),
                'description' => esc_html__( 'You can change separator postion from here', 'markety' ),
                'dependency'  => array(
                    'element' => 'section_separator',
                    'value'   => array( 'yes' )
                ),
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Separator color', 'markety' ),
                'param_name'  => 'separator_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default separator color then select custom color', 'markety' ),
                'dependency'  => array(
                    'element' => 'section_separator',
                    'value'   => array( 'yes' )
                ),
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Custom color', 'markety' ),
                'param_name'  => 'separator_color',
                'description' => esc_html__( 'change border color', 'markety' ),
                'dependency'  => array(
                    'element' => 'separator_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_TT_Section_Title extends WPBakeryShortCode {
        }
    }
endif;