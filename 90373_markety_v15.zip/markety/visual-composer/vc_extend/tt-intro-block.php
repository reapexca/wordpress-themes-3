<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Icon blog element
    vc_map( array(
        'name'        => esc_html__( 'Intro Block', 'markety' ),
        'base'        => 'tt_intro_block',
        'icon'        => 'fa fa-keyboard-o',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Introduction Block', 'markety' ),
        'params'      => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Intro Title', 'markety' ),
                'param_name'  => 'title',
                'holder' => 'h3',
                'description' => esc_html__( 'Enter intro title here', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Intro Title color', 'markety' ),
                'param_name'  => 'title_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default title color then select custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'title_color',
                'description' => esc_html__( 'change title color', 'markety' ),
                'dependency'  => Array(
                    'element' => 'title_color_option',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content alignment', 'markety' ),
                'param_name'  => 'content_alignment',
                'value'       => array(
                    esc_html__('Select content alignment', 'markety') => '',
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety')  =>'text-center',
                    esc_html__('Right', 'markety')  =>'text-right' 
                ),
                'description' => esc_html__( 'Select content alignment', 'markety' )
            ),


            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content color', 'markety' ),
                'param_name'  => 'content_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Custom color', 'markety')  =>'custom-color',
                ),
                'std'         => 'default-color',
                'description' => esc_html__( 'If you change default content color then select custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'content_color',
                'description' => esc_html__( 'Change content color', 'markety' ),
                'dependency'  => Array(
                    'element' => 'content_color_option',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content Background', 'markety' ),
                'param_name'  => 'content_background',
                'value'       => array(
                    esc_html__('Select background color', 'markety') => '',
                    esc_html__('Theme Color', 'markety') => 'theme-bg', 
                    esc_html__('Dark Color', 'markety') => 'dark-bg',
                    esc_html__('Custom color', 'markety')  =>'custom-color', 
                ),
                'description' => esc_html__( 'Select content background color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'content_background_color',
                'description' => esc_html__( 'Change content background color', 'markety' ),
                'dependency'  => Array(
                    'element' => 'content_background',
                    'value'   => array( 'custom-color' )
                )
            ),


            array(
                'type'        => 'textarea_html',
                'heading'     => esc_html__( 'Text', 'markety' ),
                'param_name'  => 'content',
                'description' => esc_html__( 'Enter content here.', 'markety' )
            ),



            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Set custom link ?', 'markety' ),
                'param_name'  => 'custom_link',
                'value'       => array(
                    esc_html__('No', 'markety') => 'no',
                    esc_html__('Yes', 'markety')  =>'yes',
                ),
                'description' => esc_html__( 'If you want to set custom link then select yes, the link will appear on title', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Readmore Text', 'markety' ),
                'param_name'  => 'readmore_title',
                'holder' => 'span',
                'description' => esc_html__( 'Enter readmore text here', 'markety' ),
                'dependency'  => Array(
                    'element' => 'custom_link',
                    'value'   => array( 'yes' )
                )
            ),


            array(
                'type'        => 'vc_link',
                'heading'     => esc_html__( 'Link', 'markety' ),
                'param_name'  => 'link',
                'description' => esc_html__( 'Enter link or select page as link', 'markety' ),
                'dependency'  => Array(
                    'element' => 'custom_link',
                    'value'   => array( 'yes' )
                )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));


    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Intro_Block extends WPBakeryShortCode {
        }
    }
endif;
