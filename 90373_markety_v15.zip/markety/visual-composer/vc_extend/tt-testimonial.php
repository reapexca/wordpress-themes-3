<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if( function_exists('vc_map') ) :

	// TT testimonial element
	vc_map( array(
        'name'        => esc_html__( 'Testimonial Carousel', 'markety' ),
        'base'        => 'tt_testimonial',
        'icon'        => 'fa fa-picture-o',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Show off testimonial', 'markety' ),
        'params'      => array(
			
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Carousel style', 'markety' ),
				'param_name'  => 'carousel_style',
				'admin_label' => true,
				'value' 	  => array(
					esc_html__('Creative Carousel', 'markety') => 'carousel-creative',
					esc_html__('Standard Carousel', 'markety') => 'carousel-standard'
				),
				'admin_label' => true,
				'description' => esc_html__( 'Select carousel style', 'markety' )
			),

			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Content align', 'markety' ),
				'param_name'  => 'content_align',
				'admin_label' => true,
				'value' 	  => array(
					esc_html__('Left', 'markety') => 'text-left',
					esc_html__('Center', 'markety') => 'text-center',
					esc_html__('Right', 'markety') => 'text-right'
				),
				'description' => esc_html__( 'Select content align option', 'markety' )
			),

			array(
                'type'          => 'param_group',
                'heading'       => esc_html__('Testimonial info', 'markety'),
                'param_name'    => 'testimonial_info',
                'description'   => esc_html__('Enter testimonial info (click toggle row to input data)', 'markety'),
                'group'         => 'Testimonial Info',
                'params' => array(
                    
                	array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Use photo?', 'markety' ),
						'param_name'  => 'photo_option',
						'admin_label' => true,
						'value' 	  => array(
							esc_html__('No', 'markety') => 'no',
							esc_html__('Yes', 'markety') => 'yes'
						),
						'description' => esc_html__( 'If you want to use photo then select yes', 'markety' )
					),

					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'markety' ),
						'param_name'  => 'client_image',
						'description' => esc_html__( 'Select images from media library, dimension: 100x100', 'markety' ),
						'dependency'  => array(
							'element' => 'photo_option', 
							'value'   => array('yes')
						)
					),

					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Use video', 'markety' ),
						'param_name'  => 'quote_video',
						'value' 	  => array(
							esc_html__('No', 'markety') => 'no',
							esc_html__('Yes', 'markety') => 'yes'
						),
						'description' => esc_html__( 'If you want to use icon on top of quote text then select yes', 'markety' )
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video URL', 'markety' ),
						'param_name'  => 'video_url',
						'description' => esc_html__( 'Enter youtube or vemio video url here', 'markety' ),
						'dependency'  => array(
							'element' => 'quote_video', 
							'value'   => array('yes')
						)
					),

					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Video icon color', 'markety' ),
						'param_name'  => 'icon_color',
						'value'		  => '#000000',
						'description' => esc_html__( 'Change icon color', 'markety' ),
						'dependency'  => array(
							'element' => 'quote_video', 
							'value'   => array('yes')
						)
					),

					array(
						'type'        	=> 'textfield',
						'heading'     	=> esc_html__( 'Name', 'markety' ),
						'param_name'  	=> 'client_name',
						'holder'		=> 'h3',
						'admin_label'   => true,
						'description' 	=> esc_html__( 'Enter name', 'markety' )
					),

					array(
						'type'        	=> 'textfield',
						'heading'     	=> esc_html__( 'Organization/Designation', 'markety' ),
						'param_name'  	=> 'client_org',
						'admin_label'   => true,
						'description' 	=> esc_html__( 'Enter Organization name or designation' , 'markety' )
					),

					array(
						'type'        	=> 'textarea',
						'heading'     	=> esc_html__( 'Quote', 'markety' ),
						'param_name'  	=> 'content',
						'description' 	=> esc_html__( 'Enter testimonial quote', 'markety' )
					)
                ),
            ),

			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Client name text color', 'markety' ),
				'param_name'  => 'client_text_color',
				'group' 	  => 'Color Options',
				'description' => esc_html__( 'Change client text color', 'markety' )
			),

			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Client Organization/Designation text color', 'markety' ),
				'param_name'  => 'client_org_text_color',
				'group' 	  => 'Color Options',
				'description' => esc_html__( 'Change client organization/designation text color', 'markety' )
			),

			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Client quote text color', 'markety' ),
				'param_name'  => 'client_quote_text_color',
				'group' 	  => 'Color Options',
				'description' => esc_html__( 'Change client quote text color', 'markety' )
			),

			array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Carousel row', 'markety' ),
                'param_name'    => 'carousel_row',
                'value'         => array(
                    esc_html__( 'Single', 'markety' ) => '1',
                    esc_html__( 'Double', 'markety' ) => '2'
                ),
                'group' 	  	=> 'Carousel Settings',
                'admin_label'   => true,
                'description'   => esc_html__( 'Select row option', 'markety' )
            ),

			array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Show/hide navigation', 'markety' ),
                'param_name'    => 'navigation_visibility',
                'value'         => array(
                    esc_html__( 'Show', 'markety' ) => 'show',
                    esc_html__( 'Hide', 'markety' ) => 'hide'
                ),
                'std'			=> 'hide',
                'group' 	  	=> 'Carousel Settings',
                'description'   => esc_html__( 'Navigation visibility option', 'markety' )
            ),

			array(
                'type'          => 'dropdown',
                'heading'       => esc_html__( 'Show/hide pagination', 'markety' ),
                'param_name'    => 'pagination_visibility',
                'value'         => array(
                    esc_html__( 'Show', 'markety' ) => 'show',
                    esc_html__( 'Hide', 'markety' ) => 'hide'
                ),
                'std'			=> 'hide',
                'group' 	  	=> 'Carousel Settings',
                'description'   => esc_html__( 'Pagination visibility option', 'markety' )
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Default large screen item, e.g: min width 1200px', 'markety'),
                'param_name'    => 'large_screen',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety'),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Desktop e.g: max width 1199px', 'markety'),
                'param_name'    => 'items_desktop',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety'),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Tablet e.g: max width 768px', 'markety' ),
                'param_name'    => 'items_tablet',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Mobile landscape e.g: max width 640px', 'markety' ),
                'param_name'    => 'items_mobile_landscape',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Items Mobile e.g: max width 320px', 'markety' ),
                'param_name'    => 'items_mobile',
                'description'   => esc_html__( 'Put the number of amount that you want to show at a time', 'markety' ),
                'group'         => esc_html__('Responsive Settings', 'markety'),
                'admin_label'   => true,
                'value'         => 1
            ),

            array(
                'type'          => 'textfield',
                'heading'       => esc_html__( 'Item gutter', 'markety'),
                'param_name'    => 'item_gutter',
                'description'   => esc_html__( 'Add gutter between items', 'markety'),
                'admin_label'   => true,
                'value'         => 0
            ),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Extra class name', 'markety' ),
				'param_name'  => 'el_class',
				'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
			),

			array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            )
		)
	));

	if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Testimonial extends WPBakeryShortCode {
        }
    }

endif;