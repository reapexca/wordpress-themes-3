<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // TT Member element
    vc_map( array(
        'name'                    => esc_html__( 'Members', 'markety' ),
        'base'                    => 'tt_member',
        'icon'                    => 'fa fa-user',
        'category'                => esc_html__( 'TT Elements', 'markety' ),
        'description'             => esc_html__( 'Show off member', 'markety' ),
        'params'                  => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Member Limit', 'markety' ),
                'param_name'  => 'post_limit',
                'value'       => -1,
                'admin_label' => true,
                'description' => esc_html__( 'Enter member post number to display member, -1 for no limit', 'markety' )
            ),

            array(
                 'type'         => 'dropdown',
                 'heading'      => esc_html__('Select grid column', 'markety'),
                 'param_name'   => 'grid_column',
                 'value'        => array(
                      esc_html__('Select grid column', 'markety') => '',
                      esc_html__('2 Columns', 'markety') => '6',
                      esc_html__('3 Columns', 'markety') => '4',
                      esc_html__('4 Columns', 'markety') => '3',
                  ),
                 'std'          => '3',
                 'admin_label'  => true,
                 'description'  => esc_html__('Select grid column', 'markety'),
            ),

            array(
                 'type'         => 'dropdown',
                 'heading'      => esc_html__('Show content?', 'markety'),
                 'param_name'   => 'content_visibility',
                 'value'        => array(
                      esc_html__('Yes', 'markety') => 'yes',
                      esc_html__('No', 'markety') => 'no'
                  ),
                 'admin_label'  => true,
                 'description'  => esc_html__('If do not like to show content then select No to hide content.', 'markety'),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Word Limit', 'markety'),
                'param_name'  => 'word_limit',
                'value'       => 15,
                'admin_label' => true,
                'dependency'  => array(
                    'element' => 'content_visibility',
                    'value'   => array( 'yes' )
                ),
                'description' => esc_html__( 'How many word would you like to show ?', 'markety')
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Member Order', 'markety' ),
                'param_name'  => 'member_order',
                'value'       => array(
                    esc_html__('Select an option', 'markety') => '',
                    esc_html__('ASC', 'markety') => 'ASC',
                    esc_html__('DESC', 'markety')  =>'DESC'
                    ),
                'admin_label' => true,
                'description' => esc_html__( 'You can change default order, Default is DESC', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Member designation visibility', 'markety' ),
                'param_name'  => 'designation_visibility',
                'value'       => array(
                    esc_html__('Select an option', 'markety') => '',
                    esc_html__('Visible', 'markety') => 'visible-designation',
                    esc_html__('Hidden', 'markety')  =>'hiddden-designation'
                    ),
                'admin_label' => true,
                'description' => esc_html__( 'If do not want to show member designation option then select hidden', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'admin_label' => true,
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_TT_Member extends WPBakeryShortCode {
        }
    }

endif;