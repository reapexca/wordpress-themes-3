<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Section title style element
    vc_map( array(
        'name'        => esc_html__( 'TT Simple call to action', 'markety' ),
        'base'        => 'tt_call_to_action',
        'icon'        => 'fa fa-align-center',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Simple call to action block', 'markety' ),
        'params'      => array(

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Title', 'markety' ),
                'param_name'  => 'title',
                'holder'      => 'h3',
                'description' => esc_html__( 'Enter title here', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Title font size', 'markety' ),
                'param_name'  => 'title_font_size',
                'description' => esc_html__( 'Enter title font size in px', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Title color option', 'markety' ),
                'param_name'  => 'title_color_option',
                'value'       => array(
                    esc_html__('Default Color', 'markety') => '',
                    esc_html__('Theme Color', 'markety')  =>'theme-color',
                    esc_html__('Custom Color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default title color then select theme color or select any custom color', 'markety' )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Custom color', 'markety' ),
                'param_name'  => 'title_color',
                'description' => esc_html__( 'Change title color', 'markety' ),
                'dependency'  => Array(
                    'element' => 'title_color_option',
                    'value'   => array( 'custom-color' )
                )
            ),

            array(
                'type'        => 'textarea_html',
                'heading'     => esc_html__( 'Sub title description', 'markety' ),
                'param_name'  => 'content',
                'holder'      => 'span',
                'description' => esc_html__( 'Description will appear on after title bottom separator', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Subtitle font size', 'markety' ),
                'param_name'  => 'subtitle_font_size',
                'description' => esc_html__( 'Enter subtitle font size in px', 'markety' )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Content alignment", 'markety'),
                "param_name" => "content_alignment",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety') => 'text-center',
                    esc_html__('Right', 'markety') => 'text-right'
                ),
                "description" => esc_html__("Select content alignment", 'markety')
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button visibility", 'markety'),
                "param_name" => "button_visibility",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Visible', 'markety') => 'visible',
                    esc_html__('Hidden', 'markety') => 'hidden'
                ),
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Select button visibility option", 'markety')
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__("Button text", 'markety'),
                "param_name" => "button_text",
                "description" => esc_html__("Enter button text", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "vc_link",
                "heading" => esc_html__("Button link", 'markety'),
                "param_name" => "button_link",
                "description" => esc_html__("Enter button link", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button style", 'markety'),
                "param_name" => "button_style",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Primary', 'markety') => 'btn-primary',
                    esc_html__('White', 'markety') => 'btn-default',
                    esc_html__('Outline', 'markety') => 'btn-outline',
                ),
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Select button position", 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button size", 'markety'),
                "param_name" => "button_size",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Small', 'markety') => 'btn-sm',
                    esc_html__('Normal', 'markety') => 'btn-md',
                    esc_html__('Large', 'markety') => 'btn-lg'
                ),
                "description" => esc_html__("Select button position", 'markety'),
                'group' => esc_html__('Button', 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__("Button top margin", 'markety'),
                "param_name" => "button_top_margin",
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Enter button to margin in px", 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__("Button bottom margin", 'markety'),
                "param_name" => "button_bottom_margin",
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Enter button bottom margin in px", 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__("Button position", 'markety'),
                "param_name" => "button_position",
                "value" => array(
                    esc_html__('-- Select --', 'markety') => '',
                    esc_html__('Botton', 'markety') => 'button-bottom',
                    esc_html__('Right', 'markety') => 'button-right'
                ),
                'group' => esc_html__('Button', 'markety'),
                "description" => esc_html__("Select button position", 'markety'),
                "dependency" => Array(
                    'element' => "button_visibility",
                    'value' => array('visible')
                )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_TT_Call_To_Action extends WPBakeryShortCode {

        }

    }
    endif;
















