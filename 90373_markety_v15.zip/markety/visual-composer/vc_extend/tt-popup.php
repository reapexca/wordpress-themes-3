<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Section title style element
    vc_map( array(
        'name'        => esc_html__( 'TT Popup', 'markety' ),
        'base'        => 'tt_popup',
        'icon'        => 'fa fa-expand',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Showing youtube video or vimeo video with popup', 'markety' ),
        'params'      => array(
            array(
                'type'        => 'attach_image',
                'heading'     => esc_html__( 'Cover Image', 'markety' ),
                'param_name'  => 'cover_image',
                'description' => esc_html__( 'Upload cover image from media library', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Enter URL', 'markety' ),
                'param_name'  => 'source_url',
                'admin_label' => true,
                'description' => esc_html__( 'Enter youtube, vimeo or map url', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Height', 'markety' ),
                'param_name'  => 'height',
                'admin_label' => true,
                'description' => esc_html__( 'Enter height in px, e.g: 400px', 'markety' )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Popup extends WPBakeryShortCode {
        }
    }
endif;
