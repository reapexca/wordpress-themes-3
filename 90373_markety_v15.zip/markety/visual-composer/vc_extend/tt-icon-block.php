<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    // Icon block elements
    vc_map( array(
        'name'                    => esc_html__( 'TT Icon Block', 'markety' ),
        'base'                    => 'tt_icon_blocks',
        'icon'                    => 'fa fa-picture-o',
        'description'             => esc_html__( 'Show off text with icon', 'markety' ),
        'as_parent'               => array( 'only' => 'tt_icon_block' ),
        'content_element'         => true,
        'show_settings_on_create' => true,
        'category'                => esc_html__( 'TT Elements', 'markety' ),
        'params'                  => array(
            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Select gid column', 'markety'),
                'param_name' => 'grid_column',
                'value' => array(
                    esc_html__('Select grid column', 'markety') => '',
                    esc_html__('2 Columns', 'markety') => '6',
                    esc_html__('3 Columns', 'markety') => '4',
                    esc_html__('4 Columns', 'markety') => '3'
                ),
                'std'         => '3',
                'admin_label' => true,
                'description' => esc_html__('Select grid column', 'markety'),
            ),

            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Block style', 'markety'),
                'param_name' => 'block-style',
                'value' => array(
                    esc_html__('Box style', 'markety') => 'box-style',
                    esc_html__('Box with border style', 'markety') => 'border-box-style'
                ),
                'admin_label' => true,
                'description' => esc_html__('Select block style', 'markety'),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Block height', 'markety' ),
                'param_name'  => 'block_height',
                'value'       => '310px',
                'description' => esc_html__( 'Enter block height in px, e.g: 310px', 'markety' )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        ),
        'js_view'                 => 'VcColumnView',
    ));

    // Icon block element
    vc_map( array(
        'name'        => esc_html__( 'Add icon and details', 'markety' ),
        'base'        => 'tt_icon_block',
        'icon'        => 'fa fa-align-center',
        'as_child'        => array( 'only' => 'tt_icon_blocks' ),
        'content_element' => true,
        'class'           => 'repeatable-content-wrap',

        'params'      => array(
            array(
                'type'        => 'dropdown',
                'class'       => '',
                'heading'     => esc_html__( 'Show icon ?', 'markety' ),
                'param_name'  => 'show_icon',
                'value' => array(
                    esc_html__('select option', 'markety') => '',
                    esc_html__('Yes', 'markety') => 'yes',
                    esc_html__('No', 'markety') => 'no'
                ),
                'admin_label' => true,
                'description' => esc_html__( 'If you do not like to show icon then select no', 'markety' ),
            ),

            array(
                'type'        => 'dropdown',
                'class'       => '',
                'heading'     => esc_html__( 'Icon Style', 'markety' ),
                'param_name'  => 'icon_style',
                'value' => array(
                    esc_html__('Default Style', 'markety') => 'icon-default',
                    esc_html__('Square Style', 'markety') => 'icon-square',
                    esc_html__('Round Style', 'markety') => 'icon-round',
                    esc_html__('Circle Style', 'markety') => 'icon-circle'
                ),
                'std'         => 'icon-default',
                'admin_label' => true,
                'description' => esc_html__( 'Select an icon style', 'markety' ),
                'dependency'  => array(
                    'element' => 'show_icon',
                    'value'   => array( 'yes' )
                )
            ),

            array(
                'type'        => 'dropdown',
                'class'       => '',
                'heading'     => esc_html__( 'Select icon type ?', 'markety' ),
                'param_name'  => 'icon_type',
                'value' => array(
                    esc_html__('select option', 'markety') => '',
                    esc_html__('Fontawesome', 'markety') => 'fontawesome-icon',
                    esc_html__('Flaticon', 'markety') => 'flat-icon'
                ),
                'admin_label' => true,
                'description' => esc_html__( 'There are two icon types fontawesome and flaticons, choose your type', 'markety' ),
                'dependency'  => array(
                    'element' => 'show_icon',
                    'value'   => array( 'yes' )
                )
            ),
            array(
                'type'       => 'iconpicker',
                'heading'    => esc_html__('Fontawesome', 'markety'),
                'param_name' => 'fontawesome_icon',
                'settings'   => array(
                    'type' => 'fontawesome'
                ),
                'description' => esc_html__( 'Fontawesome list. Pickup your choice.', 'markety'
                ),
                'dependency'  => array(
                    'element' => 'icon_type',
                    'value'   => array( 'fontawesome-icon' )
                ),
            ),
            array(
                'type'       => 'iconpicker',
                'heading'    => esc_html__('Flaticon', 'markety'),
                'param_name' => 'flat_icon',
                'settings'   => array(
                    'type' => 'flaticon'
                ),
                'description' => esc_html__( 'Flaticon list. Pickup your choice.', 'markety'
                ),
                'dependency'  => array(
                    'element' => 'icon_type',
                    'value'   => array( 'flat-icon' )
                ),
            ),
            array(
                'type'        => 'dropdown',
                'class'       => '',
                'heading'     => esc_html__( 'Icon position', 'markety' ),
                'param_name'  => 'icon_position',
                'value' => array(
                    esc_html__('Select alginment', 'markety') => '',
                    esc_html__('Left', 'markety') => 'icon-position-left',
                    esc_html__('Top center', 'markety') => 'icon-position-center',
                    esc_html__('Right', 'markety') => 'icon-position-right'
                ),
                'admin_label' => true,
                'description' => esc_html__( 'Change icon alignment using this option.', 'markety'),
                'dependency'  => array(
                    'element' => 'show_icon',
                    'value'   => array( 'yes' )
                )
            ),
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Icon color', 'markety' ),
                'param_name'  => 'icon_color_option',
                'value'       => array(
                    esc_html__('Default Color', 'markety') => '',
                    esc_html__('Theme Color', 'markety')  =>'theme-color',
                    esc_html__('Custom Color', 'markety')  =>'custom-color',
                ),
                'description' => esc_html__( 'If you change default icon color then select custom color', 'markety' ),
                'dependency'  => array(
                    'element' => 'show_icon',
                    'value'   => array( 'yes' )
                )
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'icon_color',
                'description' => esc_html__( 'change icon color', 'markety' ),
                'dependency'  => array(
                    'element' => 'icon_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),

            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Background color', 'markety'),
                'param_name' => 'bg_color_option',
                'value' => array(
                    esc_html__('Select icon background color', 'markety') => '',
                    esc_html__('Theme color', 'markety') => 'theme-bg',
                    esc_html__('Custom Color', 'markety')  =>'custom-color'
                ),
                'admin_label' => true,
                'dependency'  => array(
                    'element' => 'icon_style',
                    'value'   => array( 'icon-square', 'icon-round', 'icon-circle' )
                ),
                'description' => esc_html__('Select icon hover background color', 'markety'),
            ),

            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'icon_bg_color',
                'description' => esc_html__( 'change icon background color', 'markety' ),
                'dependency'  => array(
                    'element' => 'bg_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),

            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Icon hover background color', 'markety'),
                'param_name' => 'icon_hover_bg_color',
                'value' => array(
                    esc_html__('Select icon hover background color', 'markety') => '',
                    esc_html__('Theme color', 'markety') => 'icon-hover-default',
                    esc_html__('White color', 'markety') => 'icon-hover-white',
                    esc_html__('Black color', 'markety') => 'icon-hover-black'
                ),
                'admin_label' => true,
                'dependency'  => array(
                    'element' => 'icon_style',
                    'value'   => array( 'icon-square', 'icon-round', 'icon-circle' )
                ),
                'description' => esc_html__('Select icon hover background color', 'markety'),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Title', 'markety' ),
                'param_name'  => 'title',
                'holder' => 'h3',
                'description' => esc_html__( 'Enter title here', 'markety' )
            ),
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Title color', 'markety' ),
                'param_name'  => 'title_color_option',
                'value'       => array(
                    esc_html__('Default color', 'markety') => '',
                    esc_html__('Theme color', 'markety')  =>'theme-color',
                    esc_html__('Custom color', 'markety')  =>'custom-color',
                ),
                'admin_label' => true,
                'description' => esc_html__( 'If you change default title color then select custom color', 'markety' )
            ),
            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Select color', 'markety' ),
                'param_name'  => 'title_color',
                'description' => esc_html__( 'change title color', 'markety' ),
                'dependency'  => array(
                    'element' => 'title_color_option',
                    'value'   => array( 'custom-color' )
                ),
            ),
            array(
                'type'        => 'textarea_html',
                'heading'     => esc_html__( 'Text', 'markety' ),
                'param_name'  => 'content',
                'description' => esc_html__( 'Enter content here.', 'markety' )
            ),
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Set custom link ?', 'markety' ),
                'param_name'  => 'custom_link',
                'value'       => array(
                    esc_html__('No', 'markety') => 'no',
                    esc_html__('Yes', 'markety')  =>'yes',
                ),
                'admin_label' => true,
                'description' => esc_html__( 'If you want to set custom link then select yes, the link will appear on title', 'markety' )
            ),
            array(
                'type'        => 'vc_link',
                'heading'     => esc_html__( 'Link', 'markety' ),
                'param_name'  => 'link',
                'description' => esc_html__( 'Enter link or select page as link', 'markety' ),
                'dependency'  => array(
                    'element' => 'custom_link',
                    'value'   => array( 'yes' )
                ),
            ),
            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),
            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_tt_Icon_Blocks extends WPBakeryShortCodesContainer {
        }
    }

    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_tt_Icon_Block extends WPBakeryShortCode {
        }
    }
endif;
