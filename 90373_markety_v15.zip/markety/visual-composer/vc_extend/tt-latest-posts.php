<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

	// Latest blog element
	vc_map( array(
		'name'        => esc_html__( 'Latest Blog Post', 'markety'),
		'base'        => 'tt_latest_post',
		'icon'        => 'fa fa-qrcode',
		'category'    => esc_html__( 'Content', 'markety'),
		'description' => esc_html__( 'Latest blog post', 'markety'),
		'params'      => array(

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Post Limit', 'markety'),
				'param_name'  => 'post_limit',
				'value'       => 3,
				'admin_label' => true,
				'description' => esc_html__( 'Enter number of post to show', 'markety')
			),

			array(
		         'type' => 'dropdown',
		         'heading' => esc_html__('Select grid column', 'markety'),
		         'param_name' => 'grid_column',
		         'value' => array(
		              esc_html__('Select grid column', 'markety') => '',
		              esc_html__('2 Columns', 'markety') => '6',
		              esc_html__('3 Columns', 'markety') => '4',
		              esc_html__('4 Columns', 'markety') => '3',
		          ),
		         'admin_label' => true,
		         'description' => esc_html__('Select grid column', 'markety'),
		    ),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Word Limit', 'markety'),
				'param_name'  => 'word_limit',
				'value'       => 15,
				'admin_label' => true,
				'description' => esc_html__( 'How many word would you like to show ?', 'markety')
			),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Change readmore text', 'markety'),
				'param_name'  => 'readmore_text',
				'value'		  => 'Read More',
				'admin_label' => true,
				'description' => esc_html__( 'You can change readmore text', 'markety')
			),

			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Show all post button?', 'markety'),
				'param_name'  => 'show_all_button',
				'value'		 => array(
					esc_html__('Select an option', 'markety') => '',
					esc_html__('Yes', 'markety') => 'yes',
					esc_html__('No', 'markety') => 'no',
					),
				'admin_label' => true,
				'description' => esc_html__( 'You can show or hide all post button', 'markety')
			),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Change button text', 'markety'),
				'param_name'  => 'button_text',
				'value'		  => 'View More',
				'admin_label' => true,
				'description' => esc_html__( 'You can change button text', 'markety'),
				'dependency'  => Array(
					'element' => 'show_all_button',
					'value'   => array('yes')
				)
			),

			array(
				'type'        => 'vc_link',
				'heading'     => esc_html__( 'Link', 'markety'),
				'param_name'  => 'custom_link',
				'description' => esc_html__( 'Enter link or select a page as link', 'markety'),
				'dependency'  => Array(
					'element' => 'show_all_button',
					'value'   => array('yes')
				)
			),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Extra class name', 'markety'),
				'param_name'  => 'el_class',
				'admin_label' => true,
				'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety')
			),

		)
	));


	if ( class_exists( 'WPBakeryShortCode' ) ) {
		class WPBakeryShortCode_tt_Latest_Post extends WPBakeryShortCode {
		}
	}
endif;