<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if( function_exists('vc_map') ) :

	// Fade Animation for title and subtitle
	$tt_css_animation = array(
		esc_html__('Select animation', 'markety') 	=> '',
		esc_html__('fadeIn', 'markety') 			=> 'fadeIn',
		esc_html__('fadeInDown', 'markety') 		=> 'fadeInDown',
		esc_html__('fadeInDownBig', 'markety') 		=> 'fadeInDownBig',
		esc_html__('fadeInLeft', 'markety') 		=> 'fadeInLeft',
		esc_html__('fadeInLeftBig', 'markety') 		=> 'fadeInLeftBig',
		esc_html__('fadeInRight', 'markety') 		=> 'fadeInRight',
		esc_html__('fadeInRightBig', 'markety') 	=> 'fadeInRightBig',
		esc_html__('fadeInUp', 'markety') 			=> 'fadeInUp',
		esc_html__('fadeInUpBig', 'markety') 		=> 'fadeInUpBig'
	);

	// animation delay
	$tt_animation_delay = array(
		esc_html__('Select delay option', 'markety') 	=> '',
		esc_html__('Delay 300ms', 'markety') 			=> 'delay-1',
		esc_html__('Delay 600ms', 'markety') 			=> 'delay-2',
		esc_html__('Delay 1200ms', 'markety') 			=> 'delay-3',
		esc_html__('Delay 1500ms', 'markety') 			=> 'delay-4',
		esc_html__('Delay 1800ms', 'markety') 			=> 'delay-5'
	);

	// TT home slider element
	vc_map( array(
		'name'                    => esc_html__( 'Home Slider', 'markety' ),
		'base'                    => 'tt_home_slides',
		'icon'                    => 'fa fa-picture-o',
		'description'             => esc_html__( 'Slider for home page, but you can use it any where in the page', 'markety' ),
		'as_parent'               => array( 'only' => 'tt_home_slide' ),
		'content_element' 		  => true,
    	'show_settings_on_create' => false,
		'category'                => esc_html__( 'TT Elements', 'markety' ),
		// 'default_content'         => '[home_slide /]',
		'params'                  => array(
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Extra class name', 'markety' ),
				'param_name'  => 'el_class',
				'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
			)
		),
		'js_view'                 => 'VcColumnView',
	));


	vc_map( array(
		'name'            => esc_html__( 'Slide', 'markety' ),
		'base'            => 'tt_home_slide',
		'as_child'        => array( 'only' => 'tt_home_slides' ),
		'content_element' => true,
		'icon'            => 'fa fa-picture-o',
		'class'			  => 'repeatable-content-wrap',
		'params'          => array(
			array(
				'type'        => 'attach_image',
				'heading'     => esc_html__( 'Image', 'markety' ),
				'param_name'  => 'slider_image',
				'description' => esc_html__( 'Select images from media library, dimension: min 1700x900', 'markety' )
			),

			array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Content alignment', 'markety' ),
                'param_name'  => 'content_alignment',
                'value'       => array(
                    esc_html__('Select content alignment', 'markety') => '',
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Center', 'markety')  =>'text-center',
                    esc_html__('Right', 'markety')  =>'text-right' 
                ),
                'std'		  => 'text-left',
                'description' => esc_html__( 'Select content alignment', 'markety' )
            ),


			// intro title
			array(
				'type'        	=> 'textfield',
				'heading'     	=> esc_html__( 'Intro title', 'markety' ),
				'param_name'  	=> 'intro-title',
				'admin_label'	=> true,
				'description' 	=> esc_html__( 'Enter intro title', 'markety' ),
				'group' 		=> esc_html__( 'Intro Title', 'markety' )
			),
			
			array(
				'type'        	=> 'textfield',
				'heading'     	=> esc_html__( 'Font size', 'markety' ),
				'param_name'  	=> 'intro-font-size',
				'admin_label'	=> true,
				'description' 	=> esc_html__( 'Enter intro font size in px, e.g: 75px', 'markety' ),
				'group' 		=> esc_html__( 'Intro Title', 'markety' )
			),
			
			array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Intro title animation', 'markety' ),
				'param_name'  	=> 'intro_title_animation',
				'admin_label'	=> true,
				'value'			=> $tt_css_animation,
				'description' 	=> esc_html__( 'Select animation for intro title, e.g: fadeInDown', 'markety' ),
				'group' 		=> esc_html__( 'Intro Title', 'markety' )
			),

			array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Animation delay', 'markety' ),
				'param_name'  	=> 'intro_title_ani_delay',
				'admin_label'	=> true,
				'value'			=> $tt_animation_delay,
				'description' 	=> esc_html__( 'Select animation delay for intro title, e.g: Delay 300ms', 'markety' ),
				'group' 		=> esc_html__( 'Intro Title', 'markety' )
			),

			// intro subtitle
			array(
				'type'        	=> 'textfield',
				'heading'     	=> esc_html__( 'Intro subtitle', 'markety' ),
				'param_name'  	=> 'intro-subtitle',
				'admin_label'	=> true,
				'description' 	=> esc_html__( 'Enter intro subtitle', 'markety' ),
				'group' 		=> esc_html__( 'Intro Subtitle', 'markety' )
			),
			
			array(
				'type'        	=> 'textfield',
				'heading'     	=> esc_html__( 'Font size', 'markety' ),
				'param_name'  	=> 'intro-subtitle-font-size',
				'admin_label'	=> true,
				'description' 	=> esc_html__( 'Enter intro subtitle font size in px, e.g: 25px', 'markety' ),
				'group' 		=> esc_html__( 'Intro Subtitle', 'markety' )
			),
			
			array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Intro subtitle animation', 'markety' ),
				'param_name'  	=> 'intro_subtitle_animation',
				'admin_label'	=> true,
				'value'			=> $tt_css_animation,
				'description' 	=> esc_html__( 'Select animation for intro subtitle, e.g: fadeInDown', 'markety' ),
				'group' 		=> esc_html__( 'Intro Subtitle', 'markety' )
			),

			array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Animation delay', 'markety' ),
				'param_name'  	=> 'intro_subtitle_ani_delay',
				'admin_label'	=> true,
				'value'			=> $tt_animation_delay,
				'description' 	=> esc_html__( 'Select animation delay for intro subtitle, e.g: Delay 300ms', 'markety' ),
				'group' 		=> esc_html__( 'Intro Subtitle', 'markety' )
			),

			// button
			array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Show learn more button ?', 'markety' ),
                'param_name'  => 'show_button',
                'value'       => array(
                    esc_html__('Select an option', 'markety') => '',
                    esc_html__('Yes', 'markety') => 'yes',
                    esc_html__('No', 'markety') => 'no'
                    
                ),
                'admin_label' => true,
                'description' => esc_html__( 'If you want to show button then select yes', 'markety'),
                'group' 		=> esc_html__( 'Learn More', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Button text', 'markety' ),
                'param_name'  => 'button_text',
                'value'       => esc_html__('Learn More', 'markety' ),
                'description' => esc_html__( 'Change button text', 'markety' ),
                'dependency' => array(
                    'element' => 'show_button', 
                    'value' => array('yes')
                ),
                'group' 		=> esc_html__( 'Learn More', 'markety' )
            ),

            array(
                'type'        => 'vc_link',
                'heading'     => esc_html__( 'Button link', 'markety' ),
                'param_name'  => 'custom_link',
                'description' => esc_html__( 'Enter custom link or select existing page as link', 'markety' ),
                'dependency' => array(
                    'element' => 'show_button',
                    'value' => array('yes')
                ),
                'group' 		=> esc_html__( 'Learn More', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Button class', 'markety' ),
                'param_name'  => 'button_class',
                'admin_label' => true,
                'description' => esc_html__( 'Use button class field to style particularly', 'markety' ),
                'dependency' => array(
                    'element' => 'show_button', 
                    'value' => array('yes')
                ),
                'group' 		=> esc_html__( 'Learn More', 'markety' )
            ),

            array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Button animation', 'markety' ),
				'param_name'  	=> 'button_animation',
				'admin_label'	=> true,
				'value'			=> $tt_css_animation,
				'description' 	=> esc_html__( 'Select animation for button, e.g: fadeInDown', 'markety' ),
				'group' 		=> esc_html__( 'Learn More', 'markety' )
			),

			array(
				'type'        	=> 'dropdown',
				'heading'     	=> esc_html__( 'Animation delay', 'markety' ),
				'param_name'  	=> 'button_ani_delay',
				'admin_label'	=> true,
				'value'			=> $tt_animation_delay,
				'description' 	=> esc_html__( 'Select animation delay for button, e.g: Delay 300ms', 'markety' ),
				'group' 		=> esc_html__( 'Learn More', 'markety' )
			),

            // design option
			array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Extra class name', 'markety' ),
				'param_name'  => 'el_class',
				'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
			)
		)
	));

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_tt_Home_Slides extends WPBakeryShortCodesContainer {
		}
	}

	if ( class_exists( 'WPBakeryShortCode' ) ) {
		class WPBakeryShortCode_tt_Home_Slide extends WPBakeryShortCode {
		}
	}
endif;