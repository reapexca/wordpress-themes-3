<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

	vc_map( array(
        'name'        => esc_html__( 'TT Gallery', 'markety' ),
        'base'        => 'tt_gallery',
        'icon'        => 'fa fa-picture-o',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Displays gallery with image or video', 'markety' ),
        'params'      => array(

        	array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Gallery type', 'markety' ),
                'param_name'  => 'gallery_type',
                'value'       => array(
                    esc_html__('Select gallery type', 'markety') => '',
                    esc_html__('Image Gallery', 'markety') => 'image-gallery',
                    esc_html__('Video Gallery', 'markety')  =>'video-gallery'
                ),
                'admin_label' => true,
                'description' => esc_html__( 'Select gallery type', 'markety' )
            ),

            array(
				'type' => 'attach_images',
				'heading' => esc_html__( 'Images', 'markety'),
				'param_name' => 'images',
				'description' => esc_html__( 'Select images from media library.', 'markety' ),
				'dependency'  => Array(
	                'element' => 'gallery_type',
	                'value'   => array( 'image-gallery' )
	            )
			),

			array(
                'type' => 'param_group',
                'heading' => esc_html__('Video content', 'markety'),
                'param_name' => 'video_content',
                'description' => esc_html__('Enter video content', 'markety'),
                'dependency'  => Array(
	                'element' => 'gallery_type',
	                'value'   => array( 'video-gallery' )
	            ),
                'params' => array(
                    array(
						'type' => 'attach_image',
						'heading' => esc_html__( 'Video Cover', 'markety'),
						'param_name' => 'video_cover',
						'description' => esc_html__( 'Select images from media library.', 'markety' )
					),

					array(
		                "type"        => "textarea_safe",
		                "heading"     => esc_html__( "Embed iframe", 'markety' ),
		                "param_name"  => "embed_iframe",
		                "description" => esc_html__( "Give your emded iframe code here, recommended size is: 1140x640.", 'markety' )
		            ),
                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

	if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Gallery extends WPBakeryShortCode {
        }
    }

endif; // function_exists( 'vc_map' )