<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

if (function_exists('vc_map')) :

    $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

    $contact_forms = array();
    if ( $cf7 ) {
        foreach ( $cf7 as $cform ) {
            $contact_forms[ $cform->post_title ] = $cform->ID;
        }
    } else {
        $contact_forms[ esc_html__( 'No contact forms found', 'markety' ) ] = 0;
    }

	vc_map( array(
        'name'        => esc_html__( 'TT Pricing Table', 'markety' ),
        'base'        => 'tt_pricing',
        'icon'        => 'fa fa-picture-o',
        'category'    => esc_html__( 'TT Elements', 'markety' ),
        'description' => esc_html__( 'Displays service package with price', 'markety' ),
        'params'      => array(
        	
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Table style type', 'markety' ),
                'param_name'  => 'table_style',
                'value'       => array(
                    esc_html__('Style one (standard)', 'markety') => 'standard-table',
                    esc_html__('Style two (modern)', 'markety')  => 'modern-table',
                    esc_html__('Style three (creative)', 'markety')  => 'creative-table'
                ),
                'admin_label' => true,
                'description' => esc_html__( 'Select table style', 'markety' )
            ),

            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Alignment', 'markety' ),
                'param_name'  => 'table_alignment',
                'value'       => array(
                    esc_html__('Left', 'markety') => 'text-left',
                    esc_html__('Right', 'markety')  => 'text-right',
                    esc_html__('Center', 'markety')  => 'text-center'
                ),
                'std'         => 'text-center',
                'admin_label' => true,
                'description' => esc_html__( 'Select table content align', 'markety' )
            ),

            array(
                 'type' => 'dropdown',
                 'heading' => esc_html__('Select grid column', 'markety'),
                 'param_name' => 'grid_column',
                 'value' => array(
                      esc_html__('Select grid column', 'markety') => '',
                      esc_html__('2 Columns', 'markety') => '6',
                      esc_html__('3 Columns', 'markety') => '4',
                      esc_html__('4 Columns', 'markety') => '3',
                  ),
                 'admin_label' => true,
                 'description' => esc_html__('Select grid column', 'markety'),
            ),

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Table content', 'markety'),
                'param_name' => 'table_content',
                'description' => esc_html__('Enter table content', 'markety'),
                'group'       => 'Table info',
                'params' => array(
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Package name', 'markety' ),
                        'param_name'  => 'package_name',
                        'admin_label' => true,
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter package name', 'markety' )
                    ),

                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Currency symbol', 'markety' ),
                        'param_name'  => 'currency_symbol',
                        'value'       => '$',
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter Package Rate Currency symbol, e.g: $ (enter only currency symbol)', 'markety' )
                    ),

                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Currency Code', 'markety' ),
                        'param_name'  => 'currency_code',
                        'value'       => 'USD',
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter Package Rate Currency Code', 'markety' )
                    ),

                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Package Rate', 'markety' ),
                        'param_name'  => 'package_rate',
                        'admin_label' => true,
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter Package Rate, e.g: 99 (enter only number)', 'markety' )
                    ),

                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Package duration', 'markety' ),
                        'param_name'  => 'package_duration',
                        'value'       => 'Month',
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter Package Duration, e.g: monthly', 'markety' )
                    ),

                    array(
                        'type'        => 'textarea_safe',
                        'heading'     => esc_html__( 'Pricing Plan Details', 'markety' ),
                        'param_name'  => 'details',
                        'group'       => 'Table info',
                        'description' => esc_html__( 'Enter Yor Pricing Plan Details', 'markety' )
                    ),

                    array(
                        'type'        => 'dropdown',
                        'heading'     => esc_html__( 'Show purchase button ?', 'markety' ),
                        'param_name'  => 'purchase_button_show',
                        'value'       => array(
                            esc_html__( 'Yes', 'markety' )              => 'yes',
                            esc_html__( 'No', 'markety' )               => 'no'
                        ),
                        'group'       => 'Table info',
                        'description' => esc_html__( 'If you do not like to show purchase button then select no to hide', 'markety' )
                    ),

                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Button Text', 'markety' ),
                        'param_name'  => 'purchase_button_text',
                        'value'       => 'Purchase',
                        'description' => esc_html__( 'Change Button Text', 'markety' ),
                        'group'       => 'Table info',
                        'dependency'  => array(
                            'element' => 'purchase_button_show',
                            'value'   => array( 'yes' )
                        )
                    ),

                    array(
                        'type'        => 'vc_link',
                        'heading'     => esc_html__( 'Button Link', 'markety' ),
                        'param_name'  => 'purchase_button_link',
                        'description' => esc_html__( 'Enter Button Link', 'markety' ),
                        'group'       => 'Table info',
                        'dependency'  => array(
                            'element' => 'purchase_button_show',
                            'value'   => array( 'yes' )
                        )
                    ),

                    array(
                        'type'        => 'attach_images',
                        'heading'     => esc_html__( 'Background Images', 'markety' ),
                        'param_name'  => 'table_bg',
                        'description' => esc_html__( 'Upload table background image', 'markety' ),
                        'group'       => 'Table info',
                        'dependency'  => array(
                            'element' => 'table_style',
                            'value'   => array( 'creative-table' )
                        )
                    ),

                    array(
                        'type'        => 'dropdown',
                        'heading'     => esc_html__( 'Table preset', 'markety' ),
                        'param_name'  => 'table_preset',
                        'value'       => array(
                            esc_html__('Preset one', 'markety') => 'table-preset-one',
                            esc_html__('Preset two', 'markety') => 'table-preset-two',
                            esc_html__('Preset three', 'markety') => 'table-preset-three',
                            esc_html__('Preset four', 'markety') => 'table-preset-four',
                            esc_html__('Preset five', 'markety') => 'table-preset-five'
                        ),
                        'class'       => 'table-preset',
                        'admin_label' => true,
                        'dependency'  => array(
                            'element' => 'table_style',
                            'value'   => array( 'standard-table', 'modern-table' )
                        ),
                        'description' => esc_html__( 'Select table preset', 'markety' )
                    )
                ),
            ),


            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Use custom price form?', 'markety' ),
                'param_name'  => 'custom_price_form',
                'value'       => array(
                    esc_html__( 'Yes', 'markety' ) => 'yes',
                    esc_html__( 'No', 'markety' )  => 'no'
                ),
                'std'         => 'no',
                'group'       => 'Custom Form',
                'description' => esc_html__( 'If you want to use custom price form then select yes', 'markety' )
            ),

            array(
                'type' => 'dropdown',
                'heading' => esc_html__( 'Select contact form', 'markety' ),
                'param_name' => 'id',
                'value' => $contact_forms,
                'save_always' => true,
                'group'       => 'Custom Form',
                'dependency'  => array(
                    'element' => 'custom_price_form',
                    'value'   => array( 'yes' )
                ),
                'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Tab one text', 'markety' ),
                'param_name'  => 'tab_one_text',
                'dependency'  => array(
                    'element' => 'custom_price_form',
                    'value'   => array( 'yes' )
                ),
                'value'        => esc_html__( 'Regular', 'markety' ),
                'group'       => 'Custom Form',
                'description' => esc_html__( 'Change tab one text', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Tab two text', 'markety' ),
                'param_name'  => 'tab_two_text',
                'dependency'  => array(
                    'element' => 'custom_price_form',
                    'value'   => array( 'yes' )
                ),
                'value'        => esc_html__( 'Custom', 'markety' ),
                'group'       => 'Custom Form',
                'description' => esc_html__( 'Change tab two text', 'markety' )
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Tab divider text', 'markety' ),
                'param_name'  => 'tab_divider_text',
                'dependency'  => array(
                    'element' => 'custom_price_form',
                    'value'   => array( 'yes' )
                ),
                'value'        => esc_html__( 'Or', 'markety' ),
                'group'       => 'Custom Form',
                'description' => esc_html__( 'Change tab divider text', 'markety' )
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__( 'Css', 'markety' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'markety' ),
            ),

            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Extra class name', 'markety' ),
                'param_name'  => 'el_class',
                'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'markety' )
            )
        )
    ));

	if (class_exists('WPBakeryShortCode')) {
        class WPBakeryShortCode_tt_Pricing extends WPBakeryShortCode {
        }
    }

endif; // function_exists( 'vc_map' )