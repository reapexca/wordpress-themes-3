<?php 
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    $tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );

    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $tt_atts['css'], ' ' ), $this->settings['base'], $atts );

    ob_start(); 

    // table content

    $table_contents = (array) vc_param_group_parse_atts( $tt_atts['table_content'] );
    $tables = array();

    foreach ( $table_contents as $data ) :
        $table_data = $data;
        $table_data['package_name'] = isset( $data['package_name'] ) ? $data['package_name'] : '';
        $table_data['currency_symbol'] = isset( $data['currency_symbol'] ) ? $data['currency_symbol'] : '';
        $table_data['currency_code'] = isset( $data['currency_code'] ) ? $data['currency_code'] : '';
        $table_data['package_rate'] = isset( $data['package_rate'] ) ? $data['package_rate'] : '';
        $table_data['package_duration'] = isset( $data['package_duration'] ) ? $data['package_duration'] : '';
        $table_data['details'] = isset( $data['details'] ) ? $data['details'] : '';
        $table_data['purchase_button_show'] = isset( $data['purchase_button_show'] ) ? $data['purchase_button_show'] : '';
        $table_data['purchase_button_text'] = isset( $data['purchase_button_text'] ) ? $data['purchase_button_text'] : '';
        $table_data['purchase_button_link'] = isset( $data['purchase_button_link'] ) ? $data['purchase_button_link'] : '';
        $table_data['currency_symbol'] = isset( $data['currency_symbol'] ) ? $data['currency_symbol'] : '';
        $table_data['table_bg'] = isset( $data['table_bg'] ) ? $data['table_bg'] : '';
        $table_data['table_preset'] = isset( $data['table_preset'] ) ? $data['table_preset'] : '';

        $tables[] = $table_data;
    endforeach;
?>

    <div class="row pricing-wrapper <?php echo esc_attr($tt_atts['table_style'] .' '. $tt_atts[ 'el_class' ].' '.$tt_atts['table_alignment']);?>">
        <?php if ($tt_atts['custom_price_form'] == 'yes'): ?>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#regular-price" aria-controls="regular-price" role="tab" data-toggle="tab"><?php echo esc_html($tt_atts['tab_one_text']); ?></a></li>
                
                <?php if ($tt_atts['tab_divider_text']): ?>
                    <span class="divider"><?php echo esc_html($tt_atts['tab_divider_text']);?></span>
                <?php endif; ?>
                
                <li role="presentation"><a href="#custom-price" aria-controls="custom-price" role="tab" data-toggle="tab"><?php echo esc_html($tt_atts['tab_two_text']); ?></a></li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active fade in" id="regular-price">
        <?php endif; ?>

            <?php foreach ($tables as $table): 

                // vc_link
                $link     = vc_build_link($table['purchase_button_link']);
                $a_href   = $link['url'];
                $a_title  = $link['title'];
                $a_target = trim($link['target']);

                $target = "";
                $title = "";

                if ($a_target) {
                    $target = 'target='.$a_target.'';
                }

                if ($a_title) {
                    $title = 'title='.$a_title.'';
                }

                ?>

                <div class="col-sm-6 col-md-<?php echo esc_attr($tt_atts['grid_column']);?>">
                    <div class="pricing-table <?php echo esc_attr($table['table_preset']);?>">
                        <?php if ($table['table_bg']): ?>
                            <?php 
                                $images = explode( ',', $table['table_bg'] ); 
                                foreach ( $images as $key=>$attach_id ) :
                                    $tt_img_src = wp_get_attachment_image_src($attach_id, 'full'); ?>
                                    <div class="mask mask-<?php echo intval($key);?>">
                                        <img class="img-responsive" src="<?php echo esc_url($tt_img_src[0]); ?>" alt>
                                    </div>
                            <?php endforeach; ?>
                        <?php endif ?>
                        
                        <div class="table-contents">
                            <div class="table-header">
                                <?php if ($table['package_name']): ?>
                                    <div class="package-name">
                                        <span><?php echo esc_html($table['package_name']);?></span>
                                    </div> 
                                <?php endif ?>
                                
                                <?php if ($table['package_rate']): ?>
                                    <div class="package-price">
                                        <?php if ($table['currency_symbol']): ?>
                                            <span class="currency-symbol"><?php echo esc_html($table['currency_symbol']);?></span>
                                        <?php endif ?>

                                        <?php if ($table['package_rate']): ?>
                                            <span class="price"><?php echo esc_html($table['package_rate']);?></span>
                                        <?php endif ?>

                                        <?php if ($table['currency_code'] || $table['package_duration']): ?>
                                            <span class="currency-code">
                                                <?php echo esc_html($table['currency_code']);
                                                if ($table['package_duration']):?>
                                                    /<?php echo esc_html($table['package_duration']);?>
                                                <?php endif ?>
                                            </span>
                                        <?php endif ?>
                                    </div>
                                <?php endif ?>
                                
                            </div> <!-- .table-header -->

                            <?php if ($table['details']): ?>
                                <div class="table-info">
                                    <?php echo $table['details']; ?>
                                </div>
                            <?php endif ?>
                            
                            <div class="table-footer">
                                <?php if ($table['purchase_button_show'] == 'yes') { ?>
                                    <div class="purchase-button">
                                        <a class="btn btn-primary" href="<?php echo esc_url($a_href); ?>" <?php echo esc_attr($title);?> <?php echo esc_attr($target);?>><?php echo esc_html($table['purchase_button_text']);?></a>
                                    </div>   
                                <?php } ?>
                            </div> <!-- .table-footer -->
                        </div> <!-- .table-contents -->
                    </div> <!-- .pricing-wrapper -->
                </div>
            <?php endforeach; ?>
             
        <?php if ($tt_atts['custom_price_form'] == 'yes'): ?>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="custom-price">
                    <?php echo do_shortcode('[contact-form-7 id="'.intval($tt_atts['id']).'" title="Contact form 1"]');?>
                </div>
            </div> <!-- .tab-content -->
        <?php endif; ?>
    </div> <!-- .pricing-wrapper -->
<?php echo ob_get_clean();