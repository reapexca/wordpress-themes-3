<?php
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    $tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );

	ob_start();

	// icon
    $icon_type = "";
    $icon = "";

    if ($tt_atts['icon_type'] == 'fontawesome-icon') :
        $icon_type = "fontawesome-icon";
        $icon = $tt_atts['fontawesome_icon'];
    elseif ($tt_atts['icon_type'] == 'flat-icon') :
        $icon_type = "flat-icon";
        $icon = $tt_atts['flat_icon'];
    endif;


    // colors
    $icon_color = "";
    $number_color = "";
    $title_color = "";

    if ($tt_atts['icon_color_option'] == 'custom-color') :
        $icon_color = 'color:'.$tt_atts['icon_color'].'';
    endif;

    if ($tt_atts['counted_number_color_option'] == 'custom-color') :
        $number_color = 'color:'.$tt_atts['counted_number_color'].'';
    endif;

    if ($tt_atts['title_color_option'] == 'custom-color') :
        $title_color = 'color:'.$tt_atts['title_color'].'';
    endif;

	?>
	
	<div class="counter-wrap <?php echo esc_attr($tt_atts['grid_class'] .' '. $tt_atts['el_class']); ?>">
		
		<?php if ($tt_atts['show_icon'] == 'yes') : ?>
            <div class="tt-icon <?php echo esc_attr($icon_type);?>">
                <span class="icon"><i class="<?php echo esc_attr($icon.' '.$tt_atts['icon_color_option']) ;?> " style="<?php echo esc_attr($icon_color)?>"></i></span>
            </div>
        <?php endif; ?>

		<span class="timer" style="<?php echo esc_attr($number_color); ?>"><?php echo intval($tt_atts['counted_number']); ?></span>
		
		<?php if ($tt_atts['subtitle']) : ?>
			<span class="count-title" style="<?php echo esc_attr($title_color); ?>"><?php echo esc_html($tt_atts['subtitle']); ?></span>
		<?php endif; ?>

	</div>

	<?php
	echo ob_get_clean();