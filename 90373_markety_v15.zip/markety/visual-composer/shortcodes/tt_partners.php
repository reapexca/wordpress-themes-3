<?php 
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    $tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );
    $tt_custom_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $tt_atts['css'], ' ' ), $this->settings['base'], $atts ); 

    ob_start();

    // image effect
    $image_effect = $tt_atts['image_effect'];
    $image_effect_class = "";
    if ($image_effect == 'black_white') :
        $image_effect_class = "tt-bh-effect";
    endif;

    $item_bg = $item_border_color = "";
    if($tt_atts['item_bg']):
       $item_bg = 'background-color:'.$tt_atts['item_bg'].';';
    endif;
    if ($tt_atts['item_border_color']) :
        $item_border_color = 'border-color:'.$tt_atts['item_border_color'].';';
    endif;
    
    ?>

    <div class="partner-carousel-wrapper">
        <div class="partner-carousel <?php echo esc_attr($tt_atts['el_class'].' '. $tt_custom_css .' '. $tt_atts['nav_position'].' '.$tt_atts['item_top_border']);?>" data-largescreen="<?php echo intval($tt_atts['large_screen']); ?>" data-desktop="<?php echo intval($tt_atts['items_desktop']); ?>" data-tablet="<?php echo intval($tt_atts['items_tablet']); ?>" data-mobilelarge="<?php echo intval($tt_atts['items_mobile_landscape']); ?>" data-mobile="<?php echo intval($tt_atts['items_mobile']); ?>" data-sliderow="<?php echo intval($tt_atts['carousel_row']); ?>" data-gutter="<?php echo intval($tt_atts['item_gutter']); ?>" >
            <div class="swiper-wrapper">
                <?php $tt_custom_links = '';
                
                if($tt_atts['on_click_action'] == 'custom_link') :
                    $tt_custom_links = explode(',',$tt_atts['links']);
                endif;

                $images = explode( ',', $tt_atts['images'] );
                $i = -1; 
                
                foreach ( $images as $attach_id ) :
                    $i++;

                    $tt_img_src = wp_get_attachment_image_src($attach_id, 'tt-client-logo'); ?>
                    
                    <div class="swiper-slide partner-item <?php echo esc_attr($image_effect_class.' '.$tt_atts['item_border']); ?>" style="height: <?php echo esc_attr($tt_atts['item_height'].'; '.$item_bg.' '.$item_border_color); ?>">
                        <?php if($tt_atts['on_click_action'] == 'custom_link' and isset($tt_custom_links[$i])) : ?>
                            <a href="<?php echo esc_url($tt_custom_links[$i]);?>"><img src="<?php echo esc_url($tt_img_src[0]); ?>" alt></a>
                        <?php else : ?>
                            <img class="img-responsive" src="<?php echo esc_url($tt_img_src[0]); ?>" alt>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ($tt_atts['navigation_visibility'] == 'show') : ?>
                <div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
                <div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>
            <?php endif; ?>
        </div> <!-- .partner-carousel -->
    </div> <!-- .partner-carousel-wrapper -->
<?php echo ob_get_clean();