<?php
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    $tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );

    ob_start();
?>


    <?php 
    // color options
    $client_name_color = "";
    $client_org_color = "";
    $client_quote_text_color = "";

    if ($tt_atts['client_text_color']) :
        $client_name_color = 'color: ' .$tt_atts['client_text_color']. ';';
    endif;

    if ($tt_atts['client_org_text_color']) :
        $client_org_color = 'color: ' .$tt_atts['client_org_text_color']. ';';
    endif;

    if ($tt_atts['client_quote_text_color']) :
        $client_quote_text_color = 'color: ' .$tt_atts['client_quote_text_color']. ';';
    endif;


    $testimonial_info = (array)vc_param_group_parse_atts($tt_atts['testimonial_info']);
    $testimonial_info_data = array();
    foreach ($testimonial_info as $data) :
        $tt_testimonial_info = $data;

        $tt_testimonial_info['photo_option'] = isset($data['photo_option']) ? $data['photo_option'] : '';
        $tt_testimonial_info['client_image'] = isset($data['client_image']) ? $data['client_image'] : '';
        $tt_testimonial_info['quote_video'] = isset($data['quote_video']) ? $data['quote_video'] : '';
        $tt_testimonial_info['video_url'] = isset($data['video_url']) ? $data['video_url'] : '';
        $tt_testimonial_info['icon_color'] = isset($data['icon_color']) ? $data['icon_color'] : '#000000';
        $tt_testimonial_info['client_name'] = isset($data['client_name']) ? $data['client_name'] : '';
        $tt_testimonial_info['client_org'] = isset($data['client_org']) ? $data['client_org'] : '';
        $tt_testimonial_info['content'] = isset($data['content']) ? $data['content'] : '';

        $testimonial_info_data[] = $tt_testimonial_info;
    endforeach; ?>


    <div class="testimonial-carousel-wrapper">
        <div class="testimonial-carousel <?php echo esc_attr($tt_atts['carousel_style']); ?>" data-largescreen="<?php echo intval($tt_atts['large_screen']); ?>" data-desktop="<?php echo intval($tt_atts['items_desktop']); ?>" data-tablet="<?php echo intval($tt_atts['items_tablet']); ?>" data-mobilelarge="<?php echo intval($tt_atts['items_mobile_landscape']); ?>" data-mobile="<?php echo intval($tt_atts['items_mobile']); ?>" data-sliderow="<?php echo intval($tt_atts['carousel_row']); ?>" data-gutter="<?php echo intval($tt_atts['item_gutter']); ?>" >

            <div class="swiper-wrapper <?php echo esc_attr($tt_atts['content_align']); ?>">

                <?php foreach ($testimonial_info_data as $key => $carousel_content): ?>
                    <div class="swiper-slide blockquote">
                        
                        <?php if ($carousel_content['quote_video'] == 'yes') : ?>
                            <div class="video-quote">
                                <a class="tt-popup" href="<?php echo esc_url($carousel_content['video_url']);?>"><i class="fa fa-play" style="color: <?php echo esc_attr($carousel_content['icon_color']);?>; border-color: <?php echo esc_attr($carousel_content['icon_color']);?>"></i></a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="quote-content" style="<?php echo esc_attr($client_quote_text_color); ?>">
                            <p><?php echo esc_html($carousel_content['content']); ?></p>
                        </div>
                        <footer class="clearfix">
                            <div class="client-info">
                                <?php $img_src = wp_get_attachment_image_src($carousel_content['client_image']); 
                                    if ($img_src) : ?>
                                        <div class="client-photo">
                                            <img class="img-responsive " src="<?php echo esc_url($img_src[0]); ?>" alt="<?php echo esc_attr($carousel_content['client_name']); ?>">
                                        </div>
                                    <?php endif; 
                                ?>
                                
                                <?php 
                                $client_name = $carousel_content['client_name'];
                                $client_designation = $carousel_content['client_org'];

                                if ($client_name) : ?>
                                    <span class="client-name" style="<?php echo esc_attr($client_name_color); ?>"><?php echo esc_html($client_name); ?></span>
                                <?php endif; 
                                
                                if ($client_designation) : ?>
                                    <span class="client-title" style="<?php echo esc_attr($client_org_color); ?>"><?php echo esc_html($client_designation); ?></span>
                                <?php endif; ?>
                            </div>
                        </footer>
                    </div>
                <?php endforeach; ?>
            </div> <!-- .swiper-wrapper -->

            <?php if ($tt_atts['pagination_visibility'] == 'show') : ?>
                <div class="swiper-pagination"></div>
            <?php endif; ?>
            
            <?php if ($tt_atts['navigation_visibility'] == 'show') : ?>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            <?php endif; ?>

        </div> <!-- .testimonial-carousel -->
    </div> <!-- .testimonial-carousel-wrapper -->

    <?php 
    echo ob_get_clean();