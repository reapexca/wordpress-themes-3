<?php 
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;
    
    $tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );

    ob_start(); 

    $tt_link     = vc_build_link($tt_atts['custom_link']);
    $tt_a_href   = $tt_link['url'];
    $tt_a_title  = $tt_link['title'];

?>
    
    <div class="tt-text-rotator <?php echo esc_attr($tt_atts['el_class']); ?>">
        <div class="intro <?php echo esc_attr($tt_atts['title_alignment']); ?>">

            <?php if ($tt_atts['title']) : ?>
                <h2><span class="rotate" data-animation="<?php echo esc_attr($tt_atts['animation'])?>" data-speed="<?php echo esc_attr($tt_atts['animation_speed']); ?>"><?php echo esc_html($tt_atts['title']);?></span></h2>
            <?php endif; ?>


            <?php if (wpb_js_remove_wpautop($content, true)) : ?>
                <div class="intro-sub"><?php echo wpb_js_remove_wpautop($content, true); ?></div>

                <?php if ($tt_atts['show_button'] == 'yes') : ?>
                    <a class="btn <?php echo esc_attr($tt_atts['button_class']); ?>" href="<?php echo esc_url($tt_a_href);?>" title="<?php echo esc_attr($tt_a_title);?>"><?php echo esc_html($tt_atts['button_text']); ?></a>
                <?php endif; ?>

            <?php endif; ?>
            
        </div> <!-- .intro -->
    </div> <!-- .tt-text-rotator -->

<?php echo ob_get_clean();