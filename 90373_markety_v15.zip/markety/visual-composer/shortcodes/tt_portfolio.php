<?php
	if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

	$tt_atts = vc_map_get_attributes( $this->getShortcode(), $atts );

	ob_start();

  	$taxonomy  = 'tt-portfolio-cat';
	$tax_terms = get_terms( $taxonomy );

	$grid_padding = '';
	if ($tt_atts['grid_padding'] == 'yes') :
		$grid_padding = 'grid-padding';
	else :
		$grid_padding = 'no-grid-padding';
	endif;

	$portfolio_thumb = 'markety-portfolio-thumb';

	if ($tt_atts['grid_column'] == '6') {
		$portfolio_thumb = 'markety-portfolio-large';
	}
?>
		
	<div class="portfolio-container <?php echo esc_attr($tt_atts['el_class'].' '.$grid_padding);?>">
		<?php if ($tt_atts['filter_visibility'] == 'visible') : ?>
			<div class="tt-filter-wrap <?php echo esc_attr($tt_atts['filter_style'].' '.$tt_atts['filter_alignment'].' '.$tt_atts['filter_color']); ?> ">
				<ul class="tt-filter list-inline">
					<li><button class="active" data-group="all"><?php esc_html_e('All', 'markety');?></button></li>
					<?php foreach ( $tax_terms as $term_id ) :
						$term = get_term( $term_id, 'tt-portfolio-cat' ); ?>
						<li>
							<button data-group="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></button>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<div class="row">
			<div class="tt-grid">
				<?php
				$args = array(
					'post_type'      => 'tt-portfolio',
					'posts_per_page' => $tt_atts['post_limit'],
					'post_status'    => 'publish',
				);


				$query = new WP_Query( $args ); ?>

				<?php if ( $query->have_posts() ) : ?>

					<!-- the loop -->
					<?php while ( $query->have_posts() ) : $query->the_post(); 

					$terms = wp_get_post_terms( get_the_ID(), 'tt-portfolio-cat' );
					$term = array();

					foreach ( $terms as $t ) :
						$term[ ] = '"'. $t->slug .'"';
					endforeach;

	            	$tt_attachment_id = get_post_thumbnail_id(get_the_ID());
					$tt_image_attr = wp_get_attachment_image_src($tt_attachment_id, 'full' );
            	
					?>
						<div class="tt-item portfolio-item col-md-<?php echo esc_attr($tt_atts['grid_column'] .' '. $tt_atts['grid_padding']);?> col-sm-6 col-xs-12" data-groups='[<?php echo implode( ',', $term ); ?>]'>

							<div class="item-wrapper">
			                    <?php echo get_the_post_thumbnail( get_the_ID(), $portfolio_thumb, array( 'class' => 'img-responsive', 'alt' => markety_alt_text()));
								?>

			                    <?php if ($tt_atts['mask_visibility'] == 'visible'): ?>
						            <?php 
						                $images = explode( ',', $tt_atts['portfolio_mask'] ); 
						                foreach ( $images as $key=>$attach_id ) :
						                    $tt_img_src = wp_get_attachment_image_src($attach_id, 'full'); ?>
						                    <div class="mask mask-<?php echo intval($key);?>">
						                        <img class="img-responsive" src="<?php echo esc_url($tt_img_src[0]); ?>" alt>
						                    </div>
						            <?php endforeach; ?>
						        <?php endif; ?>

			                    <div class="portfolio-intro">
			                      	<?php if ($tt_atts['link_button_visibility'] == 'visible') : ?>
				                      	<div class="action-btn">
				                        	<a href="<?php the_permalink(); ?>"><i class="fa fa-angle-right"></i></a>
				                      	</div>
			                      	<?php endif; ?>

			                      	<?php if ($tt_atts['title_visibility'] == 'visible') : ?>
                                    	<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <?php endif; ?>
			                      	
			                      	<?php if ($tt_atts['category_visibility'] == 'visible') : ?>
			                      		<p>
	                                    <?php markety_portfolio_cat(); ?>
	                                    </p>
                                   	<?php endif; ?>
			                      	
			                    </div> <!-- .portfolio-intro -->
			                </div> <!-- .item-wrapper -->

						</div> <!-- .tt-item -->
					<?php endwhile; ?>
					<!-- end of the loop -->

					<?php wp_reset_postdata(); ?>

				<?php else : ?>
					<p><?php esc_html_e( 'Sorry, portfolio not found !', 'markety' ); ?></p>
				<?php endif; ?>
				
			</div> <!-- .tt-grid -->
		</div> <!-- .row -->
	</div> <!-- .portfolio-container -->

<?php echo ob_get_clean();