<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; ?>

    <?php $tt_footer_style = markety_option('footer-style', false, 'footer-default');

	    $page_footer = "";
        if (function_exists('rwmb_meta')) : 
            $page_footer = rwmb_meta('markety_footer_style');
        endif;

        if ($page_footer == 'inherit-theme-option' || empty($page_footer)) :
            if ($tt_footer_style == 'footer-three-column') :
  		        get_footer('three-column');
  		    elseif ($tt_footer_style == 'footer-four-column') :
  		        get_footer('four-column');
  		    elseif ($tt_footer_style == 'footer-onepage') :
  		        get_footer('onepage');
  		    else :
  		        get_footer('default');
  		    endif;
        elseif($page_footer == 'footer-three-column') :
            get_footer('three-column');
       	elseif($page_footer == 'footer-four-column') :
       		get_footer('four-column');
       	elseif($page_footer == 'footer-onepage') :
       		get_footer('onepage');
       	else :
       		get_footer('default');
        endif; ?>

<?php wp_footer(); ?>

</body>
</html>