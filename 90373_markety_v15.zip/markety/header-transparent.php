<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<div class="header-wrapper navbar-fixed-top">
    <nav class="navbar navbar-default">
        <div class="container">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".mobile-toggle">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <div class="navbar-brand">
                    <h1>
                        <a href="<?php echo esc_url(site_url('/')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>">
                            <?php if (markety_option('logo-type', false, 'logo')) : 

                                $fallback_logo = get_template_directory_uri() . '/images/logo.png';
                                $fallback_retina_logo = get_template_directory_uri() . '/images/logo2x.png';

                                $default_logo = markety_option('logo', 'url', $fallback_logo);
                                $default_ratina_logo = markety_option('retina-logo', 'url', $fallback_retina_logo);
                                
                                // site logo
                                $site_logo = $default_logo;
                                $site_mobile_logo = $default_logo;
                                $site_sticky_logo = $default_logo;
                                $site_sticky_mobile_logo = $default_logo;

                                // site retina logo
                                $site_retina_logo = $default_ratina_logo;
                                $site_retina_mobile_logo = $default_ratina_logo;
                                $site_retina_sticky_logo = $default_ratina_logo;
                                $site_retina_sticky_mobile_logo = $default_ratina_logo;

                                // mobile logo
                                if (markety_option('mobile-logo', 'url')) :
                                    $site_mobile_logo = markety_option('mobile-logo', 'url', $fallback_logo);
                                endif;

                                if (markety_option('retina-mobile-logo', 'url')) :
                                    $site_retina_mobile_logo = markety_option('retina-mobile-logo', 'url', $fallback_retina_logo);
                                endif;

                                // Sticky logo
                                if (markety_option('sticky-logo', 'url')) :
                                    $site_sticky_logo = markety_option('sticky-logo', 'url', $fallback_logo);
                                endif;

                                if (markety_option('retina-sticky-logo', 'url')) :
                                    $site_retina_sticky_logo = markety_option('retina-sticky-logo', 'url', $fallback_retina_logo);
                                endif;

                                // Sticky Mobile
                                if (markety_option('sticky-mobile-logo', 'url')) :
                                    $site_sticky_mobile_logo = markety_option('sticky-mobile-logo', 'url', $fallback_logo);
                                endif;

                                if (markety_option('retina-sticky-mobile-logo', 'url')) :
                                    $site_retina_sticky_mobile_logo = markety_option('retina-sticky-mobile-logo', 'url', $fallback_retina_logo);
                                endif; ?>

                                <!-- site logo -->
                                <img class="site-logo hidden-xs" src="<?php echo esc_url($site_logo) ?>" data-at2x="<?php echo esc_url($site_retina_logo) ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>

                                <!-- mobile logo -->
                                <img class="mobile-logo visible-xs" src="<?php echo esc_url($site_mobile_logo) ?>" data-at2x="<?php echo esc_url($site_retina_mobile_logo) ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
                                
                                <!-- sticky logo -->
                                <?php if (markety_option('sticky-logo', 'url')): ?>
                                    <img class="sticky-logo" src="<?php echo esc_url($site_sticky_logo) ?>" data-at2x="<?php echo esc_url($site_retina_sticky_logo) ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
                                <?php endif; ?>

                                <!-- sticky mobile -->
                                <?php if (markety_option('sticky-mobile-logo', 'url')): ?>
                                    <img class="sticky-mobile-logo" src="<?php echo esc_url($site_sticky_mobile_logo) ?>" data-at2x="<?php echo esc_url($site_retina_sticky_mobile_logo) ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
                                <?php endif; ?>
                                    
                            <?php else : ?>
                                <?php if (markety_option('text-logo')) :
                                    echo esc_html(markety_option('text-logo'));
                                else :
                                    echo esc_html(get_bloginfo('name'));
                                endif;
                                ?>
                            <?php endif; ?>
                        </a>
                    </h1>
                </div> <!-- .navbar-brand -->
            </div> <!-- .navbar-header -->
            
            <div class="main-menu-wrapper hidden-xs clearfix">
                <div class="main-menu">
                    <?php if (markety_option('analysis-button-visibility')) : ?>
                        <div class="analysis-button pull-right">
                            <?php if (markety_option('analysis-button-link') == true): 

                            $analysis_link = "";

                            if (markety_option('analysis-button-page-link')) {
                                $analysis_link = get_page_link(markety_option('analysis-button-page-link'));
                            }

                            ?>
                                <a class="btn-blue btn-sm" href="<?php echo esc_url($analysis_link); ?>"><?php echo esc_html(markety_option('analysis-button-text', false, true))?></a>
                            <?php else : ?>
                                <a class="btn-blue btn-sm" href="<?php echo esc_url(markety_option('analysis-button-external-link')); ?>" target="_blank"><?php echo esc_html(markety_option('analysis-button-text', false, true))?></a>
                            <?php endif; ?>
                        </div> <!-- .analysis-button -->
                    <?php endif; ?>

                    <?php wp_nav_menu( apply_filters( 'markety_primary_wp_nav_menu', array(
                        'container'      => false,
                        'theme_location' => 'primary',
                        'items_wrap'     => '<ul id="%1$s" class="%2$s nav navbar-nav navbar-right">%3$s</ul>',
                        'walker'         => new Markety_Navwalker(),
                        'fallback_cb'    => 'Markety_Navwalker::fallback'
                    ))); ?>
                </div>
            </div> <!-- /navbar-collapse -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="visible-xs">
                <div class="mobile-menu collapse navbar-collapse mobile-toggle">
                    <?php wp_nav_menu( apply_filters( 'markety_primary_wp_nav_menu', array(
                          'container'      => false,
                          'theme_location' => 'primary',
                          'items_wrap'     => '<ul id="%1$s" class="%2$s nav navbar-nav">%3$s</ul>',
                          'walker'         => new Markety_Mobile_Navwalker(),
                          'fallback_cb'    => 'Markety_Mobile_Navwalker::fallback'
                    ))); ?>
                </div> <!-- /.navbar-collapse -->
            </div>
        </div><!-- .container-->
    </nav>
</div> <!-- .header-wrapper -->