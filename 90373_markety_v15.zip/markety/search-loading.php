<?php 
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

	<?php 
		$input_val = $_POST['input_val'];
		$cat_val = $_POST['cat_dropdown'];
		$tag_val = $_POST['tag_dropdown'];
		$orderby_val = $_POST['post_orderby'];
		$order_val = $_POST['post_order'];

	    if (empty($cat_val) && empty($tag_val)) :
	    	$args = array(
		    	's' 			=> $input_val,
		        'post_type' 	=> 'post',
		        'post_status' 	=> 'publish',
		        'posts_per_page'=> -1,
		        'orderby'		=> $orderby_val,
		        'order'			=> $order_val
		    );
	    else :
	    	$args = array(
		    	's' 			=> $input_val,
		        'post_type' 	=> 'post',
		        'post_status' 	=> 'publish',
		        'posts_per_page'=> -1,
		        'orderby'		=> $orderby_val,
		        'order'			=> $order_val,
		        'tax_query' 	=> array(
		        	'relation' => 'OR',
					array(
						'taxonomy' => 'category',
						'field'    => 'slug',
						'terms'    => $cat_val
					),
					array(
						'taxonomy' => 'post_tag',
						'field'    => 'slug',
						'terms'    => $tag_val
					)
				)
		    );
	    endif;
	    

	    $search = new WP_Query( $args );

	    if ( $search->have_posts() ) : 

		while ( $search->have_posts() ) : $search->the_post();

	?>

		<div class="col-xs-12">
			<?php get_template_part( 'template-parts/content', get_post_format() ); ?>
		</div>

		<?php endwhile; ?>

		<?php if ( markety_option( 'blog-page-nav', false, true ) ) {
			markety_posts_pagination();
		} else {
			markety_posts_navigation();
		} ?>

	<?php else : ?>

		<header class="page-header text-center">
			<i class="fa fa-dropbox"></i>
			<h2><?php esc_html_e( 'Nothing Found', 'markety' ); ?></h2>
			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'markety' ); ?></p>
		</header><!-- .page-header -->

	<?php endif; ?>
			