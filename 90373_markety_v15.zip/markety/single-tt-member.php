<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

get_header(); ?>
<div class="page-wrapper single-member-page">
	<div class="container">
		<div class="row">
			<?php while ( have_posts() ) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
					
					<div class="col-md-5 col-sm-5">
						<?php if ( has_post_thumbnail() ) : ?>
		  					<div class="member-thumb">
								<?php the_post_thumbnail( 'markety-member', array( 'class' => 'img-responsive', 'alt' => get_the_title())); ?>
							</div> <!-- .member-thumb -->
						<?php endif; ?>
					</div> <!-- .col -->
	  				
	  				<div class="col-md-7 col-sm-7">
						<div class="member-info-content">

							<?php if (function_exists('rwmb_meta')) :
	                            $member_designation = rwmb_meta('markety_member_designaion');
	                            if ($member_designation) : ?>
	                                <span class="designation"><?php echo esc_html($member_designation); ?></span>
	                            <?php endif;
	                        endif; ?>

	                        <?php if (function_exists('rwmb_meta')) : ?>
                            
	                            <div class="team-social">
	                                <ul class="list-inline">
	                                    <?php
	                                    
	                                    $facebook_link = rwmb_meta('markety_facebook_link');
	                                    if ($facebook_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($facebook_link); ?>"><i class="fa fa-facebook"></i></a>
	                                        </li>
	                                    <?php endif; 

	                                    $twitter_link = rwmb_meta('markety_twitter_link');
	                                    if ($twitter_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($twitter_link); ?>"><i class="fa fa-twitter"></i></a>
	                                        </li>
	                                    <?php endif; 

	                                    $google_plus_link = rwmb_meta('markety_google_plus_link');
	                                    if ($google_plus_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($google_plus_link); ?>"><i class="fa fa-google-plus"></i></a>
	                                        </li>
	                                    <?php endif; 

	                                    $linkedin_link = rwmb_meta('markety_linkedin_link');
	                                    if ($linkedin_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($linkedin_link); ?>"><i class="fa fa-linkedin"></i></a>
	                                        </li>
	                                    <?php endif;

	                                    $flickr_link = rwmb_meta('markety_flickr_link');
	                                    if ($flickr_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($flickr_link); ?>"><i class="fa fa-flickr"></i></a>
	                                        </li>
	                                    <?php endif;

	                                    $youtube_link = rwmb_meta('markety_youtube_link');
	                                    if ($youtube_link) : ?>
	                                        <li>
	                                            <a href="<?php echo esc_url($youtube_link); ?>"><i class="fa fa-youtube"></i></a>
	                                        </li>
	                                    <?php endif; ?>
	                                </ul>
	                            </div> <!-- .team-social -->

	                        <?php endif; ?>

							<?php the_content(); ?>

							<?php if (function_exists('rwmb_meta')) : ?>

								<?php if (rwmb_meta('markety_educational_qualification')): ?>
									<div class="educational-qualification">
										<?php echo rwmb_meta('markety_educational_qualification'); ?>
									</div>
								<?php endif ?>
								
								<?php if (rwmb_meta('markety_member_address')): ?>
									<address>
										<?php echo rwmb_meta('markety_member_address'); ?>
									</address>
								<?php endif ?>
								
							<?php endif; ?>

						</div> <!-- .member-info-content -->
					</div> <!-- .col-# -->
		  			
				</div> <!-- #post-# -->

			<?php endwhile; // end of the loop. ?>
		</div> <!-- .row -->

		
		<?php       
		$args = array(
			'post_type' => 'tt-member',
			'post_status' => 'publish',
			'posts_per_page' => 4, // you may edit this number
			'orderby' => 'rand',
			'post__not_in' => array ($post->ID)
		);
		$member_post = new WP_Query( $args ); ?>

		<?php if ( $member_post->have_posts() ) : ?>

			<div class="member-wrapper more-member">
				<div class="row">
					<div class="section-intro">
						<h2><?php esc_html_e('More Members', 'markety');?></h2>
					</div>
					<?php while ( $member_post->have_posts() ) : $member_post->the_post(); ?>
						
						<div class="col-xs-12 col-sm-6 col-md-3">
	                      	<div class="team-member-wrapper">
                        
		                        <div class="team-thumb">
		                            <?php the_post_thumbnail('markety-member', array('alt'=> get_the_title(), 'class' => 'img-responsive' ));?>
		                        </div>

		                        <div class="member-info text-center">
		                            <div class="member-title">
		                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		                                <?php if (function_exists('rwmb_meta')) :
		                                    $member_designation = rwmb_meta('markety_member_designaion');
		                                    if ($member_designation) : ?>
		                                        <span class="designation"><?php echo esc_html($member_designation); ?></span>
		                                    <?php endif; 
		                                endif; ?>
		                            </div>

	                                <div class="member-content">
	                                    <p>
	                                        <?php
	                                            $content = get_the_content();
	                                            echo wp_trim_words( $content, 12);
	                                        ?>
	                                    </p>
	                                </div>

		                            <?php if (function_exists('rwmb_meta')) : ?>
		                                
		                                <ul class="social-link list-inline">
		                                    <?php
		                                    
		                                    $facebook_link = rwmb_meta('markety_facebook_link');
		                                    if ($facebook_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($facebook_link); ?>"><i class="fa fa-facebook"></i></a>
		                                        </li>
		                                    <?php endif; 

		                                    $twitter_link = rwmb_meta('markety_twitter_link');
		                                    if ($twitter_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($twitter_link); ?>"><i class="fa fa-twitter"></i></a>
		                                        </li>
		                                    <?php endif; 

		                                    $google_plus_link = rwmb_meta('markety_google_plus_link');
		                                    if ($google_plus_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($google_plus_link); ?>"><i class="fa fa-google-plus"></i></a>
		                                        </li>
		                                    <?php endif; 

		                                    $linkedin_link = rwmb_meta('markety_linkedin_link');
		                                    if ($linkedin_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($linkedin_link); ?>"><i class="fa fa-linkedin"></i></a>
		                                        </li>
		                                    <?php endif;

		                                    $flickr_link = rwmb_meta('markety_flickr_link');
		                                    if ($flickr_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($flickr_link); ?>"><i class="fa fa-flickr"></i></a>
		                                        </li>
		                                    <?php endif;

		                                    $youtube_link = rwmb_meta('markety_youtube_link');
		                                    if ($youtube_link) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($youtube_link); ?>"><i class="fa fa-youtube"></i></a>
		                                        </li>
		                                    <?php endif;

		                                    $email_address = rwmb_meta('markety_member_email');
		                                    if ($email_address) : ?>
		                                        <li>
		                                            <a href="<?php echo esc_url($email_address); ?>"><i class="fa fa-envelope"></i></a>
		                                        </li>
		                                    <?php endif; ?>
		                                </ul>
		                            <?php endif; ?>
		                        </div><!-- /.member-info -->
		                    </div><!-- /.team-member-wrapper -->
	                    </div> <!-- .col-## -->
					<?php endwhile; ?>
				</div> <!-- .row -->
			</div> <!-- .more-member -->

			<?php wp_reset_postdata(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Member not found !', 'markety' ); ?></p>
		<?php endif; ?>
	</div> <!-- .container -->
</div><!-- .single-member-page -->

<?php get_footer(); ?>