<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

get_header(); ?>
<div class="portfolio-wrapper content-wrapper portfolio-category">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="main" class="row" role="main">

                    <?php
                    $term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
                    $paged = ( get_query_var('paged') ) ? absint( get_query_var('paged') ) : 1;
                    $args = array(
                        'post_type'      => 'tt-portfolio',
                        'posts_per_page' => markety_option('category-portfolio-limit', false, true),
                        'tt-portfolio-cat'   => $term->slug,
                        'post_status'    => 'publish',
                        'paged'          => $paged
                    );
                    $query = new WP_Query( $args ); ?>
                    <?php if ( $query->have_posts() ) : ?>

                        <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                            <div class="tt-item portfolio-item col-md-4 col-sm-6 col-xs-12">
                                <div class="item-wrapper">
                                    <?php echo get_the_post_thumbnail( get_the_ID(), 'markety-portfolio-thumb', array( 'class' => 'img-responsive', 'alt' => get_the_title()));
                                    ?>

                                    <?php if (markety_option('mask-show-hide', false, true)): 

                                        if (markety_option('mask-0')) : ?>
                                            <div class="mask mask-0">
                                                <img class="img-responsive" src="<?php echo esc_url(markety_option('mask-0', 'url')); ?>" alt>
                                            </div>
                                        <?php endif; 

                                        if (markety_option('mask-1')) : ?>
                                            <div class="mask mask-1">
                                                <img class="img-responsive" src="<?php echo esc_url(markety_option('mask-1', 'url')); ?>" alt>
                                            </div>
                                        <?php endif; ?>

                                    <?php endif ?>

                                    <div class="portfolio-intro">
                                        <div class="action-btn">
                                            <a href="<?php the_permalink(); ?>"><i class="fa fa-angle-right"></i></a>
                                        </div>

                                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                        <p>
                                        <?php markety_portfolio_cat(); ?>
                                        </p>
                                    </div> <!-- .portfolio-intro -->
                                </div> <!-- .item-wrapper -->
                            </div> <!-- .tt-item -->

                        <?php endwhile; ?>

                        <div class="col-md-12 text-center">
                            <?php markety_list_posts_pagination(); ?>
                        </div>

                        <?php
                    else : ?>
                        <p><?php esc_html_e('Portfolio not found !', 'markety');?></p>
                    <?php endif;
                        wp_reset_postdata();
                    ?>
                </div><!-- .row -->
            </div> <!-- .col-# -->
        </div> <!-- .row -->
    </div> <!-- .container -->
</div> <!-- .portfolio-wrapper -->
<?php get_footer();