<?php 
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

get_header(); ?>

<div class="single-project-section">
    <?php while ( have_posts() ) : the_post(); ?>

    	<?php if (markety_option('portfolio-navigation', false, true)) : ?>
			<div class="portfolio-nav">

				<?php previous_post_link( '<div class="prev">%link</div>', markety_previous_post_image('markety-portfolio-mini') . '<i class="fa fa-angle-left"></i>'); ?>

				<?php next_post_link( '<div class="next">%link</div>', '<i class="fa fa-angle-right"></i>' . markety_next_post_image( 'markety-portfolio-mini' )); ?>

	        </div>
		<?php endif; ?>

		<?php the_content(); ?>

	<?php endwhile; // End of the loop. ?>
</div> <!-- .single-project-section -->

<?php get_footer(); ?>