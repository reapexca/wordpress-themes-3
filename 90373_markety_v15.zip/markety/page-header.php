<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

$tt_page_template = basename( get_page_template_slug() );

$header_page_settings = NULL;

if (function_exists('rwmb_meta')) :
    $header_page_settings = rwmb_meta('markety_page_header_visibility');
endif;


if ($header_page_settings == 'header-section-show' || $header_page_settings == NULL) :

    if ( is_page() and $tt_page_template != 'template-home.php' and $tt_page_template != 'blog-grid-home.php' and $tt_page_template != 'template-no-footer.php' and $tt_page_template != 'template-shop.php') : 
        get_template_part( 'template-parts/page-header', 'section' );
    endif;

    if ( ! is_page() && ! is_404() && ! is_singular('post')) : 
        get_template_part( 'template-parts/page-header', 'section' );
    endif;

endif;