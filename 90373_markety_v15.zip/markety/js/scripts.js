/*
Theme Name: Markety
Author: TrendyTheme
*/

/* ======= TABLE OF CONTENTS ================================== 
    # Preloader
    # Enable bootstrap tooltip
    # Detect IE version
    # jQuery for page scrolling feature - requires jQuery Easing plugin
    # Mobile Dropdown Menu
    # Navbar collapse on click
    # Dropdown menu offest
    # Sticky Menu
    # Full Screen Background
    # Textrotator
    # Counter
    # Stellar for background scrolling
    # Magnific Popup
    # Magnific Popup for embeds
    # Masonry Grid
    # Partner Carousel
    # Testimonial Carousel
    # Gallery
    # Home slider
    # Shuffle for portfolio filter
    # Flickr photo
    # Ajax Post Search
    # Material input style
    # Product quantity
    # Google Map
========================================================= */

jQuery(function ($) {

    "use strict";

    /* ======= Preloader ======= */
    (function () {
        $('#status').fadeOut();
        $('#preloader').delay(200).fadeOut('slow');
    }());


    /* ======= Enable bootstrap tooltip ======= */
    (function () {
        $('[data-toggle="tooltip"]').tooltip()
    }());


    /* === Detect IE version === */
    (function () {
        function getIEVersion() {
            var match = navigator.userAgent.match(/(?:MSIE |Trident\/.*; rv:)(\d+)/);
            return match ? parseInt(match[1], 10) : false;
        }

        if( getIEVersion() ){
            $('html').addClass('ie'+getIEVersion());
        }
    }());


    /* === jQuery for page scrolling feature - requires jQuery Easing plugin === */
    (function () {
        $('.navbar-nav a[href^="#"], .tt-scroll').on('click', function (e) {
            e.preventDefault();

            var target = this.hash;
            var $target = $(target);
            var headerHeight = $('.navbar-header, .header-wrapper.sticky .navbar-header').outerHeight();
            
            if (target) {
                $('html, body').stop().animate({
                    'scrollTop': $target.offset().top - headerHeight + "px"
                }, 1200, 'easeInOutExpo', function () {
                    window.location.hash = target;
                });
            }
        });
    }());


    /* === Mobile Dropdown Menu === */
    (function(){
        $('.dropdown-menu-trigger').each(function() {
            $(this).on('click', function(e){
                $(this).toggleClass('menu-collapsed');
            });
        });
    }());


    /* === Navbar collapse on click === */
    $('.navbar-nav > li > a[href^="#"]').on('click', function(e) {
        $('.mobile-toggle').removeClass('in');
    });


    /* === Dropdown menu offest === */
    $(window).on('load resize', function () {
        $(".dropdown-wrapper > ul > li").each(function() {
            var $this = $(this),
                $win = $(window);

            if ($this.offset().left + 195 > $win.width() + $win.scrollLeft() - $this.width()) {
                $this.addClass("dropdown-inverse");
            } else {
                $this.removeClass("dropdown-inverse");
            }
        });
    });


    /* === Sticky Menu === */
    (function () {
        if (marketyJSObject.markety_sticky_menu == true) {
            var body = $('body');
            var nav = $('.header-wrapper');
            var scrolled = false;

            $(window).scroll(function () {

                if (20 < $(window).scrollTop() && !scrolled) {
                    body.addClass('active-sticky');
                    nav.addClass('sticky').animate({ 'margin-top': '0px' });
                    scrolled = true;
                }

                if (20 > $(window).scrollTop() && scrolled) {
                    body.removeClass('active-sticky');
                    nav.removeClass('sticky').css('margin-top', '0px');
                    scrolled = false;
                }
            });
        }
    }());


    /* ======= Full Screen Background ======= */
    $(".tt-fullHeight").height($(window).height());
    $(window).resize(function(){
        $(".tt-fullHeight").height($(window).height());
    });


    /* ======= Textrotator ======= */
    if ($('.rotate').length > 0) {
        $(".rotate").textrotator({
            animation: "dissolve", // You can pick the way it animates when rotating through words. Options are dissolve (default), fade, flip, flipUp, flipCube, flipCubeUp and spin.
            separator: "|", //  You can define a new separator (|, &, * etc.) by yourself using this field.
            speed: 3000 // How many milliseconds until the next word show.
        });
    }


    /* === Counter === */
    $('.counter-section').on('inview', function(event, visible, visiblePartX, visiblePartY) {
        if (visible) {
            $(this).find('.timer').each(function () {
                var $this = $(this);
                $({ Counter: 0 }).animate({ Counter: $this.text() }, {
                    duration: 2000,
                    easing: 'swing',
                    step: function () {
                        $this.text(Math.ceil(this.Counter));
                    }
                });
            });
            $(this).off('inview');
        }
    });


    /* ======= Stellar for background scrolling ======= */
    (function () {

        $(window).on('load', function () {

            if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
             
            } else {
                $(window).stellar({
                    horizontalScrolling: false,
                    responsive: true
                });
            }

        });

    }());


    /* ======= Magnific Popup ======= */
    (function () {
        $(".tt-lightbox, .image-link, .tt-flickr-photo a, .woocommerce-product-gallery__image > a").magnificPopup({
            type: 'image',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            fixedContentPos: false,
            gallery:{
                enabled:true
            }
        });
    }());


    /* ======= Magnific Popup for embeds ======= */
    $('.tt-popup').magnificPopup({
        disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: true,
        fixedContentPos: false
    });


    /* === Masonry Grid  === */
    $(window).load(function () {
        $('.masonry-wrap').masonry({
            "columnWidth" : ".masonry-column"
        });
    });


    /* ======= Partner Carousel ======= */
    (function () {
        $('.partner-carousel-wrapper').each(function(i, e){

            var partnerCarousal = $(this).find('.partner-carousel');
            var slideRow = parseInt(partnerCarousal.attr('data-sliderow'));
            var itemGutter = parseInt(partnerCarousal.attr('data-gutter'));

            // responsive settings
            var partnerCarousalItems = parseInt(partnerCarousal.attr('data-largescreen'));
            var partnerCarousalItemsDesktop = parseInt(partnerCarousal.attr('data-desktop'));
            var partnerCarousalItemsTablet = parseInt(partnerCarousal.attr('data-tablet'));
            var partnerCarousalItemsMobileLarge = parseInt(partnerCarousal.attr('data-mobilelarge'));
            var partnerCarousalItemsMobile = parseInt(partnerCarousal.attr('data-mobile'));

            var swiper = new Swiper(partnerCarousal, {
                slidesPerView: partnerCarousalItems,
                centeredSlides: false,
                spaceBetween: itemGutter,
                keyboardControl: true,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
                slidesPerColumn: slideRow,
                breakpoints: {
                    1024: {
                        slidesPerView: partnerCarousalItemsDesktop,
                        spaceBetween: itemGutter
                    },
                    768: {
                        slidesPerView: partnerCarousalItemsTablet,
                        spaceBetween: itemGutter
                    },
                    640: {
                        slidesPerView: partnerCarousalItemsMobileLarge,
                        spaceBetween: itemGutter
                    },
                    320: {
                        slidesPerView: partnerCarousalItemsMobile,
                        spaceBetween: itemGutter
                    }
                }
            });
        });
    }());


    /* ======= Testimonial Carousel ======= */
    (function () {
        $('.testimonial-carousel-wrapper').each(function(i, e){

            var quoteCarousal = $(this).find('.testimonial-carousel');
            var slideRow = parseInt(quoteCarousal.attr('data-sliderow'));
            var itemGutter = parseInt(quoteCarousal.attr('data-gutter'));

            // responsive settings
            var quoteCarousalItems = parseInt(quoteCarousal.attr('data-largescreen'));
            var quoteCarousalItemsDesktop = parseInt(quoteCarousal.attr('data-desktop'));
            var quoteCarousalItemsTablet = parseInt(quoteCarousal.attr('data-tablet'));
            var quoteCarousalItemsMobileLarge = parseInt(quoteCarousal.attr('data-mobilelarge'));
            var quoteCarousalItemsMobile = parseInt(quoteCarousal.attr('data-mobile'));

            var swiper = new Swiper(quoteCarousal, {
                loop: true,
                slidesPerView: quoteCarousalItems,
                centeredSlides: true,
                spaceBetween: itemGutter,
                autoHeight: true,
                keyboardControl: true,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
                pagination: '.swiper-pagination',
                paginationClickable: true,
                slidesPerColumn: slideRow,
                breakpoints: {
                    1024: {
                        slidesPerView: quoteCarousalItemsDesktop,
                        spaceBetween: itemGutter
                    },
                    768: {
                        slidesPerView: quoteCarousalItemsTablet,
                        spaceBetween: itemGutter
                    },
                    640: {
                        slidesPerView: quoteCarousalItemsMobileLarge,
                        spaceBetween: itemGutter
                    },
                    320: {
                        slidesPerView: quoteCarousalItemsMobile,
                        spaceBetween: itemGutter
                    }
                }
            });
        });
    }());



    /* === Gallery === */
    $(window).on('load', function () {
        // The slider being synced must be initialized first
        $('.tt-gallery-wrapper').each(function(i, e){

            var ttGalleryNav = $(this).find('.tt-gallery-nav');
            var ttGalleryThumb = $(this).find('.tt-gallery-thumb');
            var ttGallery = $(this).find('.tt-gallery');

            ttGalleryThumb.flexslider({
                animation     : "slide",
                controlNav    : false,
                animationLoop : true,
                slideshow     : false,
                itemWidth     : 185,
                asNavFor      : ttGallery
            });

            ttGallery.flexslider({
                animation     : "slide",
                directionNav  : false,
                controlNav    : false,
                animationLoop : false,
                slideshow     : false,
                sync          : ttGalleryThumb
            });

            // Navigation 
            ttGalleryNav.find('.prev').on('click', function (e) {
                ttGallery.flexslider('prev')
                return false;
            });

            ttGalleryNav.find('.next').on('click', function (e) {
                ttGallery.flexslider('next')
                return false;
            });
        });
    });


    /* ======= Home slider ======= */
    (function(){
        $('.tt-home-slider').superslides({
            play: 7000, 
            pagination: false,
            hashchange: false,
            animation: 'fade'
        });
    }());
    

    /* === Shuffle for portfolio filter  === */

    $(window).on('load', function () {

        $('.portfolio-container').each(function(i, e){

            var ttGrid = $(this).find('.tt-grid');
            var self = this;
            ttGrid.shuffle({
                itemSelector: '.tt-item' // the selector for the items in the grid
            });

            /* reshuffle when user clicks button filter item */
            $(this).find('.tt-filter button').on('click', function (e) {
                e.preventDefault();

                // set active class
                $(self).find('.tt-filter button').removeClass('active');
                $(this).addClass('active');

                // get group name from clicked item
                var ttGroupName = $(this).attr('data-group');

                // reshuffle grid
                ttGrid.shuffle('shuffle', ttGroupName);
            });

        });

    });



    /* === Flickr photo === */
    (function () {

        var ttFlickr = $('.tt-flickr-photo');
        ttFlickr.jflickrfeed({
        limit: ttFlickr.attr('data-photo-limit'),
        qstrings: {
            id: ttFlickr.attr('data-flickr-id')
        },
        itemTemplate: '<li>'+
                        '<a href="{{image}}" title="{{title}}">' +
                            '<img src="{{image_s}}" alt="{{title}}" />' +
                        '</a>' +
                      '</li>'
        });

    }());


    
    /* ======= Ajax Post Search ======= */
    (function(){
        
        $('.search-filter-wrapper form').on( 'submit', function() {
            var $form = $(this);
            var $input = $form.find('input[name="s"]');
            var $select_cat_val = $form.find('.post-categories select');
            var $select_tag_val = $form.find('.post-tags select');
            var $select_ob_val = $form.find('.post-orderby select');
            var $select_order_val = $form.find('.post-order select');
            var input_val = $input.val();
            var cat_val = $select_cat_val.val();
            var tag_val = $select_tag_val.val();
            var orderby_val = $select_ob_val.val();
            var order_val = $select_order_val.val();

            var $content = $('.posts-content');

            $.ajax({
                type : 'post',
                url : marketyJSObject.ajaxurl,
                data : {
                    action : 'load_search_results',
                    cat_dropdown: cat_val,
                    tag_dropdown: tag_val,
                    post_orderby: orderby_val,
                    post_order: order_val,
                    input_val : input_val
                },
                beforeSend: function() {
                    $input.prop('disabled', true);
                    $content.addClass('loading');
                },
                success : function( response ) {
                    $input.prop('disabled', false);
                    $content.removeClass('loading');
                    $content.html( response );
                }
            })
            
            return false;
        })
    }());


    /* ======= Material input style ======= */
    (function () {

        $(".input-wrap .form-control").each(function () {
            if ($(this).val() !== "") {
                $(this).closest('.input-wrap').addClass("is-completed");
            }
        });

        $(".input-wrap .form-control").on('focus', function () {
            $(this).closest('.input-wrap').addClass("is-active is-completed");
        });

        $(".input-wrap .form-control").on('focusout', function () {
            if ($(this).val() === "") {
                $(this).closest('.input-wrap').removeClass("is-completed");
            }
            $(this).closest('.input-wrap').removeClass("is-active");
        });
    }());


    /* ======= Product quantity ======= */
    (function(){
        $('.plus').on('click',function(e){
            var val = parseInt($(this).prev('input').val());
            $(this).prev('input').val( val+1 );
        });

        $('.minus').on('click',function(e){
            var val = parseInt($(this).next('input').val());
            if(val !== 0){
                $(this).next('input').val( val-1 );
            } 
        });

        $('.quantity input.btn-quantity').on('click', function(){
            $('.woocommerce').find('.shop_table td.actions input.button').removeAttr( "disabled" );
        });
    }());

});


/* ======= Google Map ======= */
    
if (jQuery('.map-section').length > 0) {
    function initialize() {
        var centerMarker = jQuery('.address-0');
        var latOne = centerMarker.attr('data-lat');
        var lngOne = centerMarker.attr('data-lng');
        var mapZoom = parseInt(centerMarker.attr('data-zoom'));

        var map = new google.maps.Map(document.getElementById('ttmap'), {
            zoom: mapZoom,
            center: new google.maps.LatLng(latOne,lngOne),
            scrollwheel: false,
            styles: [
                {
                    "featureType": "landscape",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "lightness": 65
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "poi",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "lightness": 51
                        },
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "road.arterial",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "lightness": 30
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "road.local",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "lightness": 40
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "transit",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "administrative.province",
                    "stylers": [
                        {
                            "visibility": "off"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "labels",
                    "stylers": [
                        {
                            "visibility": "on"
                        },
                        {
                            "lightness": -25
                        },
                        {
                            "saturation": -100
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "hue": "#ffff00"
                        },
                        {
                            "lightness": -25
                        },
                        {
                            "saturation": -97
                        }
                    ]
                }
            ],
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        var infowindow = new google.maps.InfoWindow();
        var marker;
        var location = {};
        var markers = document.getElementsByClassName("address");

        for (var i = 0; i < markers.length; i++) {
            location = {
                name : markers[i].getAttribute("data-info"),
                pointlat : parseFloat(markers[i].getAttribute("data-lat")),
                pointlng : parseFloat(markers[i].getAttribute("data-lng"))   
            };
            // console.log(location);
            marker = new google.maps.Marker({
                position: new google.maps.LatLng(location.pointlat, location.pointlng),
                map: map,
                icon: markers[i].getAttribute("data-marker")
            });

            google.maps.event.addListener(marker, 'click', (function(marker,location) {
                return function() {
                    infowindow.setContent(location.name);
                    infowindow.open(map, marker);
                };
            })(marker, location));
        }
    }
    google.maps.event.addDomListener(window, 'load', initialize);
}