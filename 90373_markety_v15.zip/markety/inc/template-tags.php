<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Single blog post navigation
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_post_navigation')) :

    function markety_post_navigation() {

        $prev_post = (is_attachment()) ? get_post(get_post()->post_parent) : get_adjacent_post(false, '', true);
        $next_post = get_adjacent_post(false, '', false);

        if (!$next_post && !$prev_post) :
            return;
        endif;
        ?>
        <?php do_action('markety_before_single_post_navigation' );?>
        <nav class="single-post-navigation" role="navigation">
            <div class="row">
                <?php if ($prev_post): ?>
                    <!-- Previous Post -->
                    <div class="col-xs-6">
                        <div class="previous-post-link">
                            <?php previous_post_link('<div class="previous">%link</div>', '<i class="fa fa-long-arrow-left"></i>' . esc_html__( 'Previous Post', 'markety' )); ?>
                        </div>
                    </div>
                <?php endif ?>
                
                <?php if ($next_post): ?>
                    <!-- Next Post -->
                    <div class="col-xs-6">
                        <div class="next-post-link">
                            <?php next_post_link('<div class="next">%link</div>', esc_html__( 'Next Post', 'markety' ) . '<i class="fa fa-long-arrow-right"></i>'); ?>
                        </div>
                    </div>
                <?php endif ?>
            </div> <!-- .row -->
        </nav> <!-- .single-post-navigation -->
        <?php do_action('markety_after_single_post_navigation' );?>
    <?php
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Blog posts navigation
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_posts_navigation')) :

    function markety_posts_navigation() { ?>
        <div class="blog-navigation clearfix">
            <?php if (get_next_posts_link()) : ?>
                <div class="col-xs-6 pull-left">
                    <div class="previous-page">
                        <?php next_posts_link('<i class="fa fa-long-arrow-left"></i>' . esc_html('Older Posts', 'markety')); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (get_previous_posts_link()) : ?>
                <div class="col-xs-6 pull-right">
                    <div class="next-page">
                        <?php previous_posts_link(esc_html__('Newer Posts', 'markety') . '<i class="fa fa-long-arrow-right"></i>'); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Blog posts pagination for default blog layout
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_posts_pagination')) :
    function markety_posts_pagination() { 

        global $wp_query;
            if ($wp_query->max_num_pages > 1) {
                $big = 999999999; // need an unlikely integer
                $items = paginate_links(array(
                    'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format'    => '?paged=%#%',
                    'prev_next' => true,
                    'current'   => max(1, get_query_var('paged')),
                    'total'     => $wp_query->max_num_pages,
                    'type'      => 'array',
                    'prev_text' => '<i class="fa fa-angle-left"></i>'.esc_html__('Prev.', 'markety'),
                    'next_text' => esc_html__('Next', 'markety').'<i class="fa fa-angle-right"></i>'
                ));

                $pagination = "<ul class=\"pagination\">\n\t<li>";
                $pagination .= join("</li>\n\t<li>", $items);
                $pagination .= "</li>\n</ul>\n";

                echo $pagination;
            } 

        return;

    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Blog list style posts pagination
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if ( ! function_exists( 'markety_list_posts_pagination' ) ):

    function markety_list_posts_pagination() { ?>
        <?php

        global $query;

        $big   = 999999999; // need an unlikely integer
        $items = paginate_links(array(
            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format'    => '?paged=%#%',
            'prev_next' => TRUE,
            'current'   => max( 1, get_query_var( 'paged' ) ),
            'total'     => $query->max_num_pages,
            'type'      => 'array',
            'prev_text' => esc_html__( 'Prev.', 'markety' ),
            'next_text' => esc_html__( 'Next', 'markety' )
        ) );

        $pagination = '<ul class="pagination"><li>';
        $pagination .= join( "</li><li>", (array) $items );
        $pagination .= "</li></ul>";

        echo $pagination;
    }

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Page break pagination
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_link_pages')) :

    function markety_link_pages($args = '') {
        $defaults = array(
            'before'           => '',
            'after'            => '',
            'link_before'      => '',
            'link_after'       => '',
            'next_or_number'   => 'number',
            'nextpagelink'     => esc_html__('Next page', 'markety'),
            'previouspagelink' => esc_html__('Previous page', 'markety'),
            'pagelink'         => '%',
            'echo'             => 1
        );

        $r = wp_parse_args($args, $defaults);
        $r = apply_filters('wp_link_pages_args', $r);
        extract($r, EXTR_SKIP);

        global $page, $numpages, $multipage, $more, $pagenow;

        $output = '';
        if ($multipage) {
            if ('number' == $next_or_number) {
                $output .= $before . '<ul class="pagination">';
                $laquo = $page == 1 ? 'class="disabled"' : '';
                $output .= '<li ' . $laquo . '>' . _wp_link_page($page - 1) . '&laquo; </a></li>';
                for ($i = 1; $i < ($numpages + 1); $i = $i + 1) {
                    $j = str_replace('%', $i, $pagelink);

                    if (($i != $page) || ((!$more) && ($page == 1))) {
                        $output .= '<li>';
                        $output .= _wp_link_page($i);
                    } else {
                        $output .= '<li class="active">';
                        $output .= _wp_link_page($i);
                    }
                    $output .= $link_before . $j . $link_after;

                    $output .= '</a></li>';
                }
                $raquo = $page == $numpages ? 'class="disabled"' : '';
                $output .= '<li ' . $raquo . '>' . _wp_link_page($page + 1) . '&raquo;</a></li>';
                $output .= '</ul>' . $after;
            } else {
                if ($more) {
                    $output .= $before . '<ul class="pager">';
                    $i = $page - 1;
                    if ($i && $more) {
                        $output .= '<li class="previous">' . _wp_link_page($i);
                        $output .= $link_before . $previouspagelink . $link_after . '</li>';
                    }
                    $i = $page + 1;
                    if ($i <= $numpages && $more) {
                        $output .= '<li class="next">' . _wp_link_page($i);
                        $output .= $link_before . $nextpagelink . $link_after . '</a></li>';
                    }
                    $output .= '</ul>' . $after;
                }
            }
        }

        if ($echo) {
            echo $output;
        } else {
            return $output;
        }
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Prints HTML with meta information for the current post-date/time, author & others.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_posted_on')) :
    function markety_posted_on() { ?>
        <ul class="entry-meta clearfix">
            <?php if ( markety_option( 'tt-post-meta', 'post-author', TRUE ) ) : ?>
                <li>
                    <span class="author vcard">
                        <?php printf('<a class="url fn n" href="%1$s"><i class="fa fa-user"></i><span itemprop="author">%2$s<span></a>',
                            esc_url(get_author_posts_url(get_the_author_meta('ID'))),
                            esc_html(get_the_author())
                        ) ?>
                    </span>
                </li>
            <?php endif; ?>
            
            <?php if ( markety_option( 'tt-post-meta', 'post-date', TRUE ) ) : ?>
                <li>
                    <a href="<?php the_permalink(); ?>"><i class="fa fa-clock-o"></i><span itemprop="datePublished" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time( get_option( 'date_format' ) ); ?></span></a>
                </li>
            <?php endif; ?>

            <?php if ( markety_option( 'tt-post-meta', 'post-comment', TRUE ) ) : ?>
                <li>
                    <span class="post-comments" itemprop="commentCount">
                        <?php comments_popup_link(
                                esc_html__('0', 'markety'),
                                esc_html__('1', 'markety'),
                                esc_html__('%', 'markety'), '',
                                esc_html__('Comments are Closed', 'markety')
                            ); 
                        ?>
                    </span>
                </li>
            <?php endif; ?>

            <?php if (function_exists('zilla_likes') && markety_option( 'tt-post-meta', 'post-like', TRUE )) : ?>
                <li>
                    <span class="likes">
                        <?php zilla_likes(); ?>
                    </span>
                </li>
            <?php endif; ?>

            <?php echo edit_post_link(esc_html__('Edit Post', 'markety'), '<li class="edit-link">', '</li>') ?>
        </ul>
    <?php
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Post meta for grid style post
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if (!function_exists('markety_grid_posted_on')) :
    function markety_grid_posted_on() { ?>

        <ul class="entry-meta clearfix">
            <li>
                <span class="author vcard">
                    <?php printf('<a class="url fn n" href="%1$s"><i class="fa fa-user"></i><span itemprop="author">%2$s<span></a>',
                        esc_url(get_author_posts_url(get_the_author_meta('ID'))),
                        esc_html(get_the_author())
                    ) ?>
                </span>
            </li>
            <li>
                <a href="<?php the_permalink(); ?>"><i class="fa fa-clock-o"></i><span itemprop="datePublished" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time( get_option( 'date_format' ) ); ?></span></a>
            </li>

            <?php echo edit_post_link(esc_html__('Edit Post', 'markety'), '<li class="edit-link">', '</li>') ?>
        </ul>
    <?php
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Returns true if a blog has more than 1 category.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_categorized_blog')) :
    
    function markety_categorized_blog() {
        if (false === ($all_the_cool_cats = get_transient('markety_categories'))) :
            // Create an array of all the categories that are attached to posts.
            $all_the_cool_cats = get_categories(array(
                'fields'     => 'ids',
                'hide_empty' => 1,

                // We only need to know if there is more than one category.
                'number'     => 2,
            ));

            // Count the number of categories that are attached to the posts.
            $all_the_cool_cats = count($all_the_cool_cats);

            set_transient('markety_categories', $all_the_cool_cats);
        endif;

        if ($all_the_cool_cats > 1) :
            // This blog has more than 1 category so markety_categorized_blog should return true.
            return true;
        else :
            // This blog has only 1 category so markety_categorized_blog should return false.
            return false;
        endif;
    }

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Flush out the transients used in nominee_categorized_blog.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_category_transient_flusher')) :

    function markety_category_transient_flusher() {
        // Like, beat it. Dig?
        delete_transient('markety_categories');
    }

    add_action('edit_category', 'markety_category_transient_flusher');
    add_action('save_post', 'markety_category_transient_flusher');

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//  Post Password form
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_post_password_form')) :

    function markety_post_password_form() {
        global $post;
        $markety_label_text = 'pwbox-' . (empty($post->ID) ? rand() : $post->ID);

        return '
        <div class="row">
            <form class="clearfix" action="' . esc_url(site_url('wp-login.php?action=postpass', 'login_post')) . '" method="post">
                <div class="col-md-12">
                    <label for="' . $markety_label_text . '">' . esc_html__("This post is password protected. To view it please enter your password below:", 'markety') . '</label>
                    <div class="input-group">
                        <input class="form-control" name="post_password" placeholder="' . esc_attr__("Password:", 'markety') . '" id="' . $markety_label_text . '" type="password" /><div class="input-group-btn"><button class="btn btn-primary" type="submit" name="Submit">' . esc_attr__("Submit", 'markety') . '</button></div>
                    </div>
                </div>
            </form>
        </div>';
    }

    add_filter('the_password_form', 'markety_post_password_form');
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Breadcrumb
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_breadcrumbs')) :

    function markety_breadcrumbs(){ ?>
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo esc_url(site_url()); ?>"><?php esc_html_e('Home', 'markety') ?></a>
            </li>
            <li class="active">
                <?php if( is_tag() ) { ?>
                <?php esc_html_e('Posts Tagged ', 'markety') ?><span class="raquo">/</span><?php single_tag_title(); echo('/'); ?>
                <?php } elseif (is_day()) { ?>
                <?php esc_html_e('Posts made in', 'markety') ?> <?php echo get_the_time('F jS, Y'); ?>
                <?php } elseif (is_month()) { ?>
                <?php esc_html_e('Posts made in', 'markety') ?> <?php echo get_the_time('F, Y'); ?>
                <?php } elseif (is_year()) { ?>
                <?php esc_html_e('Posts made in', 'markety') ?> <?php echo get_the_time('Y'); ?>
                <?php } elseif (is_search()) { ?>
                <?php esc_html_e('Search results for', 'markety') ?> <?php the_search_query() ?>
                <?php } elseif (is_404()) { ?>
                <?php esc_html_e('404', 'markety') ?>
                <?php } elseif (is_single()) { ?>
                <?php $category = get_the_category();
                if ( $category ) { 
                    $catlink = get_category_link( $category[0]->cat_ID );
                    echo ('<a href="'.esc_url($catlink).'">'.esc_html($category[0]->cat_name).'</a> '.'<span class="raquo"> /</span> ');
                }
                echo get_the_title(); ?>
                <?php } elseif (is_category()) { ?>
                <?php single_cat_title(); ?>
                <?php } elseif (is_tax()) { ?>
                <?php 
                $markety_taxonomy_links = array();
                $markety_term = get_queried_object();
                $markety_term_parent_id = $markety_term->parent;
                $markety_term_taxonomy = $markety_term->taxonomy;

                while ( $markety_term_parent_id ) {
                    $markety_current_term = get_term( $markety_term_parent_id, $markety_term_taxonomy );
                    $markety_taxonomy_links[] = '<a href="' . esc_url( get_term_link( $markety_current_term, $markety_term_taxonomy ) ) . '" title="' . esc_attr( $markety_current_term->name ) . '">' . esc_html( $markety_current_term->name ) . '</a>';
                    $markety_term_parent_id = $markety_current_term->parent;
                }

                if ( !empty( $markety_taxonomy_links ) ) echo implode( ' <span class="raquo">/</span> ', array_reverse( $markety_taxonomy_links ) ) . ' <span class="raquo">/</span> ';

                echo esc_html( $markety_term->name ); 
                } elseif (is_author()) { 
                    global $wp_query;
                    $curauth = $wp_query->get_queried_object();

                    esc_html_e('Posts by: ', 'markety'); echo ' ',$curauth->nickname; 
                } elseif (is_page()) { 
                    echo get_the_title(); 
                } elseif (is_home()) { 
                    esc_html_e('Blog', 'markety');
                } elseif (class_exists('WooCommerce') and (is_shop())){
                    esc_html_e('Shop', 'markety');
                } ?>  
            </li>
        </ul>
    <?php
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Page header section background title
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_page_header_section_title')) :
    function markety_page_header_section_title() {
        $markety_query = get_queried_object();

        if (is_archive()) :
            if (is_day()) :
                $archive_title = get_the_time('d F, Y');
                $page_header_title = sprintf(esc_html__('Archive of: %s', 'markety'), $archive_title);
            elseif (is_month()) :
                $archive_title = get_the_time('F Y');
                $page_header_title = sprintf(esc_html__('Archive of: %s', 'markety'), $archive_title);
            elseif (is_year()) :
                $archive_title = get_the_time('Y');
                $page_header_title = sprintf(esc_html__('Archive of: %s', 'markety'), $archive_title);
            endif;
        endif;

        if (is_404()) :
            $page_header_title = esc_html__('404 Not Found', 'markety');
        endif;

        if (is_search()) :
            $page_header_title = sprintf(esc_html__('Search result for: "%s"', 'markety'), get_search_query());
        endif;

        if (is_category()) :
            $page_header_title = sprintf(esc_html__('Category: %s', 'markety'), $markety_query->name);
        endif;

        if (is_tag()) :
            $page_header_title = sprintf(esc_html__('Tag: %s', 'markety'), $markety_query->name);
        endif;

        if (is_author()) :
            $page_header_title = sprintf(esc_html__('Posts of: %s', 'markety'), $markety_query->display_name);
        endif;

        if (is_tax()) :
            $page_header_title = sprintf(esc_html__('%s', 'markety'), $markety_query->name);
        endif;

        if (is_tax('tt-portfolio-cat')) :
            $page_header_title = sprintf(esc_html__('%s', 'markety'), $markety_query->name);
        endif;

        if (is_page()) :
            $page_header_title = $markety_query->post_title;
        endif;

        if (is_home() or is_single()) :
            $page_header_title = markety_option('blog-title');
        endif;

        if (is_single()) :
            $page_header_title = get_the_title();
        endif;

        if (is_singular()) :
            $page_header_title = get_the_title();
        endif;

        if (is_singular('tt-member')) :
            $page_header_title = get_the_title();
        endif;

        if (is_singular('tt-portfolio')) :
            $page_header_title = get_the_title();
        endif;

        if (is_singular('product')) :
            $page_header_title = get_the_title();
        endif;

        if ( is_post_type_archive( ) ) {
            $page_header_title = post_type_archive_title( '', FALSE );
        }

        if (class_exists( 'WooCommerce' ) ) :
            if ( is_post_type_archive( 'product' ) ) {
                $page_header_title = post_type_archive_title( '', FALSE );
            }

            if ( is_product_category() ) {
                $page_header_title = sprintf( __( '%s', 'markety' ), $markety_query->name );
            }

            if ( is_product_tag() ) {
                $page_header_title = sprintf( __( '%s', 'markety' ), $markety_query->name );
            }
        endif;

        $page_header_title = apply_filters('markety_page_header_section_title', $page_header_title, $page_header_title);

        if (empty($page_header_title)) :
            $page_header_title = get_bloginfo('name');
        endif;

        return $page_header_title;
    }
endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Page header section background image
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_page_header_background')) :

    function markety_page_header_background() {

        $page_header_image = false;

        if (is_archive()) :
            $page_header_image = markety_option('archive-header-image', 'url');
        endif;

        if (is_404()) :
            $page_header_image = markety_option('header-404-image', 'url');
        endif;

        if (is_search()) :
            $page_header_image = markety_option('search-header-image', 'url');
        endif;

        if (is_category()) :
            $page_header_image = markety_option('category-header-image', 'url');
        endif;

        if (is_tag()) :
            $page_header_image = markety_option('tag-header-image', 'url');
        endif;

        if (is_author()) :
            $page_header_image = markety_option('author-header-image', 'url');
        endif;


        if (is_page()) :
            
            $page_header_image = markety_option('page-header-image', 'url');
            
            if (function_exists('rwmb_meta')) :
                $single_image = rwmb_meta('markety_page_header_image', 'type=image_advanced');
            endif;

            if (!empty($single_image)) {
                foreach ($single_image as $image) {
                    $page_header_image = $image['full_url'];
                }
            }

        endif;


        if (is_single()) :

            $page_header_image = markety_option('blog-header-image', 'url');
            
            if (function_exists('rwmb_meta')) :
                $single_image = rwmb_meta('markety_page_header_image', 'type=image_advanced');
            endif;

            if (!empty($single_image)) {
                foreach ($single_image as $image) {
                    $page_header_image = $image['full_url'];
                }
            }

        endif;

        if (empty ($single_image)) :
            if (is_singular('tt-portfolio')) :
                $page_header_image = markety_option('portfolio-header-image', 'url');
            endif;

            if (is_singular('tt-member')) :
                $page_header_image = markety_option('member-header-image', 'url');
            endif;
            
            if (class_exists('WooCommerce')) :
                if (is_singular('product')) :
                    $page_header_image = markety_option('product-header-image', 'url');
                endif;
            endif;
            
        endif;

        if (class_exists( 'WooCommerce' ) ) :
            if ( is_post_type_archive( 'product' ) || is_tax('product_cat') || is_tax('product_tag')) {
                $page_header_image = markety_option('product-header-image', 'url');
            }
        endif;

        if (is_home()) :
            $page_header_image = markety_option('blog-header-image', 'url');
        endif;

        if (!$page_header_image) :
            $page_header_image = markety_option('blog-header-image', 'url');
        endif;

        $image_src = apply_filters('markety_page_header_background', $page_header_image, $page_header_image);

        return $image_src;
        
    }

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Comment form
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_comment_form')) :

    function markety_comment_form($args = array(), $post_id = NULL) {
        if (NULL === $post_id) {
            $post_id = get_the_ID();
        } else {
            $id = $post_id;
        }

        $commenter = wp_get_current_commenter();
        $user = wp_get_current_user();
        $user_identity = $user->exists() ? $user->display_name : '';

        if (!isset($args[ 'format' ])) {
            $args[ 'format' ] = current_theme_supports('html5', 'comment-form') ? 'html5' : 'xhtml';
        }

        $req = get_option('require_name_email');
        $aria_req = ($req ? " aria-required='true'" : '');
        $html5 = 'html5' === $args[ 'format' ];
        $fields = array(
            'author' => '
            <div class="form-group">
                <div class="col-sm-6 comment-form-author">
                    <input   class="form-control"  id="author"
                    placeholder="' . esc_attr__('Name', 'markety') . '" name="author" type="text"
                    value="' . esc_attr($commenter[ 'comment_author' ]) . '" ' . $aria_req . ' />
                </div>',
            'email'  => '<div class="col-sm-6 comment-form-email">
                <input id="email" class="form-control" name="email"
                placeholder="' . esc_attr__('Email', 'markety') . '" ' . ($html5 ? 'type="email"' : 'type="text"') . '
                value="' . esc_attr($commenter[ 'comment_author_email' ]) . '" ' . $aria_req . ' />
            </div>
        </div>',
            'url'    => '<div class="form-group">
        <div class=" col-sm-12 comment-form-url">' .
                '<input  class="form-control" placeholder="' . esc_attr__('Website', 'markety') . '"  id="url" name="url" ' . ($html5 ? 'type="url"' : 'type="text"') . ' value="' . esc_attr($commenter[ 'comment_author_url' ]) . '"  />
        </div></div>',

        );

        $required_text = sprintf(' ' . esc_html__('Required fields are marked %s', 'markety'), '<span class="required">*</span>');
        $defaults = array(
            'fields'               => apply_filters('comment_form_default_fields', $fields),
            'comment_field'        => '
            <div class="form-group comment-form-comment">
                <div class="col-sm-12">
                    <textarea class="form-control" id="comment" name="comment" placeholder="' . esc_html__('Comment','markety') . '" rows="8" aria-required="true"></textarea>
                </div>
            </div>
            ',
            'must_log_in'          => '
            
            <div class="alert alert-danger must-log-in">' 
            . sprintf( wp_kses( __( 'You must be <a href="%s">logged in</a> to post a comment.', 'markety' ), array( 'a' => array( 'href' => array() ) ) ), wp_login_url( apply_filters( 'the_permalink', esc_url( get_permalink( $post_id ) ) ) ) ) . '</div>',
            'logged_in_as'         => '<div class="alert alert-info logged-in-as">' . sprintf( wp_kses( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'markety' ), array( 'a' => array( 'href' => array() ) ) ), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', esc_url( get_permalink( $post_id ) ) ) ) ) . '</div>',
            'comment_notes_before' => '<div class="alert alert-info comment-notes">' . esc_html__( 'Your email address will not be published.', 'markety' ) . ( $req ? $required_text : '' ) . '</div>',
            'comment_notes_after'  => '<div class="form-allowed-tags">' . sprintf( wp_kses( __( 'You may use these <abbr title="HyperText Markup Language">HTML</abbr> tags and attributes: %s', 'markety' ), array( 'abbr' => array( 'title' => array() ) ) ), ' <code>' . allowed_tags() . '</code>' ) . '</div>',
            'id_form'              => 'commentform',
            'id_submit'            => 'submit',
            'title_reply'          => esc_html__( 'Leave a Reply', 'markety' ),
            'title_reply_to'       => esc_html__( 'Leave a Reply to %s', 'markety' ),
            'cancel_reply_link'    => esc_html__( 'Cancel reply', 'markety' ),
            'label_submit'         => esc_html__( 'Submit Comment', 'markety' ),
            'format'               => 'xhtml',
        );

        $args = wp_parse_args($args, apply_filters('comment_form_defaults', $defaults));

        if (comments_open($post_id)) {
            ?>
            <?php do_action('comment_form_before'); ?>
            <div id="respond" class="comment-respond">
                <h3 id="reply-title" class="comment-reply-title">
                    <?php comment_form_title($args[ 'title_reply' ], $args[ 'title_reply_to' ]); ?>
                    <small><?php cancel_comment_reply_link($args[ 'cancel_reply_link' ]); ?></small>
                </h3>

                <?php if (get_option('comment_registration') && !is_user_logged_in()) { ?>
                    <?php echo $args[ 'must_log_in' ]; ?>
                    <?php do_action('comment_form_must_log_in_after'); ?>
                <?php } else { ?>
                    <form action="<?php echo site_url('/wp-comments-post.php'); ?>" method="post"
                          id="<?php echo esc_attr($args[ 'id_form' ]); ?>"
                          class="form-horizontal comment-form"<?php echo $html5 ? ' novalidate' : ''; ?>
                          role="form">
                        <?php do_action('comment_form_top'); ?>
                        <?php if (is_user_logged_in()) { ?>
                            <?php echo apply_filters('comment_form_logged_in', $args[ 'logged_in_as' ], $commenter, $user_identity); ?>
                            <?php do_action('comment_form_logged_in_after', $commenter, $user_identity); ?>
                        <?php } else { ?>
                            <?php echo $args[ 'comment_notes_before' ]; ?>
                            <?php
                            do_action('comment_form_before_fields');
                            foreach ((array) $args[ 'fields' ] as $name => $field) {
                                echo apply_filters("comment_form_field_{$name}", $field) . "\n";
                            }
                            do_action('comment_form_after_fields');
                        }

                            echo apply_filters('comment_form_field_comment', $args[ 'comment_field' ]);

                            echo $args[ 'comment_notes_after' ]; ?>

                        <div class="form-submit">
                            <input class="btn btn-primary" name="submit" type="submit"
                                   id="<?php echo esc_attr($args[ 'id_submit' ]); ?>"
                                   value="<?php echo esc_attr($args[ 'label_submit' ]); ?>"/>
                            <?php comment_id_fields($post_id); ?>
                        </div>
                        <?php do_action('comment_form', $post_id); ?>
                    </form>
                <?php } ?>
            </div><!-- #respond -->
            <?php do_action('comment_form_after'); ?>
        <?php } else { ?>
            <?php do_action('comment_form_comments_closed'); ?>
        <?php } ?>
    <?php
    }
endif;

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Comments list
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists("markety_comments_list")) :

    function markety_comments_list($comment, $args, $depth) {
        $GLOBALS[ 'comment' ] = $comment;
        switch ($comment->comment_type) {
            // Display trackbacks differently than normal comments.
            case 'pingback' :
            case 'trackback' :
                ?>

                <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
                <p><?php esc_html_e('Pingback:', 'markety'); ?> <?php comment_author_link(); ?> <?php edit_comment_link(esc_html__('(Edit)', 'markety'), '<span class="edit-link">', '</span>'); ?></p>

                <?php
                break;

            default :
                // Proceed with normal comments.
                global $post;
                ?>
                <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
                <div id="comment-<?php comment_ID(); ?>" class="comment media">
                    <div class="comment-author clearfix">

                        <div class="comment-meta media-heading">

                            <div class="media-left">
                                <?php
                                    $get_avatar = get_avatar($comment, apply_filters('markety_post_comment_avatar_size', 80));
                                    $avatar_img = markety_get_avatar_url($get_avatar);
                                ?>
                                <img class="avatar" src="<?php echo esc_url($avatar_img); ?>" alt="<?php echo get_comment_author(); ?>">
                            </div>

                            <div class="media-body">
                                <div class="comment-info">
                                    <div class="comment-author">
                                        <h4><?php echo get_comment_author(); ?></h4>
                                    </div>
                                    
                                    <div class="pull-right">
                                        <time datetime="<?php echo get_comment_date(); ?>">
                                            <?php echo get_comment_date(); ?> <?php echo get_comment_time(); ?>
                                            <?php edit_comment_link(esc_html__('Edit', 'markety'), '<span class="edit-link">', '</span>'); //edit link
                                            ?>
                                        </time>

                                        <?php comment_reply_link(array_merge($args, array(
                                            'reply_text' => esc_html__('Reply', 'markety'),
                                            'depth'      => $depth,
                                            'max_depth'  => $args[ 'max_depth' ]
                                        ))); ?>
                                    </div>
                                </div>

                                <?php if ('0' == $comment->comment_approved) { ?>
                                    <div class="alert alert-info">
                                        <?php esc_html_e('Your comment is awaiting moderation.', 'markety'); ?>
                                    </div>
                                <?php } ?>
                                
                                <?php comment_text(); //Comment text ?>
                            </div>

                        </div> <!-- .comment-meta -->
                    </div> <!-- .comment-author -->
                </div> <!-- #comment-## -->
                <?php
                break;
        } // end comment_type check

    }

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Fetching Avatar URL
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_get_avatar_url')) :

    function markety_get_avatar_url($get_avatar) {
        preg_match("/src='(.*?)'/i", $get_avatar, $matches);

        return $matches[ 1 ];
    }

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Search form
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_blog_search_form')) :

    function markety_blog_search_form($form) {
        $form = '<form role="search" method="get" id="searchform" class="search-form" action="' . esc_url(home_url('/')) . '">
        <input type="text" class="form-control" value="' . get_search_query() . '" name="s" id="s" placeholder="'.esc_attr__('Search', 'markety').'"/>
        <button type="submit">'.esc_html('Search', 'markety').'</button>
        <input type="hidden" value="post" name="post_type" id="post_type" />
    </form>';

        return $form;
    }

    add_filter('get_search_form', 'markety_blog_search_form');

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Associative array to html attribute conversion
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_array2attr')) :
  
    function markety_array2attr($attr, $filter = '') {
        $attr = wp_parse_args($attr, array());
        if ($filter) {
            $attr = apply_filters($filter, $attr);
        }
        $html = '';
        foreach ($attr as $name => $value) {
            $html .= " $name=" . '"' . $value . '"';
        }

        return $html;
    }

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Hex to RGB color
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_hex2rgb')) :
    
    function markety_hex2rgb($hex) {
       $hex = str_replace("#", "", $hex);

       if(strlen($hex) == 3) {
          $r = hexdec(substr($hex,0,1).substr($hex,0,1));
          $g = hexdec(substr($hex,1,1).substr($hex,1,1));
          $b = hexdec(substr($hex,2,1).substr($hex,2,1));
       } else {
          $r = hexdec(substr($hex,0,2));
          $g = hexdec(substr($hex,2,2));
          $b = hexdec(substr($hex,4,2));
       }
       $rgb = array($r, $g, $b);

       return $rgb[0].','.$rgb[1].','.$rgb[2];
    }

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// color modify for darken/lighten
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if (!function_exists('markety_modify_color')) :
    
    function markety_modify_color( $hex, $steps ) {
        $steps = max( -255, min( 255, $steps ) );
        // Format the hex color string
        $hex = str_replace( '#', '', $hex );
        if ( strlen( $hex ) == 3 ) {
            $hex = str_repeat( substr( $hex,0,1 ), 2 ).str_repeat( substr( $hex,1,1 ), 2 ).str_repeat( substr( $hex,2,1 ), 2 );
        }
        // Get decimal values
        $r = hexdec( substr( $hex,0,2 ) );
        $g = hexdec( substr( $hex,2,2 ) );
        $b = hexdec( substr( $hex,4,2 ) );
        // Adjust number of steps and keep it inside 0 to 255
        $r = max( 0,min( 255,$r + $steps ) );
        $g = max( 0,min( 255,$g + $steps ) );  
        $b = max( 0,min( 255,$b + $steps ) );
        $r_hex = str_pad( dechex( $r ), 2, '0', STR_PAD_LEFT );
        $g_hex = str_pad( dechex( $g ), 2, '0', STR_PAD_LEFT );
        $b_hex = str_pad( dechex( $b ), 2, '0', STR_PAD_LEFT );
        return '#'.$r_hex.$g_hex.$b_hex;
    }

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Portfolio category
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if (! function_exists('markety_portfolio_cat')) :
    function markety_portfolio_cat(){
        $portfolio_terms = wp_get_post_terms(get_the_ID(), 'tt-portfolio-cat');
        $count = count($portfolio_terms);
        $increament = 0;

        foreach ($portfolio_terms as $term) :
            $increament++; ?>
            <a class="links" href="<?php echo esc_url(get_term_link($term, 'tt-portfolio')) ?>"><?php echo esc_html($term->name); ?></a><?php echo esc_html($increament < $count ? ', ' : '');
        endforeach;
    }
endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Ajax search result
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (!function_exists('markety_load_search_results')) :
    
    function markety_load_search_results() {
        get_template_part('search', 'loading');

        die();
    }

    add_action( 'wp_ajax_load_search_results', 'markety_load_search_results' );
    add_action( 'wp_ajax_nopriv_load_search_results', 'markety_load_search_results' );
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Previous post featured image
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'markety_previous_post_image' ) ) :
    function markety_previous_post_image( $size = 'thumbnail' ) {
        $post = get_previous_post();
        if ( ! empty( $post ) ) {
            $id = $post->ID;
            if ( has_post_thumbnail() ) {
                return get_the_post_thumbnail( $id, $size );
            }
        }
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Next post featured image
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'markety_next_post_image' ) ) :
    function markety_next_post_image( $size = 'thumbnail' ) {
        $post = get_next_post();
        if ( ! empty( $post ) ) {
            $id = $post->ID;
            if ( has_post_thumbnail() ) {
                return get_the_post_thumbnail( $id, $size );
            }
        }
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Post thumbnail alt text
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (! function_exists( 'markety_alt_text' )) :
    function markety_alt_text(){
        $id = get_the_ID();
        $thumbnail_id = get_post_thumbnail_id($id);

        $alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);

        if ($alt) :
            return $alt;
        else :
            return get_the_title();
        endif;
    }
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Remove Query Strings From Static Resources
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if( ! function_exists( 'markety_remove_query_strings_1' )){
    function markety_remove_query_strings_1( $src ){
        $parts = explode( '?ver', $src );
        return $parts[0];
    }
}

if( ! function_exists( 'markety_remove_query_strings_2' )){
    function markety_remove_query_strings_2( $src ){
        $parts = explode( '&ver', $src );
        return $parts[0];
    }
}