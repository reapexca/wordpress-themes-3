<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Register meta boxes
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (! function_exists('markety_register_meta_boxes')) :

	function markety_register_meta_boxes( $meta_boxes ) {
		/**
		 * Prefix of meta keys (optional)
		 */

		$prefix = 'markety_';

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format quote
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

		$meta_boxes[] = array(
			'id' => 'tt-post-format-quote',

			// Meta box title - Will appear at the drag and drop handle bar. Required.
			'title' => esc_html__( 'Post Quote Settings', 'markety' ),

			// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
			'pages' => array( 'post'),

			// Where the meta box appear: normal (default), advanced, side. Optional.
			'context' => 'normal',

			// Order of meta box: high (default), low. Optional.
			'priority' => 'high',

			// Auto save: true, false (default). Optional.
			'autosave' => true,

			// List of meta fields
			'fields' => array(
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Qoute Text', 'markety' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute",
					'desc'  => esc_html__( 'Write Your Qoute Here', 'markety' ),
					'type'  => 'textarea',
					// Default value (optional)
					'std'   => ''
				),
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Qoute Author/Company', 'markety' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute_author",
					'desc'  => esc_html__( 'Write Qoute Author or Company name', 'markety' ),
					'type'  => 'text',
					// Default value (optional)
					'std'   => ''
				),
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Author/Company URL', 'markety' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute_author_url",
					'desc'  => esc_html__( 'Write Qoute Author or Company URL', 'markety' ),
					'type'  => 'text',
					// Default value (optional)
					'std'   => ''
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format link
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-link',
			'title' => esc_html__( 'Post Link Settings', 'markety' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Link text', 'markety' ),
					'id'    => "{$prefix}link_text",
					'desc'  => esc_html__( 'Write Your Link Text, leave blank to show only url', 'markety' ),
					'type'  => 'text',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Link URL*', 'markety' ),
					'id'    => "{$prefix}link",
					'desc'  => esc_html__( 'Write Your Link, e.g: http://yourlink.com', 'markety' ),
					'type'  => 'text',
					'std'   => ''
				),

				array(
					'name'     => esc_html__( 'Link title', 'markety' ),
					'id'       => "{$prefix}link_title",
					'desc'     => esc_html__( 'Write link title, appear as link title attribute', 'markety' ),
					'type'     => 'text',
					'std'      => ''
				),

				array(
					'name'     => esc_html__( 'Link target', 'markety' ),
					'id'       => "{$prefix}link_target",
					'type'     => 'select',
					'options'  => array(
						'_self' => esc_html__( 'Self', 'markety' ),
						'_blank' => esc_html__( 'New Window', 'markety' )
					),
					'std'         => 'self'
				)
			)
		);

		
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format audio
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-audio',
			'title' => esc_html__( 'Post Audio Settings', 'markety' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Featured Audio (.mp3)', 'markety' ),
					'id'    => "{$prefix}featured_mp3",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.mp3', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Audio (.ogg)', 'markety' ),
					'id'    => "{$prefix}featured_ogg",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.ogg', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Audio (.wav)', 'markety' ),
					'id'    => "{$prefix}featured_wav",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.wav', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Embed Audio', 'markety' ),
					'id'    => "{$prefix}embed_audio",
					'desc'  => esc_html__( 'Input URL for sounds, audios from Youtube, Soundcloud and all supported sites by WordPress, Supported list: http://codex.wordpress.org/Embeds', 'markety' ),
					'type'  => 'oembed',
					'std'   => ''
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format video
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-video',
			'title' => esc_html__( 'Post Video Settings', 'markety' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Featured Video (.mp4)', 'markety' ),
					'id'    => "{$prefix}featured_mp4",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.mp4', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Video (.webm)', 'markety' ),
					'id'    => "{$prefix}featured_webm",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.webm', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Video (.ogv)', 'markety' ),
					'id'    => "{$prefix}featured_ogv",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.ogv', 'markety' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Embed Video', 'markety' ),
					'id'    => "{$prefix}embed_video",
					'desc'  => esc_html__( 'Enter embed code here.', 'markety' ),
					//'type'  => 'oembed',
					'type'  => 'textarea',
					'std'   => ''
				)	
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format gallery
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-gallery',
			'title' => esc_html__( 'Post Gallery Settings', 'markety' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'             => esc_html__( 'Upload image from media library', 'markety' ),
					'id'               => "{$prefix}post_gallery",
					'type'             => 'image_advanced',
					'max_file_uploads' => 6,
				)			
			)
		);



		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for portfolio gallery
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'portfolio-gallery-settings',
			'title' => esc_html__( 'Portfolio Gallery', 'markety' ),
			'pages' => array('tt-portfolio'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				
				array(
					'name'             => esc_html__( 'Portfolio Gallery', 'markety' ),
					'id'               => "{$prefix}portfolio_gallery",
					'type'             => 'image_advanced',
					'max_file_uploads' => 5,
					'desc'  => esc_html__( 'Upload gallery image to show gallery on single portfolio', 'markety' ),
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for portfolio
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'portfolio-meta-settings',
			'title' => esc_html__( 'Portfolio Settings', 'markety' ),
			'pages' => array('tt-portfolio'),
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Select single portfolio layout', 'markety' ),
					'id'          => "{$prefix}portfolio_single_layout",
					'type'        => 'select_advanced',
					'options'     => array(
						'portfolio-layout-default' => esc_html__( 'Default layout', 'markety' ),
						'portfolio-layout-sidebar' => esc_html__( 'Details on sidebar', 'markety' ),
					),
					'multiple'    => false,
					'std'         => 'portfolio-layout-default', // Default value, optional
					'placeholder' => esc_html__( 'Select a layout', 'markety' )
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'markety' ),
					'id'  	=> "{$prefix}portfolio_divider_one",
					'type' 	=> 'divider'
				),
				
                array(
					'name'    	=> esc_html__( 'Portfolio Overview', 'markety' ),
					'id'   => "{$prefix}portfolio_overview",
					'type'    	=> 'text_list',
					// Number of rows
					'rows'    	=> 1,
					'options' 	=> array(
						'Label' => esc_html__( 'Label', 'markety' ),
						'Value' => esc_html__( 'Value', 'markety' )
					),
					'clone'		=> true,
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'markety' ),
					'id'  	=> "{$prefix}portfolio_divider_three",
					'type' 	=> 'divider'
				),

				array(
					'name'    	=> esc_html__( 'Show/hide social share button', 'markety' ),
					'id'   		=> "{$prefix}portfolio_share",
					'type'    	=> 'radio',
					'options' 	=> array(
						'show_share' => esc_html__( 'Show', 'markety' ),
						'hide_share' => esc_html__( 'Hide', 'markety' )
					),
					'std'		=> 'show_share'
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'markety' ),
					'id'  	=> "{$prefix}portfolio_divider_four",
					'type' 	=> 'divider'
				),

				array(
					'name'    	=> esc_html__( 'Portfolio link text', 'markety' ),
					'id'   		=> "{$prefix}portfolio_link_text",
					'type'    	=> 'text',
					'desc'     	=> esc_html__( 'Enter link text', 'markety' ),
					
				),
				array(
					'name'    	=> esc_html__( 'Portfolio link', 'markety' ),
					'id'   		=> "{$prefix}portfolio_link",
					'type'    	=> 'text',
					'desc'     	=> esc_html__( 'Enter portfolio link', 'markety' ),
					
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for page header
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-meta-settings',
			'title' => esc_html__( 'Page Settings', 'markety' ),
			'pages' => array( 'page', 'tt-portfolio', 'product', 'tt-member'),
			'context' => 'normal',
			'priority' => 'low',
			'fields' => array(

				// header visibility option
				array(
					'name'        => esc_html__( 'Enable/Disable Page Header', 'markety' ),
					'id'          => "{$prefix}page_header_visibility",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'header-section-show' => esc_html__( 'Header Section Show', 'markety' ),
						'header-section-hide' => esc_html__( 'Header Section Hide', 'markety' )
					),
					// Default selected value
					'std'         => 'header-section-show',
					// Placeholder
					'placeholder' => esc_html__( 'Select header visibility option', 'markety' )
				),

				array(
					'name'             => esc_html__( 'Subtitle', 'markety' ),
					'id'               => "{$prefix}page_subtitle",
					'type'             => 'text',
					'desc'  		   => esc_html__( 'Enter page subtitle', 'markety' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'markety' ),
					'id'               => "{$prefix}breadcumb_divider_one",
					'type'             => 'divider'
				),

				// Section padding
				array(
					'name'             => esc_html__( 'Padding top', 'markety' ),
					'id'               => "{$prefix}header_padding_top",
					'type'             => 'text',
					'desc'  		   => esc_html__( 'Enter page header section top padding in px', 'markety' ),
				),

				array(
					'name'             => esc_html__( 'Padding bottom', 'markety' ),
					'id'               => "{$prefix}header_padding_bottom",
					'type'             => 'text',
					'desc'  => esc_html__( 'Enter page header section bottom padding in px', 'markety' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'markety' ),
					'id'               => "{$prefix}breadcumb_divider_two",
					'type'             => 'divider'
				),

				// Background image
				array(
					'name'             => esc_html__( 'Background image', 'markety' ),
					'id'               => "{$prefix}page_header_image",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'Upload background image, dimension: 1920px x 450px', 'markety' ),
				),

				// Parallax background
				array(
					'name'             	=> esc_html__( 'Parallax background', 'markety' ),
					'id'               	=> "{$prefix}parallax_header_image",
					'type'             	=> 'radio',
					'options'     		=> array(
						'parallax_header_bg' => esc_html__( 'Enable', 'markety' ),
						'default_header_bg' => esc_html__( 'Disable', 'markety' )
					),
					'std'				=> 'default_header_bg',
					'desc'  => esc_html__( 'Select parallax background option', 'markety' ),
				),

				// Background overlay option
				array(
					'name'             	=> esc_html__( 'Enable background overlay color', 'markety' ),
					'id'               	=> "{$prefix}background_overlay",
					'type'             	=> 'radio',
					'options'     		=> array(
						'bg_overlay_enable' => esc_html__( 'Enable', 'markety' ),
						'bg_overlay_disable' => esc_html__( 'Disable', 'markety' )
					),
					'std'				=> 'bg_overlay_disable',
					'desc'  => esc_html__( 'Select background overlay option', 'markety' ),
				),

				// Background color
				array(
					'name'             => esc_html__( 'Background color', 'markety' ),
					'id'               => "{$prefix}page_header_color",
					'type'             => 'color',
					'desc'  => esc_html__( 'Select backgroud color if do not like to use background image', 'markety' ),
				),

				// title color
				array(
					'name'             => esc_html__( 'Title color', 'markety' ),
					'id'               => "{$prefix}header_content_color",
					'type'             => 'color',
					'desc'  => esc_html__( 'Select content color if needed', 'markety' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'markety' ),
					'id'               => "{$prefix}breadcumb_divider_three",
					'type'             => 'divider'
				),

				// Content alignment
				array(
					'name'        => esc_html__( 'Content alignment', 'markety' ),
					'id'          => "{$prefix}breadcrumb_content_alignment",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'text-center' => esc_html__( 'Content center', 'markety' ),
						'text-left' => esc_html__( 'Content left', 'markety' ),
						'text-right' => esc_html__( 'Content right', 'markety' ),
						'title-left' => esc_html__( 'Title left', 'markety' ),
						'title-right' => esc_html__( 'Title Right', 'markety' )
					),
					// Default selected value
					'std'         => 'text-center',
					// Placeholder
					'placeholder' => esc_html__( 'Select breadcrumb alignment', 'markety' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'markety' ),
					'id'               => "{$prefix}breadcumb_divider_four",
					'type'             => 'divider'
				),

				// Hide breadcrumb
				array(
					'name'             	=> esc_html__( 'Show/hide breadcrumb', 'markety' ),
					'id'               	=> "{$prefix}page_breadcrumb_show",
					'type'             	=> 'radio',
					'options'     		=> array(
						'page_breadcrumb_show' => esc_html__( 'Show', 'markety' ),
						'page_breadcrumb_hide' => esc_html__( 'Hide', 'markety' )
					),
					'std'				=> 'page_breadcrumb_hide',
					'desc'  => esc_html__( 'Select breadcrumb show/hide option', 'markety' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'markety' ),
					'id'               => "{$prefix}breadcumb_divider_five",
					'type'             => 'divider'
				),

				// Page Header Margin Bottom
				array(
					'name'             => esc_html__( 'Page Header Margin Bottom', 'markety' ),
					'id'               => "{$prefix}page_header_margin_bottom",
					'type'             => 'text',
					'desc'  => esc_html__( 'Enter margin bottom value in px', 'markety' ),
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for header style
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-header-style',
			'title' => esc_html__( 'Page Header Styles', 'markety' ),
			'pages' => array( 'page', 'tt-portfolio', 'product', 'tt-member'),
			'context' => 'side',
			'priority' => 'high',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Header style', 'markety' ),
					'id'          => "{$prefix}header_style",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'inherit-theme-option' => esc_html__( 'Inherit from theme option', 'markety' ),
						'header-default' => esc_html__( 'Header Default', 'markety' ),
						'header-transparent' => esc_html__( 'Header transparent', 'markety' )
					),
					// Default selected value
					'std'         => 'inherit-theme-option',
					// Placeholder
					'placeholder' => esc_html__( 'Select header style', 'markety' ),
					'desc'     => esc_html__( 'This settings apply only for this page', 'markety' )
				)
			)
		);

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for footer style
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-footer-style',
			'title' => esc_html__( 'Page Footer Styles', 'markety' ),
			'pages' => array( 'page', 'tt-portfolio', 'product', 'tt-member'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Footer style', 'markety' ),
					'id'          => "{$prefix}footer_style",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'inherit-theme-option' => esc_html__( 'Inherit from theme option', 'markety' ),
						'footer-default' => esc_html__( 'Footer default', 'markety' ),
						'footer-three-column' => esc_html__( 'Footer three column', 'markety' ),
						'footer-four-column' => esc_html__( 'Footer four column', 'markety' ),
						'footer-onepage' => esc_html__( 'Footer onepage', 'markety' )
					),
					// Default selected value
					'std'         => 'inherit-theme-option',
					// Placeholder
					'placeholder' => esc_html__( 'Select footer style', 'markety' ),
					'desc'     => esc_html__( 'This settings apply only for this page', 'markety' )
				)
			)
		);

		$the_sidebars = '';

		if (function_exists('smk_get_all_sidebars')) :
			$the_sidebars = smk_get_all_sidebars();
			if( is_array($the_sidebars) ){
	            $select_str = esc_html__('-- Select a sidebar --', 'markety');
	            $the_sidebars = array_merge( array( '' => $select_str ), $the_sidebars );
	        }
		endif;
		

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for sidebar style
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-sidebar-style',
			'title' => esc_html__( 'Sidebar Settings', 'markety' ),
			'pages' => array( 'page'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Sidebars', 'markety' ),
					'id'          => "{$prefix}page_sidebars",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => $the_sidebars,
					// Default selected value
					'std'         => 'markety-page-sidebar',
					// Placeholder
					'placeholder' => esc_html__( 'Select sidebar', 'markety' ),
					'desc'     => esc_html__( 'This settings apply only for this page', 'markety' )
				)
			)
		);


		
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for member post type
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'member-meta-settings',
			'title' => esc_html__( 'Team Member Settings', 'markety' ),
			'pages' => array( 'tt-member'),
			'fields' => array(
				array(
					'name'     => esc_html__( 'Member Designation', 'markety' ),
					'id'       => "{$prefix}member_designaion",
					'desc'     => esc_html__( 'Enter member designation', 'markety' ),
					'type'     => 'text'
				),
				
				array(
					'name'     => esc_html__( 'Educational Qualification', 'markety' ),
					'id'       => "{$prefix}educational_qualification",
					'desc'     => esc_html__( 'Enter educational qualification', 'markety' ),
					'type'     => 'wysiwyg',
					'options'  => array(
						'editor_height' => 100
					)
				),

				array(
					'name'     => esc_html__( 'Address', 'markety' ),
					'id'       => "{$prefix}member_address",
					'desc'     => esc_html__( 'Enter member address', 'markety' ),
					'type'     => 'wysiwyg',
					'options'  => array(
						'editor_height' => 100
					)
				)
			)
		);

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Member social settings
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'member-social-settings',
			'title' => esc_html__( 'Member Social Settings', 'markety' ),
			'pages' => array( 'tt-member'),
			'fields' => array(
				array(
					'name'     => esc_html__( 'Facebook Link', 'markety' ),
					'id'       => "{$prefix}facebook_link",
					'desc'     => esc_html__( 'Enter facebook page or profile link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Twitter Link', 'markety' ),
					'id'       => "{$prefix}twitter_link",
					'desc'     => esc_html__( 'Enter twitter profile link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Google Plus Link', 'markety' ),
					'id'       => "{$prefix}google_plus_link",
					'desc'     => esc_html__( 'Enter google plus profile or page link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Linkedin Link', 'markety' ),
					'id'       => "{$prefix}linkedin_link",
					'desc'     => esc_html__( 'Enter linkedin profile link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Flickr Link', 'markety' ),
					'id'       => "{$prefix}flickr_link",
					'desc'     => esc_html__( 'Enter flickr profile link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Youtube Link', 'markety' ),
					'id'       => "{$prefix}youtube_link",
					'desc'     => esc_html__( 'Enter youtube channel link', 'markety' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Email Address', 'markety' ),
					'id'       => "{$prefix}member_email",
					'desc'     => esc_html__( 'Enter member email address', 'markety' ),
					'type'     => 'text'
				)
			)
		);

		return $meta_boxes;
	}

	add_filter( 'rwmb_meta_boxes', 'markety_register_meta_boxes' );

endif;