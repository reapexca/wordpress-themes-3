<?php 
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;


$pagesidebar = 'markety-page-sidebar';

if (function_exists('rwmb_meta')) :
	$pagesidebar = rwmb_meta('markety_page_sidebars');
endif;

$page_sidebar = markety_option( 'page-layout', false, 'right-sidebar' );

if ( $page_sidebar == 'right-sidebar' and is_active_sidebar( 'markety-page-sidebar' ) ) : ?>
	<div class="col-md-4 col-sm-4">
		<div class="tt-sidebar-wrapper right-sidebar page-sidebar" role="complementary">
			<?php if (function_exists('smk_sidebar') && rwmb_meta('markety_page_sidebars')) :
				smk_sidebar($pagesidebar);
			else :
				dynamic_sidebar( 'markety-page-sidebar' );
			endif; ?>
		</div>
	</div>
<?php elseif ( $page_sidebar == 'left-sidebar' and is_active_sidebar( 'markety-page-sidebar' ) ) : ?>
	<div class="col-md-4 col-md-pull-8 col-sm-4 col-sm-pull-8">
		<div class="tt-sidebar-wrapper left-sidebar" role="complementary">
			<?php if (function_exists('smk_sidebar') && rwmb_meta('markety_page_sidebars')) :
				smk_sidebar($pagesidebar);
			else :
				dynamic_sidebar( 'markety-page-sidebar' );
			endif; ?>
		</div>
	</div>
<?php endif;